const COOKIE_DATA_ENCODING_ERROR = `Failed to encode the cookie data.`;

export { COOKIE_DATA_ENCODING_ERROR };
