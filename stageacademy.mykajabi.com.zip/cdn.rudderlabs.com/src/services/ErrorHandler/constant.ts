const LOAD_ORIGIN = 'RS_JS_SDK';

export { LOAD_ORIGIN };
