const externallyLoadedSessionStorageKeys = {
  segment: 'ajs_anonymous_id',
};

export { externallyLoadedSessionStorageKeys };
