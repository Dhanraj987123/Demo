const STORAGE_MIGRATOR_PLUGIN = 'StorageMigratorPlugin';

export { STORAGE_MIGRATOR_PLUGIN };
