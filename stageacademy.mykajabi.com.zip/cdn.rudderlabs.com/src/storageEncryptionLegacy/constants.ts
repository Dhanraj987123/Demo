export const ENCRYPTION_PREFIX_V1 = 'RudderEncrypt:';
export const ENCRYPTION_KEY_V1 = 'Rudder';
