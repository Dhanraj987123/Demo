export const AMP_LINKER_ANONYMOUS_ID_KEY = 'rs_amp_id';
