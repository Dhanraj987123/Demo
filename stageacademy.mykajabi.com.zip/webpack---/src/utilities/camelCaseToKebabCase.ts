export const camelCaseToKebabCase = (camelCaseString: string): string => {
  return camelCaseString.replace(/[A-Z]+(?![a-z])|[A-Z]/g, (letter: string, idx?: number) => {
    return (idx !== undefined ? '-' : '') + letter.toLowerCase();
  });
};

export const kebabCaseToCamelCase = (kebabCaseString: string): string => {
  return kebabCaseString.replace(/-./g, (word) => word[1].toUpperCase());
};
