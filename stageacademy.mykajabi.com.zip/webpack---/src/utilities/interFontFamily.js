export const interBoldItalicFontFamily = 'WistiaPlayerInterBoldItalic, Helvetica, Sans-Serif';
export const interFontFamily = 'WistiaPlayerInter, Helvetica, Sans-Serif';
export const interSemiBoldFontFamily = 'WistiaPlayerInterSemiBold, Helvetica, Sans-Serif';
export const interNumbersSemiBold = 'WistiaPlayerInterNumbersSemiBold, Helvetica, Sans-Serif';