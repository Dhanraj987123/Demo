export const CONTROL_BAR_HEIGHT = 34;

// eslint-disable-next-line @typescript-eslint/no-magic-numbers
export const DEFAULT_ASPECT = 16 / 9;
