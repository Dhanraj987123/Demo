import merge from 'lodash.merge';
import cloneDeep from 'lodash.clonedeep';
import { cast } from '../../../utilities/obj.js';
import type { EmbedOptions, MediaData } from '../../../types/player-api-types.ts';

interface SourceEmbedOptions {
  domOptions?: EmbedOptions;
  iframeOptions?: EmbedOptions;
  mediaDataOptions?: EmbedOptions;
  wistiaWindowOptions?: EmbedOptions;
}

export class PlayerDataHandler {
  // Embed options set after initialization which override the embed options
  // gathered from the source data
  #embedOptionOverrides: EmbedOptions = {};

  // Merged embed options gathered from source data
  #embedOptions: EmbedOptions = {};

  // Merged media data gathered from source data
  #mediaData: MediaData = {};

  // Source data which is used to create the final embed options
  readonly #sourceEmbedOptions: SourceEmbedOptions = {
    domOptions: {} as EmbedOptions,
    iframeOptions: {} as EmbedOptions,
    mediaDataOptions: {} as EmbedOptions,
    wistiaWindowOptions: {} as EmbedOptions,
  };

  // Source data which is used to create the final media data
  #sourceMediaData: MediaData = {};

  /**
   * Returns the final embed options which are a merge of all the source data and the overrides
   * @returns {EmbedOptions}
   * @readonly
   */
  public get embedOptions(): EmbedOptions {
    return this.#embedOptions;
  }

  /**
   * Returns the final media data which is a merge of all the source data
   * @returns {MediaData}
   * @readonly
   */
  public get mediaData(): MediaData {
    // Our embed options can be overridden after our initial source data fetches
    // Make sure the embed options within the media data are up to date
    this.#mediaData.embedOptions = this.#embedOptions;
    return this.#mediaData;
  }

  /**
   * Sets the source data for the embed options set on the <wistia-player> DOM element
   * @param {EmbedOptions} data
   * @returns {void}
   */
  public setDomEmbedOptionSource(data: EmbedOptions): void {
    this.#sourceEmbedOptions.domOptions = data;
    this.#updatePlayerEmbedOptions();
  }

  /**
   * Sets the source data for the embed options from an iframe's url search params
   * @returns {void}
   */
  public setIframeEmbedOptionSource(data: EmbedOptions): void {
    this.#sourceEmbedOptions.iframeOptions = data;
    this.#updatePlayerEmbedOptions();
  }

  /**
   * Sets the source data for the media data
   * @param {MediaData} data
   * @returns {void}
   */
  public setMediaDataSource(data: MediaData): void {
    this.#sourceMediaData = data;
    this.#mediaData = cast(cloneDeep(this.#sourceMediaData)) as MediaData;

    this.#sourceEmbedOptions.mediaDataOptions = cloneDeep(this.#mediaData.embedOptions) ?? {};
    this.#updatePlayerEmbedOptions();
  }

  /**
   * Sets the source data for the embed options set on the window via wistiaOptions
   * @param {EmbedOptions} data
   * @returns {void}
   */
  public setWistiaWindowEmbedOptionSource(data: EmbedOptions): void {
    this.#sourceEmbedOptions.wistiaWindowOptions = data;
    this.#updatePlayerEmbedOptions();
  }

  /**
   * Updates the embed option overrides which will be merged with the source embed option data
   * This merge can happen more frequently than our finite source data sets, which is why it's separate.
   * That way we don't have to re-merge the source data every time we update the overrides.
   * @param {EmbedOptions} data
   * @returns {void}
   */
  public updateEmbedOptionOverrides(data: EmbedOptions): void {
    this.#embedOptionOverrides = merge(this.#embedOptionOverrides, data);
    this.#embedOptions = merge(this.#embedOptions, this.#embedOptionOverrides);
  }

  /**
   * Merge the source embed options together to create a single source of truth of embed options
   * @private
   * @returns {void}
   */
  #updatePlayerEmbedOptions(): void {
    const { mediaDataOptions, wistiaWindowOptions, domOptions, iframeOptions } =
      this.#sourceEmbedOptions;

    // Merge the embed options together to create a single source of truth of embed options
    this.#embedOptions = cast(
      merge(
        {},
        mediaDataOptions ?? {},
        wistiaWindowOptions ?? {},
        domOptions ?? {},
        iframeOptions ?? {},
        this.#embedOptionOverrides,
      ),
    ) as EmbedOptions;

    // Make sure the embed options within the media data are up to date
    this.#mediaData.embedOptions = this.#embedOptions;
  }
}
