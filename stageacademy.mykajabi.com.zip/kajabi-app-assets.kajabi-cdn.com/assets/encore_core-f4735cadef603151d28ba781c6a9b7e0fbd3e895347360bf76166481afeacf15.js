function productTrackingListeners() {
    function e() {
        return $(c).data("token")
    }

    function t(e) {
        return e && "true" === e.attr(l)
    }

    function n(e, t) {
        $.post(a, {
            token: e
        }, t)
    }

    function i(e, t) {
        $.post(a, {
            _method: "DELETE",
            token: e
        }, t)
    }

    function r(e, t) {
        t && e.text(t)
    }

    function s() {
        var e = $(c);
        return e.length > 0 && !!e.data("token")
    }

    function o(e, t) {
        t = !!t, e.attr(l, String(t)), e.trigger("kajabi-post-completion", t)
    }
    var a = "/tracking/completion",
        u = "/tracking/progress",
        l = "data-post-completion-toggle",
        c = "a[" + l + "]",
        d = $(document),
        f = null;
    d.on("kajabi-video-progress", function(t, n) {
        s() && (f = $.extend(n, {
            token: e()
        }))
    }), $(window).on("visibilitychange beforeunload", function() {
        if (!_.isEmpty(f)) {
            if ("undefined" != typeof navigator.sendBeacon) {
                var e = new FormData;
                for (var t in f) e.append(t, f[t]);
                navigator.sendBeacon(u, e)
            } else $.ajax({
                type: "POST",
                async: !1,
                url: u,
                data: f
            });
            f = null
        }
    }), d.on("kajabi-video-completed", function() {
        if (s()) {
            var e = $(c);
            t(e) || e.trigger("click")
        }
    }), $(document).on("click", c, function() {
        var e = $(this),
            s = e.data("token");
        return t(e) ? i(s, function() {
            o(e, !1), r(e, e.data("complete-text"))
        }) : n(s, function() {
            o(e, !0), r(e, e.data("incomplete-text"))
        }), !1
    })
}

function productTrackingVideoSetup() {
    function e(e, n) {
        return !e || 1 > e ? !1 : t(e, n) >= 90
    }

    function t(e, t) {
        return !e || 1 > e ? 0 : Math.min(Math.round(t / e * 100), 100)
    }

    function n() {
        s.trigger("kajabi-video-completed")
    }

    function i() {
        s.trigger("kajabi-video-ended")
    }

    function r(e) {
        s.trigger("kajabi-video-progress", e)
    }
    var s = $(document);
    window._wq = window._wq || [], _wq.push({
        id: "_all",
        onReady: function(s) {
            function o() {
                e(s.duration(), s.time()) && n()
            }

            function a(e, t) {
                if (!(l >= t)) {
                    l = t;
                    var n = {
                        progress_seconds: e,
                        progress_percent: t
                    };
                    r(n)
                }
            }
            var u = $(s.container).data("tracked-percent"),
                l = parseInt(u, 10) || 0;
            s.bind("timechange", _.throttle(o, 1e3));
            var c = 10;
            s.bind("timechange", _.throttle(function() {
                var e = Math.round(s.time()),
                    n = t(s.duration(), e);
                a(e, n)
            }, 1e3 * c)), s.bind("end", function() {
                100 !== l && a(s.duration(), 100), n(), i()
            })
        }
    })
}

function resizeAssessmentIframe(e) {
    $(e).each(function(e, t) {
        t.style.height = t.contentWindow.document.body.offsetHeight + "px", setTimeout(function() {
            t.style.height = t.contentWindow.document.body.offsetHeight + "px"
        }, 10)
    })
}! function(e, t) {
    "use strict";
    "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function(e) {
        if (!e.document) throw new Error("jQuery requires a window with a document");
        return t(e)
    } : t(e)
}("undefined" != typeof window ? window : this, function(e, t) {
    "use strict";

    function n(e, t, n) {
        n = n || _t;
        var i, r, s = n.createElement("script");
        if (s.text = e, t)
            for (i in xt) r = t[i] || t.getAttribute && t.getAttribute(i), r && s.setAttribute(i, r);
        n.head.appendChild(s).parentNode.removeChild(s)
    }

    function i(e) {
        return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? ht[pt.call(e)] || "object" : typeof e
    }

    function r(e) {
        var t = !!e && "length" in e && e.length,
            n = i(e);
        return wt(e) || bt(e) ? !1 : "array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e
    }

    function s(e, t) {
        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
    }

    function o(e, t, n) {
        return wt(t) ? Et.grep(e, function(e, i) {
            return !!t.call(e, i, e) !== n
        }) : t.nodeType ? Et.grep(e, function(e) {
            return e === t !== n
        }) : "string" != typeof t ? Et.grep(e, function(e) {
            return ft.call(t, e) > -1 !== n
        }) : Et.filter(t, e, n)
    }

    function a(e, t) {
        for (;
            (e = e[t]) && 1 !== e.nodeType;);
        return e
    }

    function u(e) {
        var t = {};
        return Et.each(e.match(Nt) || [], function(e, n) {
            t[n] = !0
        }), t
    }

    function l(e) {
        return e
    }

    function c(e) {
        throw e
    }

    function d(e, t, n, i) {
        var r;
        try {
            e && wt(r = e.promise) ? r.call(e).done(t).fail(n) : e && wt(r = e.then) ? r.call(e, t, n) : t.apply(void 0, [e].slice(i))
        } catch (e) {
            n.apply(void 0, [e])
        }
    }

    function f() {
        _t.removeEventListener("DOMContentLoaded", f), e.removeEventListener("load", f), Et.ready()
    }

    function h(e, t) {
        return t.toUpperCase()
    }

    function p(e) {
        return e.replace(It, "ms-").replace(Lt, h)
    }

    function m() {
        this.expando = Et.expando + m.uid++
    }

    function g(e) {
        return "true" === e ? !0 : "false" === e ? !1 : "null" === e ? null : e === +e + "" ? +e : Wt.test(e) ? JSON.parse(e) : e
    }

    function y(e, t, n) {
        var i;
        if (void 0 === n && 1 === e.nodeType)
            if (i = "data-" + t.replace(zt, "-$&").toLowerCase(), n = e.getAttribute(i), "string" == typeof n) {
                try {
                    n = g(n)
                } catch (r) {}
                Bt.set(e, t, n)
            } else n = void 0;
        return n
    }

    function v(e, t, n, i) {
        var r, s, o = 20,
            a = i ? function() {
                return i.cur()
            } : function() {
                return Et.css(e, t, "")
            },
            u = a(),
            l = n && n[3] || (Et.cssNumber[t] ? "" : "px"),
            c = e.nodeType && (Et.cssNumber[t] || "px" !== l && +u) && Gt.exec(Et.css(e, t));
        if (c && c[3] !== l) {
            for (u /= 2, l = l || c[3], c = +u || 1; o--;) Et.style(e, t, c + l), (1 - s) * (1 - (s = a() / u || .5)) <= 0 && (o = 0), c /= s;
            c = 2 * c, Et.style(e, t, c + l), n = n || []
        }
        return n && (c = +c || +u || 0, r = n[1] ? c + (n[1] + 1) * n[2] : +n[2], i && (i.unit = l, i.start = c, i.end = r)), r
    }

    function w(e) {
        var t, n = e.ownerDocument,
            i = e.nodeName,
            r = Zt[i];
        return r ? r : (t = n.body.appendChild(n.createElement(i)), r = Et.css(t, "display"), t.parentNode.removeChild(t), "none" === r && (r = "block"), Zt[i] = r, r)
    }

    function b(e, t) {
        for (var n, i, r = [], s = 0, o = e.length; o > s; s++) i = e[s], i.style && (n = i.style.display, t ? ("none" === n && (r[s] = Ht.get(i, "display") || null, r[s] || (i.style.display = "")), "" === i.style.display && Qt(i) && (r[s] = w(i))) : "none" !== n && (r[s] = "none", Ht.set(i, "display", n)));
        for (s = 0; o > s; s++) null != r[s] && (e[s].style.display = r[s]);
        return e
    }

    function _(e, t) {
        var n;
        return n = "undefined" != typeof e.getElementsByTagName ? e.getElementsByTagName(t || "*") : "undefined" != typeof e.querySelectorAll ? e.querySelectorAll(t || "*") : [], void 0 === t || t && s(e, t) ? Et.merge([e], n) : n
    }

    function x(e, t) {
        for (var n = 0, i = e.length; i > n; n++) Ht.set(e[n], "globalEval", !t || Ht.get(t[n], "globalEval"))
    }

    function C(e, t, n, r, s) {
        for (var o, a, u, l, c, d, f = t.createDocumentFragment(), h = [], p = 0, m = e.length; m > p; p++)
            if (o = e[p], o || 0 === o)
                if ("object" === i(o)) Et.merge(h, o.nodeType ? [o] : o);
                else if (sn.test(o)) {
            for (a = a || f.appendChild(t.createElement("div")), u = (tn.exec(o) || ["", ""])[1].toLowerCase(), l = rn[u] || rn._default, a.innerHTML = l[1] + Et.htmlPrefilter(o) + l[2], d = l[0]; d--;) a = a.lastChild;
            Et.merge(h, a.childNodes), a = f.firstChild, a.textContent = ""
        } else h.push(t.createTextNode(o));
        for (f.textContent = "", p = 0; o = h[p++];)
            if (r && Et.inArray(o, r) > -1) s && s.push(o);
            else if (c = Xt(o), a = _(f.appendChild(o), "script"), c && x(a), n)
            for (d = 0; o = a[d++];) nn.test(o.type || "") && n.push(o);
        return f
    }

    function E() {
        return !0
    }

    function F() {
        return !1
    }

    function T(e, t) {
        return e === k() == ("focus" === t)
    }

    function k() {
        try {
            return _t.activeElement
        } catch (e) {}
    }

    function $(e, t, n, i, r, s) {
        var o, a;
        if ("object" == typeof t) {
            "string" != typeof n && (i = i || n, n = void 0);
            for (a in t) $(e, a, n, i, t[a], s);
            return e
        }
        if (null == i && null == r ? (r = n, i = n = void 0) : null == r && ("string" == typeof n ? (r = i, i = void 0) : (r = i, i = n, n = void 0)), r === !1) r = F;
        else if (!r) return e;
        return 1 === s && (o = r, r = function(e) {
            return Et().off(e), o.apply(this, arguments)
        }, r.guid = o.guid || (o.guid = Et.guid++)), e.each(function() {
            Et.event.add(this, t, r, i, n)
        })
    }

    function S(e, t, n) {
        return n ? (Ht.set(e, t, !1), void Et.event.add(e, t, {
            namespace: !1,
            handler: function(e) {
                var i, r, s = Ht.get(this, t);
                if (1 & e.isTrigger && this[t]) {
                    if (s.length)(Et.event.special[t] || {}).delegateType && e.stopPropagation();
                    else if (s = lt.call(arguments), Ht.set(this, t, s), i = n(this, t), this[t](), r = Ht.get(this, t), s !== r || i ? Ht.set(this, t, !1) : r = {}, s !== r) return e.stopImmediatePropagation(), e.preventDefault(), r.value
                } else s.length && (Ht.set(this, t, {
                    value: Et.event.trigger(Et.extend(s[0], Et.Event.prototype), s.slice(1), this)
                }), e.stopImmediatePropagation())
            }
        })) : void(void 0 === Ht.get(e, t) && Et.event.add(e, t, E))
    }

    function j(e, t) {
        return s(e, "table") && s(11 !== t.nodeType ? t : t.firstChild, "tr") ? Et(e).children("tbody")[0] || e : e
    }

    function A(e) {
        return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
    }

    function O(e) {
        return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"), e
    }

    function P(e, t) {
        var n, i, r, s, o, a, u;
        if (1 === t.nodeType) {
            if (Ht.hasData(e) && (s = Ht.get(e), u = s.events)) {
                Ht.remove(t, "handle events");
                for (r in u)
                    for (n = 0, i = u[r].length; i > n; n++) Et.event.add(t, r, u[r][n])
            }
            Bt.hasData(e) && (o = Bt.access(e), a = Et.extend({}, o), Bt.set(t, a))
        }
    }

    function D(e, t) {
        var n = t.nodeName.toLowerCase();
        "input" === n && en.test(e.type) ? t.checked = e.checked : ("input" === n || "textarea" === n) && (t.defaultValue = e.defaultValue)
    }

    function N(e, t, i, r) {
        t = ct(t);
        var s, o, a, u, l, c, d = 0,
            f = e.length,
            h = f - 1,
            p = t[0],
            m = wt(p);
        if (m || f > 1 && "string" == typeof p && !vt.checkClone && cn.test(p)) return e.each(function(n) {
            var s = e.eq(n);
            m && (t[0] = p.call(this, n, s.html())), N(s, t, i, r)
        });
        if (f && (s = C(t, e[0].ownerDocument, !1, e, r), o = s.firstChild, 1 === s.childNodes.length && (s = o), o || r)) {
            for (a = Et.map(_(s, "script"), A), u = a.length; f > d; d++) l = s, d !== h && (l = Et.clone(l, !0, !0), u && Et.merge(a, _(l, "script"))), i.call(e[d], l, d);
            if (u)
                for (c = a[a.length - 1].ownerDocument, Et.map(a, O), d = 0; u > d; d++) l = a[d], nn.test(l.type || "") && !Ht.access(l, "globalEval") && Et.contains(c, l) && (l.src && "module" !== (l.type || "").toLowerCase() ? Et._evalUrl && !l.noModule && Et._evalUrl(l.src, {
                    nonce: l.nonce || l.getAttribute("nonce")
                }, c) : n(l.textContent.replace(dn, ""), l, c))
        }
        return e
    }

    function q(e, t, n) {
        for (var i, r = t ? Et.filter(t, e) : e, s = 0; null != (i = r[s]); s++) n || 1 !== i.nodeType || Et.cleanData(_(i)), i.parentNode && (n && Xt(i) && x(_(i, "script")), i.parentNode.removeChild(i));
        return e
    }

    function R(e, t, n) {
        var i, r, s, o, a = e.style;
        return n = n || hn(e), n && (o = n.getPropertyValue(t) || n[t], "" !== o || Xt(e) || (o = Et.style(e, t)), !vt.pixelBoxStyles() && fn.test(o) && mn.test(t) && (i = a.width, r = a.minWidth, s = a.maxWidth, a.minWidth = a.maxWidth = a.width = o, o = n.width, a.width = i, a.minWidth = r, a.maxWidth = s)), void 0 !== o ? o + "" : o
    }

    function M(e, t) {
        return {
            get: function() {
                return e() ? void delete this.get : (this.get = t).apply(this, arguments)
            }
        }
    }

    function I(e) {
        for (var t = e[0].toUpperCase() + e.slice(1), n = gn.length; n--;)
            if (e = gn[n] + t, e in yn) return e
    }

    function L(e) {
        var t = Et.cssProps[e] || vn[e];
        return t ? t : e in yn ? e : vn[e] = I(e) || e
    }

    function V(e, t, n) {
        var i = Gt.exec(t);
        return i ? Math.max(0, i[2] - (n || 0)) + (i[3] || "px") : t
    }

    function H(e, t, n, i, r, s) {
        var o = "width" === t ? 1 : 0,
            a = 0,
            u = 0;
        if (n === (i ? "border" : "content")) return 0;
        for (; 4 > o; o += 2) "margin" === n && (u += Et.css(e, n + Yt[o], !0, r)), i ? ("content" === n && (u -= Et.css(e, "padding" + Yt[o], !0, r)), "margin" !== n && (u -= Et.css(e, "border" + Yt[o] + "Width", !0, r))) : (u += Et.css(e, "padding" + Yt[o], !0, r), "padding" !== n ? u += Et.css(e, "border" + Yt[o] + "Width", !0, r) : a += Et.css(e, "border" + Yt[o] + "Width", !0, r));
        return !i && s >= 0 && (u += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - s - u - a - .5)) || 0), u
    }

    function B(e, t, n) {
        var i = hn(e),
            r = !vt.boxSizingReliable() || n,
            o = r && "border-box" === Et.css(e, "boxSizing", !1, i),
            a = o,
            u = R(e, t, i),
            l = "offset" + t[0].toUpperCase() + t.slice(1);
        if (fn.test(u)) {
            if (!n) return u;
            u = "auto"
        }
        return (!vt.boxSizingReliable() && o || !vt.reliableTrDimensions() && s(e, "tr") || "auto" === u || !parseFloat(u) && "inline" === Et.css(e, "display", !1, i)) && e.getClientRects().length && (o = "border-box" === Et.css(e, "boxSizing", !1, i), a = l in e, a && (u = e[l])), u = parseFloat(u) || 0, u + H(e, t, n || (o ? "border" : "content"), a, i, u) + "px"
    }

    function W(e, t, n, i, r) {
        return new W.prototype.init(e, t, n, i, r)
    }

    function z() {
        En && (_t.hidden === !1 && e.requestAnimationFrame ? e.requestAnimationFrame(z) : e.setTimeout(z, Et.fx.interval), Et.fx.tick())
    }

    function U() {
        return e.setTimeout(function() {
            Cn = void 0
        }), Cn = Date.now()
    }

    function G(e, t) {
        var n, i = 0,
            r = {
                height: e
            };
        for (t = t ? 1 : 0; 4 > i; i += 2 - t) n = Yt[i], r["margin" + n] = r["padding" + n] = e;
        return t && (r.opacity = r.width = e), r
    }

    function Y(e, t, n) {
        for (var i, r = (J.tweeners[t] || []).concat(J.tweeners["*"]), s = 0, o = r.length; o > s; s++)
            if (i = r[s].call(n, t, e)) return i
    }

    function K(e, t, n) {
        var i, r, s, o, a, u, l, c, d = "width" in t || "height" in t,
            f = this,
            h = {},
            p = e.style,
            m = e.nodeType && Qt(e),
            g = Ht.get(e, "fxshow");
        n.queue || (o = Et._queueHooks(e, "fx"), null == o.unqueued && (o.unqueued = 0, a = o.empty.fire, o.empty.fire = function() {
            o.unqueued || a()
        }), o.unqueued++, f.always(function() {
            f.always(function() {
                o.unqueued--, Et.queue(e, "fx").length || o.empty.fire()
            })
        }));
        for (i in t)
            if (r = t[i], Fn.test(r)) {
                if (delete t[i], s = s || "toggle" === r, r === (m ? "hide" : "show")) {
                    if ("show" !== r || !g || void 0 === g[i]) continue;
                    m = !0
                }
                h[i] = g && g[i] || Et.style(e, i)
            }
        if (u = !Et.isEmptyObject(t), u || !Et.isEmptyObject(h)) {
            d && 1 === e.nodeType && (n.overflow = [p.overflow, p.overflowX, p.overflowY], l = g && g.display, null == l && (l = Ht.get(e, "display")), c = Et.css(e, "display"), "none" === c && (l ? c = l : (b([e], !0), l = e.style.display || l, c = Et.css(e, "display"), b([e]))), ("inline" === c || "inline-block" === c && null != l) && "none" === Et.css(e, "float") && (u || (f.done(function() {
                p.display = l
            }), null == l && (c = p.display, l = "none" === c ? "" : c)), p.display = "inline-block")), n.overflow && (p.overflow = "hidden", f.always(function() {
                p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
            })), u = !1;
            for (i in h) u || (g ? "hidden" in g && (m = g.hidden) : g = Ht.access(e, "fxshow", {
                display: l
            }), s && (g.hidden = !m), m && b([e], !0), f.done(function() {
                m || b([e]), Ht.remove(e, "fxshow");
                for (i in h) Et.style(e, i, h[i])
            })), u = Y(m ? g[i] : 0, i, f), i in g || (g[i] = u.start, m && (u.end = u.start, u.start = 0))
        }
    }

    function X(e, t) {
        var n, i, r, s, o;
        for (n in e)
            if (i = p(n), r = t[i], s = e[n], Array.isArray(s) && (r = s[1], s = e[n] = s[0]), n !== i && (e[i] = s, delete e[n]), o = Et.cssHooks[i], o && "expand" in o) {
                s = o.expand(s), delete e[i];
                for (n in s) n in e || (e[n] = s[n], t[n] = r)
            } else t[i] = r
    }

    function J(e, t, n) {
        var i, r, s = 0,
            o = J.prefilters.length,
            a = Et.Deferred().always(function() {
                delete u.elem
            }),
            u = function() {
                if (r) return !1;
                for (var t = Cn || U(), n = Math.max(0, l.startTime + l.duration - t), i = n / l.duration || 0, s = 1 - i, o = 0, u = l.tweens.length; u > o; o++) l.tweens[o].run(s);
                return a.notifyWith(e, [l, s, n]), 1 > s && u ? n : (u || a.notifyWith(e, [l, 1, 0]), a.resolveWith(e, [l]), !1)
            },
            l = a.promise({
                elem: e,
                props: Et.extend({}, t),
                opts: Et.extend(!0, {
                    specialEasing: {},
                    easing: Et.easing._default
                }, n),
                originalProperties: t,
                originalOptions: n,
                startTime: Cn || U(),
                duration: n.duration,
                tweens: [],
                createTween: function(t, n) {
                    var i = Et.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                    return l.tweens.push(i), i
                },
                stop: function(t) {
                    var n = 0,
                        i = t ? l.tweens.length : 0;
                    if (r) return this;
                    for (r = !0; i > n; n++) l.tweens[n].run(1);
                    return t ? (a.notifyWith(e, [l, 1, 0]), a.resolveWith(e, [l, t])) : a.rejectWith(e, [l, t]), this
                }
            }),
            c = l.props;
        for (X(c, l.opts.specialEasing); o > s; s++)
            if (i = J.prefilters[s].call(l, e, c, l.opts)) return wt(i.stop) && (Et._queueHooks(l.elem, l.opts.queue).stop = i.stop.bind(i)), i;
        return Et.map(c, Y, l), wt(l.opts.start) && l.opts.start.call(e, l), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always), Et.fx.timer(Et.extend(u, {
            elem: e,
            anim: l,
            queue: l.opts.queue
        })), l
    }

    function Q(e) {
        var t = e.match(Nt) || [];
        return t.join(" ")
    }

    function Z(e) {
        return e.getAttribute && e.getAttribute("class") || ""
    }

    function et(e) {
        return Array.isArray(e) ? e : "string" == typeof e ? e.match(Nt) || [] : []
    }

    function tt(e, t, n, r) {
        var s;
        if (Array.isArray(t)) Et.each(t, function(t, i) {
            n || Rn.test(e) ? r(e, i) : tt(e + "[" + ("object" == typeof i && null != i ? t : "") + "]", i, n, r)
        });
        else if (n || "object" !== i(t)) r(e, t);
        else
            for (s in t) tt(e + "[" + s + "]", t[s], n, r)
    }

    function nt(e) {
        return function(t, n) {
            "string" != typeof t && (n = t, t = "*");
            var i, r = 0,
                s = t.toLowerCase().match(Nt) || [];
            if (wt(n))
                for (; i = s[r++];) "+" === i[0] ? (i = i.slice(1) || "*", (e[i] = e[i] || []).unshift(n)) : (e[i] = e[i] || []).push(n)
        }
    }

    function it(e, t, n, i) {
        function r(a) {
            var u;
            return s[a] = !0, Et.each(e[a] || [], function(e, a) {
                var l = a(t, n, i);
                return "string" != typeof l || o || s[l] ? o ? !(u = l) : void 0 : (t.dataTypes.unshift(l), r(l), !1)
            }), u
        }
        var s = {},
            o = e === Kn;
        return r(t.dataTypes[0]) || !s["*"] && r("*")
    }

    function rt(e, t) {
        var n, i, r = Et.ajaxSettings.flatOptions || {};
        for (n in t) void 0 !== t[n] && ((r[n] ? e : i || (i = {}))[n] = t[n]);
        return i && Et.extend(!0, e, i), e
    }

    function st(e, t, n) {
        for (var i, r, s, o, a = e.contents, u = e.dataTypes;
            "*" === u[0];) u.shift(), void 0 === i && (i = e.mimeType || t.getResponseHeader("Content-Type"));
        if (i)
            for (r in a)
                if (a[r] && a[r].test(i)) {
                    u.unshift(r);
                    break
                }
        if (u[0] in n) s = u[0];
        else {
            for (r in n) {
                if (!u[0] || e.converters[r + " " + u[0]]) {
                    s = r;
                    break
                }
                o || (o = r)
            }
            s = s || o
        }
        return s ? (s !== u[0] && u.unshift(s), n[s]) : void 0
    }

    function ot(e, t, n, i) {
        var r, s, o, a, u, l = {},
            c = e.dataTypes.slice();
        if (c[1])
            for (o in e.converters) l[o.toLowerCase()] = e.converters[o];
        for (s = c.shift(); s;)
            if (e.responseFields[s] && (n[e.responseFields[s]] = t), !u && i && e.dataFilter && (t = e.dataFilter(t, e.dataType)), u = s, s = c.shift())
                if ("*" === s) s = u;
                else if ("*" !== u && u !== s) {
            if (o = l[u + " " + s] || l["* " + s], !o)
                for (r in l)
                    if (a = r.split(" "), a[1] === s && (o = l[u + " " + a[0]] || l["* " + a[0]])) {
                        o === !0 ? o = l[r] : l[r] !== !0 && (s = a[0], c.unshift(a[1]));
                        break
                    }
            if (o !== !0)
                if (o && e["throws"]) t = o(t);
                else try {
                    t = o(t)
                } catch (d) {
                    return {
                        state: "parsererror",
                        error: o ? d : "No conversion from " + u + " to " + s
                    }
                }
        }
        return {
            state: "success",
            data: t
        }
    }
    var at = [],
        ut = Object.getPrototypeOf,
        lt = at.slice,
        ct = at.flat ? function(e) {
            return at.flat.call(e)
        } : function(e) {
            return at.concat.apply([], e)
        },
        dt = at.push,
        ft = at.indexOf,
        ht = {},
        pt = ht.toString,
        mt = ht.hasOwnProperty,
        gt = mt.toString,
        yt = gt.call(Object),
        vt = {},
        wt = function(e) {
            return "function" == typeof e && "number" != typeof e.nodeType
        },
        bt = function(e) {
            return null != e && e === e.window
        },
        _t = e.document,
        xt = {
            type: !0,
            src: !0,
            nonce: !0,
            noModule: !0
        },
        Ct = "3.5.1",
        Et = function(e, t) {
            return new Et.fn.init(e, t)
        };
    Et.fn = Et.prototype = {
        jquery: Ct,
        constructor: Et,
        length: 0,
        toArray: function() {
            return lt.call(this)
        },
        get: function(e) {
            return null == e ? lt.call(this) : 0 > e ? this[e + this.length] : this[e]
        },
        pushStack: function(e) {
            var t = Et.merge(this.constructor(), e);
            return t.prevObject = this, t
        },
        each: function(e) {
            return Et.each(this, e)
        },
        map: function(e) {
            return this.pushStack(Et.map(this, function(t, n) {
                return e.call(t, n, t)
            }))
        },
        slice: function() {
            return this.pushStack(lt.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        even: function() {
            return this.pushStack(Et.grep(this, function(e, t) {
                return (t + 1) % 2
            }))
        },
        odd: function() {
            return this.pushStack(Et.grep(this, function(e, t) {
                return t % 2
            }))
        },
        eq: function(e) {
            var t = this.length,
                n = +e + (0 > e ? t : 0);
            return this.pushStack(n >= 0 && t > n ? [this[n]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor()
        },
        push: dt,
        sort: at.sort,
        splice: at.splice
    }, Et.extend = Et.fn.extend = function() {
        var e, t, n, i, r, s, o = arguments[0] || {},
            a = 1,
            u = arguments.length,
            l = !1;
        for ("boolean" == typeof o && (l = o, o = arguments[a] || {}, a++), "object" == typeof o || wt(o) || (o = {}), a === u && (o = this, a--); u > a; a++)
            if (null != (e = arguments[a]))
                for (t in e) i = e[t], "__proto__" !== t && o !== i && (l && i && (Et.isPlainObject(i) || (r = Array.isArray(i))) ? (n = o[t], s = r && !Array.isArray(n) ? [] : r || Et.isPlainObject(n) ? n : {}, r = !1, o[t] = Et.extend(l, s, i)) : void 0 !== i && (o[t] = i));
        return o
    }, Et.extend({
        expando: "jQuery" + (Ct + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(e) {
            throw new Error(e)
        },
        noop: function() {},
        isPlainObject: function(e) {
            var t, n;
            return e && "[object Object]" === pt.call(e) ? (t = ut(e)) ? (n = mt.call(t, "constructor") && t.constructor, "function" == typeof n && gt.call(n) === yt) : !0 : !1
        },
        isEmptyObject: function(e) {
            var t;
            for (t in e) return !1;
            return !0
        },
        globalEval: function(e, t, i) {
            n(e, {
                nonce: t && t.nonce
            }, i)
        },
        each: function(e, t) {
            var n, i = 0;
            if (r(e))
                for (n = e.length; n > i && t.call(e[i], i, e[i]) !== !1; i++);
            else
                for (i in e)
                    if (t.call(e[i], i, e[i]) === !1) break;
            return e
        },
        makeArray: function(e, t) {
            var n = t || [];
            return null != e && (r(Object(e)) ? Et.merge(n, "string" == typeof e ? [e] : e) : dt.call(n, e)), n
        },
        inArray: function(e, t, n) {
            return null == t ? -1 : ft.call(t, e, n)
        },
        merge: function(e, t) {
            for (var n = +t.length, i = 0, r = e.length; n > i; i++) e[r++] = t[i];
            return e.length = r, e
        },
        grep: function(e, t, n) {
            for (var i, r = [], s = 0, o = e.length, a = !n; o > s; s++) i = !t(e[s], s), i !== a && r.push(e[s]);
            return r
        },
        map: function(e, t, n) {
            var i, s, o = 0,
                a = [];
            if (r(e))
                for (i = e.length; i > o; o++) s = t(e[o], o, n), null != s && a.push(s);
            else
                for (o in e) s = t(e[o], o, n), null != s && a.push(s);
            return ct(a)
        },
        guid: 1,
        support: vt
    }), "function" == typeof Symbol && (Et.fn[Symbol.iterator] = at[Symbol.iterator]), Et.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(e, t) {
        ht["[object " + t + "]"] = t.toLowerCase()
    });
    var Ft = function(e) {
        function t(e, t, n, i) {
            var r, s, o, a, u, l, c, f = t && t.ownerDocument,
                p = t ? t.nodeType : 9;
            if (n = n || [], "string" != typeof e || !e || 1 !== p && 9 !== p && 11 !== p) return n;
            if (!i && (O(t), t = t || P, N)) {
                if (11 !== p && (u = wt.exec(e)))
                    if (r = u[1]) {
                        if (9 === p) {
                            if (!(o = t.getElementById(r))) return n;
                            if (o.id === r) return n.push(o), n
                        } else if (f && (o = f.getElementById(r)) && I(t, o) && o.id === r) return n.push(o), n
                    } else {
                        if (u[2]) return Z.apply(n, t.getElementsByTagName(e)), n;
                        if ((r = u[3]) && x.getElementsByClassName && t.getElementsByClassName) return Z.apply(n, t.getElementsByClassName(r)), n
                    }
                if (!(!x.qsa || G[e + " "] || q && q.test(e) || 1 === p && "object" === t.nodeName.toLowerCase())) {
                    if (c = e, f = t, 1 === p && (dt.test(e) || ct.test(e))) {
                        for (f = bt.test(e) && d(t.parentNode) || t, f === t && x.scope || ((a = t.getAttribute("id")) ? a = a.replace(Ct, Et) : t.setAttribute("id", a = L)), l = T(e), s = l.length; s--;) l[s] = (a ? "#" + a : ":scope") + " " + h(l[s]);
                        c = l.join(",")
                    }
                    try {
                        return Z.apply(n, f.querySelectorAll(c)), n
                    } catch (m) {
                        G(e, !0)
                    } finally {
                        a === L && t.removeAttribute("id")
                    }
                }
            }
            return $(e.replace(ut, "$1"), t, n, i)
        }

        function n() {
            function e(n, i) {
                return t.push(n + " ") > C.cacheLength && delete e[t.shift()], e[n + " "] = i
            }
            var t = [];
            return e
        }

        function i(e) {
            return e[L] = !0, e
        }

        function r(e) {
            var t = P.createElement("fieldset");
            try {
                return !!e(t)
            } catch (n) {
                return !1
            } finally {
                t.parentNode && t.parentNode.removeChild(t), t = null
            }
        }

        function s(e, t) {
            for (var n = e.split("|"), i = n.length; i--;) C.attrHandle[n[i]] = t
        }

        function o(e, t) {
            var n = t && e,
                i = n && 1 === e.nodeType && 1 === t.nodeType && e.sourceIndex - t.sourceIndex;
            if (i) return i;
            if (n)
                for (; n = n.nextSibling;)
                    if (n === t) return -1;
            return e ? 1 : -1
        }

        function a(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return "input" === n && t.type === e
            }
        }

        function u(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return ("input" === n || "button" === n) && t.type === e
            }
        }

        function l(e) {
            return function(t) {
                return "form" in t ? t.parentNode && t.disabled === !1 ? "label" in t ? "label" in t.parentNode ? t.parentNode.disabled === e : t.disabled === e : t.isDisabled === e || t.isDisabled !== !e && Tt(t) === e : t.disabled === e : "label" in t ? t.disabled === e : !1
            }
        }

        function c(e) {
            return i(function(t) {
                return t = +t, i(function(n, i) {
                    for (var r, s = e([], n.length, t), o = s.length; o--;) n[r = s[o]] && (n[r] = !(i[r] = n[r]))
                })
            })
        }

        function d(e) {
            return e && "undefined" != typeof e.getElementsByTagName && e
        }

        function f() {}

        function h(e) {
            for (var t = 0, n = e.length, i = ""; n > t; t++) i += e[t].value;
            return i
        }

        function p(e, t, n) {
            var i = t.dir,
                r = t.next,
                s = r || i,
                o = n && "parentNode" === s,
                a = B++;
            return t.first ? function(t, n, r) {
                for (; t = t[i];)
                    if (1 === t.nodeType || o) return e(t, n, r);
                return !1
            } : function(t, n, u) {
                var l, c, d, f = [H, a];
                if (u) {
                    for (; t = t[i];)
                        if ((1 === t.nodeType || o) && e(t, n, u)) return !0
                } else
                    for (; t = t[i];)
                        if (1 === t.nodeType || o)
                            if (d = t[L] || (t[L] = {}), c = d[t.uniqueID] || (d[t.uniqueID] = {}), r && r === t.nodeName.toLowerCase()) t = t[i] || t;
                            else {
                                if ((l = c[s]) && l[0] === H && l[1] === a) return f[2] = l[2];
                                if (c[s] = f, f[2] = e(t, n, u)) return !0
                            } return !1
            }
        }

        function m(e) {
            return e.length > 1 ? function(t, n, i) {
                for (var r = e.length; r--;)
                    if (!e[r](t, n, i)) return !1;
                return !0
            } : e[0]
        }

        function g(e, n, i) {
            for (var r = 0, s = n.length; s > r; r++) t(e, n[r], i);
            return i
        }

        function y(e, t, n, i, r) {
            for (var s, o = [], a = 0, u = e.length, l = null != t; u > a; a++)(s = e[a]) && (!n || n(s, i, r)) && (o.push(s), l && t.push(a));
            return o
        }

        function v(e, t, n, r, s, o) {
            return r && !r[L] && (r = v(r)), s && !s[L] && (s = v(s, o)), i(function(i, o, a, u) {
                var l, c, d, f = [],
                    h = [],
                    p = o.length,
                    m = i || g(t || "*", a.nodeType ? [a] : a, []),
                    v = !e || !i && t ? m : y(m, f, e, a, u),
                    w = n ? s || (i ? e : p || r) ? [] : o : v;
                if (n && n(v, w, a, u), r)
                    for (l = y(w, h), r(l, [], a, u), c = l.length; c--;)(d = l[c]) && (w[h[c]] = !(v[h[c]] = d));
                if (i) {
                    if (s || e) {
                        if (s) {
                            for (l = [], c = w.length; c--;)(d = w[c]) && l.push(v[c] = d);
                            s(null, w = [], l, u)
                        }
                        for (c = w.length; c--;)(d = w[c]) && (l = s ? tt(i, d) : f[c]) > -1 && (i[l] = !(o[l] = d))
                    }
                } else w = y(w === o ? w.splice(p, w.length) : w), s ? s(null, o, w, u) : Z.apply(o, w)
            })
        }

        function w(e) {
            for (var t, n, i, r = e.length, s = C.relative[e[0].type], o = s || C.relative[" "], a = s ? 1 : 0, u = p(function(e) {
                    return e === t
                }, o, !0), l = p(function(e) {
                    return tt(t, e) > -1
                }, o, !0), c = [function(e, n, i) {
                    var r = !s && (i || n !== S) || ((t = n).nodeType ? u(e, n, i) : l(e, n, i));
                    return t = null, r
                }]; r > a; a++)
                if (n = C.relative[e[a].type]) c = [p(m(c), n)];
                else {
                    if (n = C.filter[e[a].type].apply(null, e[a].matches), n[L]) {
                        for (i = ++a; r > i && !C.relative[e[i].type]; i++);
                        return v(a > 1 && m(c), a > 1 && h(e.slice(0, a - 1).concat({
                            value: " " === e[a - 2].type ? "*" : ""
                        })).replace(ut, "$1"), n, i > a && w(e.slice(a, i)), r > i && w(e = e.slice(i)), r > i && h(e))
                    }
                    c.push(n)
                }
            return m(c)
        }

        function b(e, n) {
            var r = n.length > 0,
                s = e.length > 0,
                o = function(i, o, a, u, l) {
                    var c, d, f, h = 0,
                        p = "0",
                        m = i && [],
                        g = [],
                        v = S,
                        w = i || s && C.find.TAG("*", l),
                        b = H += null == v ? 1 : Math.random() || .1,
                        _ = w.length;
                    for (l && (S = o == P || o || l); p !== _ && null != (c = w[p]); p++) {
                        if (s && c) {
                            for (d = 0, o || c.ownerDocument == P || (O(c), a = !N); f = e[d++];)
                                if (f(c, o || P, a)) {
                                    u.push(c);
                                    break
                                }
                            l && (H = b)
                        }
                        r && ((c = !f && c) && h--, i && m.push(c))
                    }
                    if (h += p, r && p !== h) {
                        for (d = 0; f = n[d++];) f(m, g, o, a);
                        if (i) {
                            if (h > 0)
                                for (; p--;) m[p] || g[p] || (g[p] = J.call(u));
                            g = y(g)
                        }
                        Z.apply(u, g), l && !i && g.length > 0 && h + n.length > 1 && t.uniqueSort(u)
                    }
                    return l && (H = b, S = v), m
                };
            return r ? i(o) : o
        }
        var _, x, C, E, F, T, k, $, S, j, A, O, P, D, N, q, R, M, I, L = "sizzle" + 1 * new Date,
            V = e.document,
            H = 0,
            B = 0,
            W = n(),
            z = n(),
            U = n(),
            G = n(),
            Y = function(e, t) {
                return e === t && (A = !0), 0
            },
            K = {}.hasOwnProperty,
            X = [],
            J = X.pop,
            Q = X.push,
            Z = X.push,
            et = X.slice,
            tt = function(e, t) {
                for (var n = 0, i = e.length; i > n; n++)
                    if (e[n] === t) return n;
                return -1
            },
            nt = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            it = "[\\x20\\t\\r\\n\\f]",
            rt = "(?:\\\\[\\da-fA-F]{1,6}" + it + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\x00-\\x7f])+",
            st = "\\[" + it + "*(" + rt + ")(?:" + it + "*([*^$|!~]?=)" + it + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + rt + "))|)" + it + "*\\]",
            ot = ":(" + rt + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + st + ")*)|.*)\\)|)",
            at = new RegExp(it + "+", "g"),
            ut = new RegExp("^" + it + "+|((?:^|[^\\\\])(?:\\\\.)*)" + it + "+$", "g"),
            lt = new RegExp("^" + it + "*," + it + "*"),
            ct = new RegExp("^" + it + "*([>+~]|" + it + ")" + it + "*"),
            dt = new RegExp(it + "|>"),
            ft = new RegExp(ot),
            ht = new RegExp("^" + rt + "$"),
            pt = {
                ID: new RegExp("^#(" + rt + ")"),
                CLASS: new RegExp("^\\.(" + rt + ")"),
                TAG: new RegExp("^(" + rt + "|[*])"),
                ATTR: new RegExp("^" + st),
                PSEUDO: new RegExp("^" + ot),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + it + "*(even|odd|(([+-]|)(\\d*)n|)" + it + "*(?:([+-]|)" + it + "*(\\d+)|))" + it + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + nt + ")$", "i"),
                needsContext: new RegExp("^" + it + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + it + "*((?:-\\d)?\\d*)" + it + "*\\)|)(?=[^-]|$)", "i")
            },
            mt = /HTML$/i,
            gt = /^(?:input|select|textarea|button)$/i,
            yt = /^h\d$/i,
            vt = /^[^{]+\{\s*\[native \w/,
            wt = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            bt = /[+~]/,
            _t = new RegExp("\\\\[\\da-fA-F]{1,6}" + it + "?|\\\\([^\\r\\n\\f])", "g"),
            xt = function(e, t) {
                var n = "0x" + e.slice(1) - 65536;
                return t ? t : 0 > n ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320)
            },
            Ct = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
            Et = function(e, t) {
                return t ? "\x00" === e ? "\ufffd" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e
            },
            Ft = function() {
                O()
            },
            Tt = p(function(e) {
                return e.disabled === !0 && "fieldset" === e.nodeName.toLowerCase()
            }, {
                dir: "parentNode",
                next: "legend"
            });
        try {
            Z.apply(X = et.call(V.childNodes), V.childNodes), X[V.childNodes.length].nodeType
        } catch (kt) {
            Z = {
                apply: X.length ? function(e, t) {
                    Q.apply(e, et.call(t))
                } : function(e, t) {
                    for (var n = e.length, i = 0; e[n++] = t[i++];);
                    e.length = n - 1
                }
            }
        }
        x = t.support = {}, F = t.isXML = function(e) {
            var t = e.namespaceURI,
                n = (e.ownerDocument || e).documentElement;
            return !mt.test(t || n && n.nodeName || "HTML")
        }, O = t.setDocument = function(e) {
            var t, n, i = e ? e.ownerDocument || e : V;
            return i != P && 9 === i.nodeType && i.documentElement ? (P = i, D = P.documentElement, N = !F(P), V != P && (n = P.defaultView) && n.top !== n && (n.addEventListener ? n.addEventListener("unload", Ft, !1) : n.attachEvent && n.attachEvent("onunload", Ft)), x.scope = r(function(e) {
                return D.appendChild(e).appendChild(P.createElement("div")), "undefined" != typeof e.querySelectorAll && !e.querySelectorAll(":scope fieldset div").length
            }), x.attributes = r(function(e) {
                return e.className = "i", !e.getAttribute("className")
            }), x.getElementsByTagName = r(function(e) {
                return e.appendChild(P.createComment("")), !e.getElementsByTagName("*").length
            }), x.getElementsByClassName = vt.test(P.getElementsByClassName), x.getById = r(function(e) {
                return D.appendChild(e).id = L, !P.getElementsByName || !P.getElementsByName(L).length
            }), x.getById ? (C.filter.ID = function(e) {
                var t = e.replace(_t, xt);
                return function(e) {
                    return e.getAttribute("id") === t
                }
            }, C.find.ID = function(e, t) {
                if ("undefined" != typeof t.getElementById && N) {
                    var n = t.getElementById(e);
                    return n ? [n] : []
                }
            }) : (C.filter.ID = function(e) {
                var t = e.replace(_t, xt);
                return function(e) {
                    var n = "undefined" != typeof e.getAttributeNode && e.getAttributeNode("id");
                    return n && n.value === t
                }
            }, C.find.ID = function(e, t) {
                if ("undefined" != typeof t.getElementById && N) {
                    var n, i, r, s = t.getElementById(e);
                    if (s) {
                        if (n = s.getAttributeNode("id"), n && n.value === e) return [s];
                        for (r = t.getElementsByName(e), i = 0; s = r[i++];)
                            if (n = s.getAttributeNode("id"), n && n.value === e) return [s]
                    }
                    return []
                }
            }), C.find.TAG = x.getElementsByTagName ? function(e, t) {
                return "undefined" != typeof t.getElementsByTagName ? t.getElementsByTagName(e) : x.qsa ? t.querySelectorAll(e) : void 0
            } : function(e, t) {
                var n, i = [],
                    r = 0,
                    s = t.getElementsByTagName(e);
                if ("*" === e) {
                    for (; n = s[r++];) 1 === n.nodeType && i.push(n);
                    return i
                }
                return s
            }, C.find.CLASS = x.getElementsByClassName && function(e, t) {
                return "undefined" != typeof t.getElementsByClassName && N ? t.getElementsByClassName(e) : void 0
            }, R = [], q = [], (x.qsa = vt.test(P.querySelectorAll)) && (r(function(e) {
                var t;
                D.appendChild(e).innerHTML = "<a id='" + L + "'></a><select id='" + L + "-\r\\' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && q.push("[*^$]=" + it + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || q.push("\\[" + it + "*(?:value|" + nt + ")"), e.querySelectorAll("[id~=" + L + "-]").length || q.push("~="), t = P.createElement("input"), t.setAttribute("name", ""), e.appendChild(t), e.querySelectorAll("[name='']").length || q.push("\\[" + it + "*name" + it + "*=" + it + "*(?:''|\"\")"), e.querySelectorAll(":checked").length || q.push(":checked"), e.querySelectorAll("a#" + L + "+*").length || q.push(".#.+[+~]"), e.querySelectorAll("\\\f"), q.push("[\\r\\n\\f]")
            }), r(function(e) {
                e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                var t = P.createElement("input");
                t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && q.push("name" + it + "*[*^$|!~]?="), 2 !== e.querySelectorAll(":enabled").length && q.push(":enabled", ":disabled"), D.appendChild(e).disabled = !0, 2 !== e.querySelectorAll(":disabled").length && q.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), q.push(",.*:")
            })), (x.matchesSelector = vt.test(M = D.matches || D.webkitMatchesSelector || D.mozMatchesSelector || D.oMatchesSelector || D.msMatchesSelector)) && r(function(e) {
                x.disconnectedMatch = M.call(e, "*"), M.call(e, "[s!='']:x"), R.push("!=", ot)
            }), q = q.length && new RegExp(q.join("|")), R = R.length && new RegExp(R.join("|")), t = vt.test(D.compareDocumentPosition), I = t || vt.test(D.contains) ? function(e, t) {
                var n = 9 === e.nodeType ? e.documentElement : e,
                    i = t && t.parentNode;
                return e === i || !(!i || 1 !== i.nodeType || !(n.contains ? n.contains(i) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(i)))
            } : function(e, t) {
                if (t)
                    for (; t = t.parentNode;)
                        if (t === e) return !0;
                return !1
            }, Y = t ? function(e, t) {
                if (e === t) return A = !0, 0;
                var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                return n ? n : (n = (e.ownerDocument || e) == (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, 1 & n || !x.sortDetached && t.compareDocumentPosition(e) === n ? e == P || e.ownerDocument == V && I(V, e) ? -1 : t == P || t.ownerDocument == V && I(V, t) ? 1 : j ? tt(j, e) - tt(j, t) : 0 : 4 & n ? -1 : 1)
            } : function(e, t) {
                if (e === t) return A = !0, 0;
                var n, i = 0,
                    r = e.parentNode,
                    s = t.parentNode,
                    a = [e],
                    u = [t];
                if (!r || !s) return e == P ? -1 : t == P ? 1 : r ? -1 : s ? 1 : j ? tt(j, e) - tt(j, t) : 0;
                if (r === s) return o(e, t);
                for (n = e; n = n.parentNode;) a.unshift(n);
                for (n = t; n = n.parentNode;) u.unshift(n);
                for (; a[i] === u[i];) i++;
                return i ? o(a[i], u[i]) : a[i] == V ? -1 : u[i] == V ? 1 : 0
            }, P) : P
        }, t.matches = function(e, n) {
            return t(e, null, null, n)
        }, t.matchesSelector = function(e, n) {
            if (O(e), !(!x.matchesSelector || !N || G[n + " "] || R && R.test(n) || q && q.test(n))) try {
                var i = M.call(e, n);
                if (i || x.disconnectedMatch || e.document && 11 !== e.document.nodeType) return i
            } catch (r) {
                G(n, !0)
            }
            return t(n, P, null, [e]).length > 0
        }, t.contains = function(e, t) {
            return (e.ownerDocument || e) != P && O(e), I(e, t)
        }, t.attr = function(e, t) {
            (e.ownerDocument || e) != P && O(e);
            var n = C.attrHandle[t.toLowerCase()],
                i = n && K.call(C.attrHandle, t.toLowerCase()) ? n(e, t, !N) : void 0;
            return void 0 !== i ? i : x.attributes || !N ? e.getAttribute(t) : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
        }, t.escape = function(e) {
            return (e + "").replace(Ct, Et)
        }, t.error = function(e) {
            throw new Error("Syntax error, unrecognized expression: " + e)
        }, t.uniqueSort = function(e) {
            var t, n = [],
                i = 0,
                r = 0;
            if (A = !x.detectDuplicates, j = !x.sortStable && e.slice(0), e.sort(Y), A) {
                for (; t = e[r++];) t === e[r] && (i = n.push(r));
                for (; i--;) e.splice(n[i], 1)
            }
            return j = null, e
        }, E = t.getText = function(e) {
            var t, n = "",
                i = 0,
                r = e.nodeType;
            if (r) {
                if (1 === r || 9 === r || 11 === r) {
                    if ("string" == typeof e.textContent) return e.textContent;
                    for (e = e.firstChild; e; e = e.nextSibling) n += E(e)
                } else if (3 === r || 4 === r) return e.nodeValue
            } else
                for (; t = e[i++];) n += E(t);
            return n
        }, C = t.selectors = {
            cacheLength: 50,
            createPseudo: i,
            match: pt,
            attrHandle: {},
            find: {},
            relative: {
                ">": {
                    dir: "parentNode",
                    first: !0
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: !0
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function(e) {
                    return e[1] = e[1].replace(_t, xt), e[3] = (e[3] || e[4] || e[5] || "").replace(_t, xt), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                },
                CHILD: function(e) {
                    return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && t.error(e[0]), e
                },
                PSEUDO: function(e) {
                    var t, n = !e[6] && e[2];
                    return pt.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && ft.test(n) && (t = T(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                }
            },
            filter: {
                TAG: function(e) {
                    var t = e.replace(_t, xt).toLowerCase();
                    return "*" === e ? function() {
                        return !0
                    } : function(e) {
                        return e.nodeName && e.nodeName.toLowerCase() === t
                    }
                },
                CLASS: function(e) {
                    var t = W[e + " "];
                    return t || (t = new RegExp("(^|" + it + ")" + e + "(" + it + "|$)")) && W(e, function(e) {
                        return t.test("string" == typeof e.className && e.className || "undefined" != typeof e.getAttribute && e.getAttribute("class") || "")
                    })
                },
                ATTR: function(e, n, i) {
                    return function(r) {
                        var s = t.attr(r, e);
                        return null == s ? "!=" === n : n ? (s += "", "=" === n ? s === i : "!=" === n ? s !== i : "^=" === n ? i && 0 === s.indexOf(i) : "*=" === n ? i && s.indexOf(i) > -1 : "$=" === n ? i && s.slice(-i.length) === i : "~=" === n ? (" " + s.replace(at, " ") + " ").indexOf(i) > -1 : "|=" === n ? s === i || s.slice(0, i.length + 1) === i + "-" : !1) : !0
                    }
                },
                CHILD: function(e, t, n, i, r) {
                    var s = "nth" !== e.slice(0, 3),
                        o = "last" !== e.slice(-4),
                        a = "of-type" === t;
                    return 1 === i && 0 === r ? function(e) {
                        return !!e.parentNode
                    } : function(t, n, u) {
                        var l, c, d, f, h, p, m = s !== o ? "nextSibling" : "previousSibling",
                            g = t.parentNode,
                            y = a && t.nodeName.toLowerCase(),
                            v = !u && !a,
                            w = !1;
                        if (g) {
                            if (s) {
                                for (; m;) {
                                    for (f = t; f = f[m];)
                                        if (a ? f.nodeName.toLowerCase() === y : 1 === f.nodeType) return !1;
                                    p = m = "only" === e && !p && "nextSibling"
                                }
                                return !0
                            }
                            if (p = [o ? g.firstChild : g.lastChild], o && v) {
                                for (f = g, d = f[L] || (f[L] = {}), c = d[f.uniqueID] || (d[f.uniqueID] = {}), l = c[e] || [], h = l[0] === H && l[1], w = h && l[2], f = h && g.childNodes[h]; f = ++h && f && f[m] || (w = h = 0) || p.pop();)
                                    if (1 === f.nodeType && ++w && f === t) {
                                        c[e] = [H, h, w];
                                        break
                                    }
                            } else if (v && (f = t, d = f[L] || (f[L] = {}), c = d[f.uniqueID] || (d[f.uniqueID] = {}), l = c[e] || [], h = l[0] === H && l[1], w = h), w === !1)
                                for (;
                                    (f = ++h && f && f[m] || (w = h = 0) || p.pop()) && ((a ? f.nodeName.toLowerCase() !== y : 1 !== f.nodeType) || !++w || (v && (d = f[L] || (f[L] = {}), c = d[f.uniqueID] || (d[f.uniqueID] = {}), c[e] = [H, w]), f !== t)););
                            return w -= r, w === i || w % i === 0 && w / i >= 0
                        }
                    }
                },
                PSEUDO: function(e, n) {
                    var r, s = C.pseudos[e] || C.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
                    return s[L] ? s(n) : s.length > 1 ? (r = [e, e, "", n], C.setFilters.hasOwnProperty(e.toLowerCase()) ? i(function(e, t) {
                        for (var i, r = s(e, n), o = r.length; o--;) i = tt(e, r[o]), e[i] = !(t[i] = r[o])
                    }) : function(e) {
                        return s(e, 0, r)
                    }) : s
                }
            },
            pseudos: {
                not: i(function(e) {
                    var t = [],
                        n = [],
                        r = k(e.replace(ut, "$1"));
                    return r[L] ? i(function(e, t, n, i) {
                        for (var s, o = r(e, null, i, []), a = e.length; a--;)(s = o[a]) && (e[a] = !(t[a] = s))
                    }) : function(e, i, s) {
                        return t[0] = e, r(t, null, s, n), t[0] = null, !n.pop()
                    }
                }),
                has: i(function(e) {
                    return function(n) {
                        return t(e, n).length > 0
                    }
                }),
                contains: i(function(e) {
                    return e = e.replace(_t, xt),
                        function(t) {
                            return (t.textContent || E(t)).indexOf(e) > -1
                        }
                }),
                lang: i(function(e) {
                    return ht.test(e || "") || t.error("unsupported lang: " + e), e = e.replace(_t, xt).toLowerCase(),
                        function(t) {
                            var n;
                            do
                                if (n = N ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(), n === e || 0 === n.indexOf(e + "-"); while ((t = t.parentNode) && 1 === t.nodeType);
                            return !1
                        }
                }),
                target: function(t) {
                    var n = e.location && e.location.hash;
                    return n && n.slice(1) === t.id
                },
                root: function(e) {
                    return e === D
                },
                focus: function(e) {
                    return e === P.activeElement && (!P.hasFocus || P.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                },
                enabled: l(!1),
                disabled: l(!0),
                checked: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return "input" === t && !!e.checked || "option" === t && !!e.selected
                },
                selected: function(e) {
                    return e.parentNode && e.parentNode.selectedIndex, e.selected === !0
                },
                empty: function(e) {
                    for (e = e.firstChild; e; e = e.nextSibling)
                        if (e.nodeType < 6) return !1;
                    return !0
                },
                parent: function(e) {
                    return !C.pseudos.empty(e)
                },
                header: function(e) {
                    return yt.test(e.nodeName)
                },
                input: function(e) {
                    return gt.test(e.nodeName)
                },
                button: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return "input" === t && "button" === e.type || "button" === t
                },
                text: function(e) {
                    var t;
                    return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                },
                first: c(function() {
                    return [0]
                }),
                last: c(function(e, t) {
                    return [t - 1]
                }),
                eq: c(function(e, t, n) {
                    return [0 > n ? n + t : n]
                }),
                even: c(function(e, t) {
                    for (var n = 0; t > n; n += 2) e.push(n);
                    return e
                }),
                odd: c(function(e, t) {
                    for (var n = 1; t > n; n += 2) e.push(n);
                    return e
                }),
                lt: c(function(e, t, n) {
                    for (var i = 0 > n ? n + t : n > t ? t : n; --i >= 0;) e.push(i);
                    return e
                }),
                gt: c(function(e, t, n) {
                    for (var i = 0 > n ? n + t : n; ++i < t;) e.push(i);
                    return e
                })
            }
        }, C.pseudos.nth = C.pseudos.eq;
        for (_ in {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) C.pseudos[_] = a(_);
        for (_ in {
                submit: !0,
                reset: !0
            }) C.pseudos[_] = u(_);
        return f.prototype = C.filters = C.pseudos, C.setFilters = new f, T = t.tokenize = function(e, n) {
            var i, r, s, o, a, u, l, c = z[e + " "];
            if (c) return n ? 0 : c.slice(0);
            for (a = e, u = [], l = C.preFilter; a;) {
                (!i || (r = lt.exec(a))) && (r && (a = a.slice(r[0].length) || a), u.push(s = [])), i = !1, (r = ct.exec(a)) && (i = r.shift(), s.push({
                    value: i,
                    type: r[0].replace(ut, " ")
                }), a = a.slice(i.length));
                for (o in C.filter) !(r = pt[o].exec(a)) || l[o] && !(r = l[o](r)) || (i = r.shift(), s.push({
                    value: i,
                    type: o,
                    matches: r
                }), a = a.slice(i.length));
                if (!i) break
            }
            return n ? a.length : a ? t.error(e) : z(e, u).slice(0)
        }, k = t.compile = function(e, t) {
            var n, i = [],
                r = [],
                s = U[e + " "];
            if (!s) {
                for (t || (t = T(e)), n = t.length; n--;) s = w(t[n]), s[L] ? i.push(s) : r.push(s);
                s = U(e, b(r, i)), s.selector = e
            }
            return s
        }, $ = t.select = function(e, t, n, i) {
            var r, s, o, a, u, l = "function" == typeof e && e,
                c = !i && T(e = l.selector || e);
            if (n = n || [], 1 === c.length) {
                if (s = c[0] = c[0].slice(0), s.length > 2 && "ID" === (o = s[0]).type && 9 === t.nodeType && N && C.relative[s[1].type]) {
                    if (t = (C.find.ID(o.matches[0].replace(_t, xt), t) || [])[0], !t) return n;
                    l && (t = t.parentNode), e = e.slice(s.shift().value.length)
                }
                for (r = pt.needsContext.test(e) ? 0 : s.length; r-- && (o = s[r], !C.relative[a = o.type]);)
                    if ((u = C.find[a]) && (i = u(o.matches[0].replace(_t, xt), bt.test(s[0].type) && d(t.parentNode) || t))) {
                        if (s.splice(r, 1), e = i.length && h(s), !e) return Z.apply(n, i), n;
                        break
                    }
            }
            return (l || k(e, c))(i, t, !N, n, !t || bt.test(e) && d(t.parentNode) || t), n
        }, x.sortStable = L.split("").sort(Y).join("") === L, x.detectDuplicates = !!A, O(), x.sortDetached = r(function(e) {
            return 1 & e.compareDocumentPosition(P.createElement("fieldset"))
        }), r(function(e) {
            return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
        }) || s("type|href|height|width", function(e, t, n) {
            return n ? void 0 : e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
        }), x.attributes && r(function(e) {
            return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
        }) || s("value", function(e, t, n) {
            return n || "input" !== e.nodeName.toLowerCase() ? void 0 : e.defaultValue
        }), r(function(e) {
            return null == e.getAttribute("disabled")
        }) || s(nt, function(e, t, n) {
            var i;
            return n ? void 0 : e[t] === !0 ? t.toLowerCase() : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
        }), t
    }(e);
    Et.find = Ft, Et.expr = Ft.selectors, Et.expr[":"] = Et.expr.pseudos, Et.uniqueSort = Et.unique = Ft.uniqueSort, Et.text = Ft.getText, Et.isXMLDoc = Ft.isXML, Et.contains = Ft.contains, Et.escapeSelector = Ft.escape;
    var Tt = function(e, t, n) {
            for (var i = [], r = void 0 !== n;
                (e = e[t]) && 9 !== e.nodeType;)
                if (1 === e.nodeType) {
                    if (r && Et(e).is(n)) break;
                    i.push(e)
                }
            return i
        },
        kt = function(e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        },
        $t = Et.expr.match.needsContext,
        St = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
    Et.filter = function(e, t, n) {
        var i = t[0];
        return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === i.nodeType ? Et.find.matchesSelector(i, e) ? [i] : [] : Et.find.matches(e, Et.grep(t, function(e) {
            return 1 === e.nodeType
        }))
    }, Et.fn.extend({
        find: function(e) {
            var t, n, i = this.length,
                r = this;
            if ("string" != typeof e) return this.pushStack(Et(e).filter(function() {
                for (t = 0; i > t; t++)
                    if (Et.contains(r[t], this)) return !0
            }));
            for (n = this.pushStack([]), t = 0; i > t; t++) Et.find(e, r[t], n);
            return i > 1 ? Et.uniqueSort(n) : n
        },
        filter: function(e) {
            return this.pushStack(o(this, e || [], !1))
        },
        not: function(e) {
            return this.pushStack(o(this, e || [], !0))
        },
        is: function(e) {
            return !!o(this, "string" == typeof e && $t.test(e) ? Et(e) : e || [], !1).length
        }
    });
    var jt, At = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,
        Ot = Et.fn.init = function(e, t, n) {
            var i, r;
            if (!e) return this;
            if (n = n || jt, "string" == typeof e) {
                if (i = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : At.exec(e), !i || !i[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
                if (i[1]) {
                    if (t = t instanceof Et ? t[0] : t, Et.merge(this, Et.parseHTML(i[1], t && t.nodeType ? t.ownerDocument || t : _t, !0)), St.test(i[1]) && Et.isPlainObject(t))
                        for (i in t) wt(this[i]) ? this[i](t[i]) : this.attr(i, t[i]);
                    return this
                }
                return r = _t.getElementById(i[2]), r && (this[0] = r, this.length = 1), this
            }
            return e.nodeType ? (this[0] = e, this.length = 1, this) : wt(e) ? void 0 !== n.ready ? n.ready(e) : e(Et) : Et.makeArray(e, this)
        };
    Ot.prototype = Et.fn, jt = Et(_t);
    var Pt = /^(?:parents|prev(?:Until|All))/,
        Dt = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    Et.fn.extend({
        has: function(e) {
            var t = Et(e, this),
                n = t.length;
            return this.filter(function() {
                for (var e = 0; n > e; e++)
                    if (Et.contains(this, t[e])) return !0
            })
        },
        closest: function(e, t) {
            var n, i = 0,
                r = this.length,
                s = [],
                o = "string" != typeof e && Et(e);
            if (!$t.test(e))
                for (; r > i; i++)
                    for (n = this[i]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (o ? o.index(n) > -1 : 1 === n.nodeType && Et.find.matchesSelector(n, e))) {
                            s.push(n);
                            break
                        }
            return this.pushStack(s.length > 1 ? Et.uniqueSort(s) : s)
        },
        index: function(e) {
            return e ? "string" == typeof e ? ft.call(Et(e), this[0]) : ft.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(e, t) {
            return this.pushStack(Et.uniqueSort(Et.merge(this.get(), Et(e, t))))
        },
        addBack: function(e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), Et.each({
        parent: function(e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t : null
        },
        parents: function(e) {
            return Tt(e, "parentNode")
        },
        parentsUntil: function(e, t, n) {
            return Tt(e, "parentNode", n)
        },
        next: function(e) {
            return a(e, "nextSibling")
        },
        prev: function(e) {
            return a(e, "previousSibling")
        },
        nextAll: function(e) {
            return Tt(e, "nextSibling")
        },
        prevAll: function(e) {
            return Tt(e, "previousSibling")
        },
        nextUntil: function(e, t, n) {
            return Tt(e, "nextSibling", n)
        },
        prevUntil: function(e, t, n) {
            return Tt(e, "previousSibling", n)
        },
        siblings: function(e) {
            return kt((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return kt(e.firstChild)
        },
        contents: function(e) {
            return null != e.contentDocument && ut(e.contentDocument) ? e.contentDocument : (s(e, "template") && (e = e.content || e), Et.merge([], e.childNodes))
        }
    }, function(e, t) {
        Et.fn[e] = function(n, i) {
            var r = Et.map(this, t, n);
            return "Until" !== e.slice(-5) && (i = n), i && "string" == typeof i && (r = Et.filter(i, r)), this.length > 1 && (Dt[e] || Et.uniqueSort(r), Pt.test(e) && r.reverse()), this.pushStack(r)
        }
    });
    var Nt = /[^\x20\t\r\n\f]+/g;
    Et.Callbacks = function(e) {
        e = "string" == typeof e ? u(e) : Et.extend({}, e);
        var t, n, r, s, o = [],
            a = [],
            l = -1,
            c = function() {
                for (s = s || e.once, r = t = !0; a.length; l = -1)
                    for (n = a.shift(); ++l < o.length;) o[l].apply(n[0], n[1]) === !1 && e.stopOnFalse && (l = o.length, n = !1);
                e.memory || (n = !1), t = !1, s && (o = n ? [] : "")
            },
            d = {
                add: function() {
                    return o && (n && !t && (l = o.length - 1, a.push(n)), function r(t) {
                        Et.each(t, function(t, n) {
                            wt(n) ? e.unique && d.has(n) || o.push(n) : n && n.length && "string" !== i(n) && r(n)
                        })
                    }(arguments), n && !t && c()), this
                },
                remove: function() {
                    return Et.each(arguments, function(e, t) {
                        for (var n;
                            (n = Et.inArray(t, o, n)) > -1;) o.splice(n, 1), l >= n && l--
                    }), this
                },
                has: function(e) {
                    return e ? Et.inArray(e, o) > -1 : o.length > 0
                },
                empty: function() {
                    return o && (o = []), this
                },
                disable: function() {
                    return s = a = [], o = n = "", this
                },
                disabled: function() {
                    return !o
                },
                lock: function() {
                    return s = a = [], n || t || (o = n = ""), this
                },
                locked: function() {
                    return !!s
                },
                fireWith: function(e, n) {
                    return s || (n = n || [], n = [e, n.slice ? n.slice() : n], a.push(n), t || c()), this
                },
                fire: function() {
                    return d.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!r
                }
            };
        return d
    }, Et.extend({
        Deferred: function(t) {
            var n = [
                    ["notify", "progress", Et.Callbacks("memory"), Et.Callbacks("memory"), 2],
                    ["resolve", "done", Et.Callbacks("once memory"), Et.Callbacks("once memory"), 0, "resolved"],
                    ["reject", "fail", Et.Callbacks("once memory"), Et.Callbacks("once memory"), 1, "rejected"]
                ],
                i = "pending",
                r = {
                    state: function() {
                        return i
                    },
                    always: function() {
                        return s.done(arguments).fail(arguments), this
                    },
                    "catch": function(e) {
                        return r.then(null, e)
                    },
                    pipe: function() {
                        var e = arguments;
                        return Et.Deferred(function(t) {
                            Et.each(n, function(n, i) {
                                var r = wt(e[i[4]]) && e[i[4]];
                                s[i[1]](function() {
                                    var e = r && r.apply(this, arguments);
                                    e && wt(e.promise) ? e.promise().progress(t.notify).done(t.resolve).fail(t.reject) : t[i[0] + "With"](this, r ? [e] : arguments)
                                })
                            }), e = null
                        }).promise()
                    },
                    then: function(t, i, r) {
                        function s(t, n, i, r) {
                            return function() {
                                var a = this,
                                    u = arguments,
                                    d = function() {
                                        var e, d;
                                        if (!(o > t)) {
                                            if (e = i.apply(a, u), e === n.promise()) throw new TypeError("Thenable self-resolution");
                                            d = e && ("object" == typeof e || "function" == typeof e) && e.then, wt(d) ? r ? d.call(e, s(o, n, l, r), s(o, n, c, r)) : (o++, d.call(e, s(o, n, l, r), s(o, n, c, r), s(o, n, l, n.notifyWith))) : (i !== l && (a = void 0, u = [e]), (r || n.resolveWith)(a, u))
                                        }
                                    },
                                    f = r ? d : function() {
                                        try {
                                            d()
                                        } catch (e) {
                                            Et.Deferred.exceptionHook && Et.Deferred.exceptionHook(e, f.stackTrace), t + 1 >= o && (i !== c && (a = void 0, u = [e]), n.rejectWith(a, u))
                                        }
                                    };
                                t ? f() : (Et.Deferred.getStackHook && (f.stackTrace = Et.Deferred.getStackHook()), e.setTimeout(f))
                            }
                        }
                        var o = 0;
                        return Et.Deferred(function(e) {
                            n[0][3].add(s(0, e, wt(r) ? r : l, e.notifyWith)), n[1][3].add(s(0, e, wt(t) ? t : l)), n[2][3].add(s(0, e, wt(i) ? i : c))
                        }).promise()
                    },
                    promise: function(e) {
                        return null != e ? Et.extend(e, r) : r
                    }
                },
                s = {};
            return Et.each(n, function(e, t) {
                var o = t[2],
                    a = t[5];
                r[t[1]] = o.add, a && o.add(function() {
                    i = a
                }, n[3 - e][2].disable, n[3 - e][3].disable, n[0][2].lock, n[0][3].lock), o.add(t[3].fire), s[t[0]] = function() {
                    return s[t[0] + "With"](this === s ? void 0 : this, arguments), this
                }, s[t[0] + "With"] = o.fireWith
            }), r.promise(s), t && t.call(s, s), s
        },
        when: function(e) {
            var t = arguments.length,
                n = t,
                i = Array(n),
                r = lt.call(arguments),
                s = Et.Deferred(),
                o = function(e) {
                    return function(n) {
                        i[e] = this, r[e] = arguments.length > 1 ? lt.call(arguments) : n, --t || s.resolveWith(i, r)
                    }
                };
            if (1 >= t && (d(e, s.done(o(n)).resolve, s.reject, !t), "pending" === s.state() || wt(r[n] && r[n].then))) return s.then();
            for (; n--;) d(r[n], o(n), s.reject);
            return s.promise()
        }
    });
    var qt = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    Et.Deferred.exceptionHook = function(t, n) {
        e.console && e.console.warn && t && qt.test(t.name) && e.console.warn("jQuery.Deferred exception: " + t.message, t.stack, n)
    }, Et.readyException = function(t) {
        e.setTimeout(function() {
            throw t
        })
    };
    var Rt = Et.Deferred();
    Et.fn.ready = function(e) {
        return Rt.then(e)["catch"](function(e) {
            Et.readyException(e)
        }), this
    }, Et.extend({
        isReady: !1,
        readyWait: 1,
        ready: function(e) {
            (e === !0 ? --Et.readyWait : Et.isReady) || (Et.isReady = !0, e !== !0 && --Et.readyWait > 0 || Rt.resolveWith(_t, [Et]))
        }
    }), Et.ready.then = Rt.then, "complete" === _t.readyState || "loading" !== _t.readyState && !_t.documentElement.doScroll ? e.setTimeout(Et.ready) : (_t.addEventListener("DOMContentLoaded", f), e.addEventListener("load", f));
    var Mt = function(e, t, n, r, s, o, a) {
            var u = 0,
                l = e.length,
                c = null == n;
            if ("object" === i(n)) {
                s = !0;
                for (u in n) Mt(e, t, u, n[u], !0, o, a)
            } else if (void 0 !== r && (s = !0, wt(r) || (a = !0), c && (a ? (t.call(e, r), t = null) : (c = t, t = function(e, t, n) {
                    return c.call(Et(e), n)
                })), t))
                for (; l > u; u++) t(e[u], n, a ? r : r.call(e[u], u, t(e[u], n)));
            return s ? e : c ? t.call(e) : l ? t(e[0], n) : o
        },
        It = /^-ms-/,
        Lt = /-([a-z])/g,
        Vt = function(e) {
            return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
        };
    m.uid = 1, m.prototype = {
        cache: function(e) {
            var t = e[this.expando];
            return t || (t = {}, Vt(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, {
                value: t,
                configurable: !0
            }))), t
        },
        set: function(e, t, n) {
            var i, r = this.cache(e);
            if ("string" == typeof t) r[p(t)] = n;
            else
                for (i in t) r[p(i)] = t[i];
            return r
        },
        get: function(e, t) {
            return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][p(t)]
        },
        access: function(e, t, n) {
            return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t)
        },
        remove: function(e, t) {
            var n, i = e[this.expando];
            if (void 0 !== i) {
                if (void 0 !== t) {
                    Array.isArray(t) ? t = t.map(p) : (t = p(t), t = t in i ? [t] : t.match(Nt) || []), n = t.length;
                    for (; n--;) delete i[t[n]]
                }(void 0 === t || Et.isEmptyObject(i)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
            }
        },
        hasData: function(e) {
            var t = e[this.expando];
            return void 0 !== t && !Et.isEmptyObject(t)
        }
    };
    var Ht = new m,
        Bt = new m,
        Wt = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        zt = /[A-Z]/g;
    Et.extend({
        hasData: function(e) {
            return Bt.hasData(e) || Ht.hasData(e)
        },
        data: function(e, t, n) {
            return Bt.access(e, t, n)
        },
        removeData: function(e, t) {
            Bt.remove(e, t)
        },
        _data: function(e, t, n) {
            return Ht.access(e, t, n)
        },
        _removeData: function(e, t) {
            Ht.remove(e, t)
        }
    }), Et.fn.extend({
        data: function(e, t) {
            var n, i, r, s = this[0],
                o = s && s.attributes;
            if (void 0 === e) {
                if (this.length && (r = Bt.get(s), 1 === s.nodeType && !Ht.get(s, "hasDataAttrs"))) {
                    for (n = o.length; n--;) o[n] && (i = o[n].name, 0 === i.indexOf("data-") && (i = p(i.slice(5)), y(s, i, r[i])));
                    Ht.set(s, "hasDataAttrs", !0)
                }
                return r
            }
            return "object" == typeof e ? this.each(function() {
                Bt.set(this, e)
            }) : Mt(this, function(t) {
                var n;
                if (s && void 0 === t) {
                    if (n = Bt.get(s, e), void 0 !== n) return n;
                    if (n = y(s, e), void 0 !== n) return n
                } else this.each(function() {
                    Bt.set(this, e, t)
                })
            }, null, t, arguments.length > 1, null, !0)
        },
        removeData: function(e) {
            return this.each(function() {
                Bt.remove(this, e)
            })
        }
    }), Et.extend({
        queue: function(e, t, n) {
            var i;
            return e ? (t = (t || "fx") + "queue", i = Ht.get(e, t), n && (!i || Array.isArray(n) ? i = Ht.access(e, t, Et.makeArray(n)) : i.push(n)), i || []) : void 0
        },
        dequeue: function(e, t) {
            t = t || "fx";
            var n = Et.queue(e, t),
                i = n.length,
                r = n.shift(),
                s = Et._queueHooks(e, t),
                o = function() {
                    Et.dequeue(e, t)
                };
            "inprogress" === r && (r = n.shift(), i--), r && ("fx" === t && n.unshift("inprogress"), delete s.stop, r.call(e, o, s)), !i && s && s.empty.fire()
        },
        _queueHooks: function(e, t) {
            var n = t + "queueHooks";
            return Ht.get(e, n) || Ht.access(e, n, {
                empty: Et.Callbacks("once memory").add(function() {
                    Ht.remove(e, [t + "queue", n])
                })
            })
        }
    }), Et.fn.extend({
        queue: function(e, t) {
            var n = 2;
            return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? Et.queue(this[0], e) : void 0 === t ? this : this.each(function() {
                var n = Et.queue(this, e, t);
                Et._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && Et.dequeue(this, e)
            })
        },
        dequeue: function(e) {
            return this.each(function() {
                Et.dequeue(this, e)
            })
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, t) {
            var n, i = 1,
                r = Et.Deferred(),
                s = this,
                o = this.length,
                a = function() {
                    --i || r.resolveWith(s, [s])
                };
            for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; o--;) n = Ht.get(s[o], e + "queueHooks"), n && n.empty && (i++, n.empty.add(a));
            return a(), r.promise(t)
        }
    });
    var Ut = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        Gt = new RegExp("^(?:([+-])=|)(" + Ut + ")([a-z%]*)$", "i"),
        Yt = ["Top", "Right", "Bottom", "Left"],
        Kt = _t.documentElement,
        Xt = function(e) {
            return Et.contains(e.ownerDocument, e)
        },
        Jt = {
            composed: !0
        };
    Kt.getRootNode && (Xt = function(e) {
        return Et.contains(e.ownerDocument, e) || e.getRootNode(Jt) === e.ownerDocument
    });
    var Qt = function(e, t) {
            return e = t || e, "none" === e.style.display || "" === e.style.display && Xt(e) && "none" === Et.css(e, "display")
        },
        Zt = {};
    Et.fn.extend({
        show: function() {
            return b(this, !0)
        },
        hide: function() {
            return b(this)
        },
        toggle: function(e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
                Qt(this) ? Et(this).show() : Et(this).hide()
            })
        }
    });
    var en = /^(?:checkbox|radio)$/i,
        tn = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
        nn = /^$|^module$|\/(?:java|ecma)script/i;
    ! function() {
        var e = _t.createDocumentFragment(),
            t = e.appendChild(_t.createElement("div")),
            n = _t.createElement("input");
        n.setAttribute("type", "radio"), n.setAttribute("checked", "checked"), n.setAttribute("name", "t"), t.appendChild(n), vt.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked, t.innerHTML = "<textarea>x</textarea>", vt.noCloneChecked = !!t.cloneNode(!0).lastChild.defaultValue, t.innerHTML = "<option></option>", vt.option = !!t.lastChild
    }();
    var rn = {
        thead: [1, "<table>", "</table>"],
        col: [2, "<table><colgroup>", "</colgroup></table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: [0, "", ""]
    };
    rn.tbody = rn.tfoot = rn.colgroup = rn.caption = rn.thead, rn.th = rn.td, vt.option || (rn.optgroup = rn.option = [1, "<select multiple='multiple'>", "</select>"]);
    var sn = /<|&#?\w+;/,
        on = /^key/,
        an = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
        un = /^([^.]*)(?:\.(.+)|)/;
    Et.event = {
        global: {},
        add: function(e, t, n, i, r) {
            var s, o, a, u, l, c, d, f, h, p, m, g = Ht.get(e);
            if (Vt(e))
                for (n.handler && (s = n, n = s.handler, r = s.selector), r && Et.find.matchesSelector(Kt, r), n.guid || (n.guid = Et.guid++), (u = g.events) || (u = g.events = Object.create(null)), (o = g.handle) || (o = g.handle = function(t) {
                        return "undefined" != typeof Et && Et.event.triggered !== t.type ? Et.event.dispatch.apply(e, arguments) : void 0
                    }), t = (t || "").match(Nt) || [""], l = t.length; l--;) a = un.exec(t[l]) || [], h = m = a[1], p = (a[2] || "").split(".").sort(), h && (d = Et.event.special[h] || {}, h = (r ? d.delegateType : d.bindType) || h, d = Et.event.special[h] || {}, c = Et.extend({
                    type: h,
                    origType: m,
                    data: i,
                    handler: n,
                    guid: n.guid,
                    selector: r,
                    needsContext: r && Et.expr.match.needsContext.test(r),
                    namespace: p.join(".")
                }, s), (f = u[h]) || (f = u[h] = [], f.delegateCount = 0, d.setup && d.setup.call(e, i, p, o) !== !1 || e.addEventListener && e.addEventListener(h, o)), d.add && (d.add.call(e, c), c.handler.guid || (c.handler.guid = n.guid)), r ? f.splice(f.delegateCount++, 0, c) : f.push(c), Et.event.global[h] = !0)
        },
        remove: function(e, t, n, i, r) {
            var s, o, a, u, l, c, d, f, h, p, m, g = Ht.hasData(e) && Ht.get(e);
            if (g && (u = g.events)) {
                for (t = (t || "").match(Nt) || [""], l = t.length; l--;)
                    if (a = un.exec(t[l]) || [], h = m = a[1], p = (a[2] || "").split(".").sort(), h) {
                        for (d = Et.event.special[h] || {}, h = (i ? d.delegateType : d.bindType) || h, f = u[h] || [], a = a[2] && new RegExp("(^|\\.)" + p.join("\\.(?:.*\\.|)") + "(\\.|$)"), o = s = f.length; s--;) c = f[s], !r && m !== c.origType || n && n.guid !== c.guid || a && !a.test(c.namespace) || i && i !== c.selector && ("**" !== i || !c.selector) || (f.splice(s, 1), c.selector && f.delegateCount--, d.remove && d.remove.call(e, c));
                        o && !f.length && (d.teardown && d.teardown.call(e, p, g.handle) !== !1 || Et.removeEvent(e, h, g.handle), delete u[h])
                    } else
                        for (h in u) Et.event.remove(e, h + t[l], n, i, !0);
                Et.isEmptyObject(u) && Ht.remove(e, "handle events")
            }
        },
        dispatch: function(e) {
            var t, n, i, r, s, o, a = new Array(arguments.length),
                u = Et.event.fix(e),
                l = (Ht.get(this, "events") || Object.create(null))[u.type] || [],
                c = Et.event.special[u.type] || {};
            for (a[0] = u, t = 1; t < arguments.length; t++) a[t] = arguments[t];
            if (u.delegateTarget = this, !c.preDispatch || c.preDispatch.call(this, u) !== !1) {
                for (o = Et.event.handlers.call(this, u, l), t = 0;
                    (r = o[t++]) && !u.isPropagationStopped();)
                    for (u.currentTarget = r.elem, n = 0;
                        (s = r.handlers[n++]) && !u.isImmediatePropagationStopped();)(!u.rnamespace || s.namespace === !1 || u.rnamespace.test(s.namespace)) && (u.handleObj = s, u.data = s.data, i = ((Et.event.special[s.origType] || {}).handle || s.handler).apply(r.elem, a), void 0 !== i && (u.result = i) === !1 && (u.preventDefault(), u.stopPropagation()));
                return c.postDispatch && c.postDispatch.call(this, u), u.result
            }
        },
        handlers: function(e, t) {
            var n, i, r, s, o, a = [],
                u = t.delegateCount,
                l = e.target;
            if (u && l.nodeType && !("click" === e.type && e.button >= 1))
                for (; l !== this; l = l.parentNode || this)
                    if (1 === l.nodeType && ("click" !== e.type || l.disabled !== !0)) {
                        for (s = [], o = {}, n = 0; u > n; n++) i = t[n], r = i.selector + " ", void 0 === o[r] && (o[r] = i.needsContext ? Et(r, this).index(l) > -1 : Et.find(r, this, null, [l]).length), o[r] && s.push(i);
                        s.length && a.push({
                            elem: l,
                            handlers: s
                        })
                    }
            return l = this, u < t.length && a.push({
                elem: l,
                handlers: t.slice(u)
            }), a
        },
        addProp: function(e, t) {
            Object.defineProperty(Et.Event.prototype, e, {
                enumerable: !0,
                configurable: !0,
                get: wt(t) ? function() {
                    return this.originalEvent ? t(this.originalEvent) : void 0
                } : function() {
                    return this.originalEvent ? this.originalEvent[e] : void 0
                },
                set: function(t) {
                    Object.defineProperty(this, e, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: t
                    })
                }
            })
        },
        fix: function(e) {
            return e[Et.expando] ? e : new Et.Event(e)
        },
        special: {
            load: {
                noBubble: !0
            },
            click: {
                setup: function(e) {
                    var t = this || e;
                    return en.test(t.type) && t.click && s(t, "input") && S(t, "click", E), !1
                },
                trigger: function(e) {
                    var t = this || e;
                    return en.test(t.type) && t.click && s(t, "input") && S(t, "click"), !0
                },
                _default: function(e) {
                    var t = e.target;
                    return en.test(t.type) && t.click && s(t, "input") && Ht.get(t, "click") || s(t, "a")
                }
            },
            beforeunload: {
                postDispatch: function(e) {
                    void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        }
    }, Et.removeEvent = function(e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n)
    }, Et.Event = function(e, t) {
        return this instanceof Et.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && e.returnValue === !1 ? E : F, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, t && Et.extend(this, t), this.timeStamp = e && e.timeStamp || Date.now(), void(this[Et.expando] = !0)) : new Et.Event(e, t)
    }, Et.Event.prototype = {
        constructor: Et.Event,
        isDefaultPrevented: F,
        isPropagationStopped: F,
        isImmediatePropagationStopped: F,
        isSimulated: !1,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = E, e && !this.isSimulated && e.preventDefault()
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = E, e && !this.isSimulated && e.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = E, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
        }
    }, Et.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        "char": !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: function(e) {
            var t = e.button;
            return null == e.which && on.test(e.type) ? null != e.charCode ? e.charCode : e.keyCode : !e.which && void 0 !== t && an.test(e.type) ? 1 & t ? 1 : 2 & t ? 3 : 4 & t ? 2 : 0 : e.which
        }
    }, Et.event.addProp), Et.each({
        focus: "focusin",
        blur: "focusout"
    }, function(e, t) {
        Et.event.special[e] = {
            setup: function() {
                return S(this, e, T), !1
            },
            trigger: function() {
                return S(this, e), !0
            },
            delegateType: t
        }
    }), Et.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function(e, t) {
        Et.event.special[e] = {
            delegateType: t,
            bindType: t,
            handle: function(e) {
                var n, i = this,
                    r = e.relatedTarget,
                    s = e.handleObj;
                return (!r || r !== i && !Et.contains(i, r)) && (e.type = s.origType, n = s.handler.apply(this, arguments), e.type = t), n
            }
        }
    }), Et.fn.extend({
        on: function(e, t, n, i) {
            return $(this, e, t, n, i)
        },
        one: function(e, t, n, i) {
            return $(this, e, t, n, i, 1)
        },
        off: function(e, t, n) {
            var i, r;
            if (e && e.preventDefault && e.handleObj) return i = e.handleObj, Et(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler), this;
            if ("object" == typeof e) {
                for (r in e) this.off(r, t, e[r]);
                return this
            }
            return (t === !1 || "function" == typeof t) && (n = t, t = void 0), n === !1 && (n = F), this.each(function() {
                Et.event.remove(this, e, n, t)
            })
        }
    });
    var ln = /<script|<style|<link/i,
        cn = /checked\s*(?:[^=]|=\s*.checked.)/i,
        dn = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
    Et.extend({
        htmlPrefilter: function(e) {
            return e
        },
        clone: function(e, t, n) {
            var i, r, s, o, a = e.cloneNode(!0),
                u = Xt(e);
            if (!(vt.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || Et.isXMLDoc(e)))
                for (o = _(a), s = _(e), i = 0, r = s.length; r > i; i++) D(s[i], o[i]);
            if (t)
                if (n)
                    for (s = s || _(e), o = o || _(a), i = 0, r = s.length; r > i; i++) P(s[i], o[i]);
                else P(e, a);
            return o = _(a, "script"), o.length > 0 && x(o, !u && _(e, "script")), a
        },
        cleanData: function(e) {
            for (var t, n, i, r = Et.event.special, s = 0; void 0 !== (n = e[s]); s++)
                if (Vt(n)) {
                    if (t = n[Ht.expando]) {
                        if (t.events)
                            for (i in t.events) r[i] ? Et.event.remove(n, i) : Et.removeEvent(n, i, t.handle);
                        n[Ht.expando] = void 0
                    }
                    n[Bt.expando] && (n[Bt.expando] = void 0)
                }
        }
    }), Et.fn.extend({
        detach: function(e) {
            return q(this, e, !0)
        },
        remove: function(e) {
            return q(this, e)
        },
        text: function(e) {
            return Mt(this, function(e) {
                return void 0 === e ? Et.text(this) : this.empty().each(function() {
                    (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) && (this.textContent = e)
                })
            }, null, e, arguments.length)
        },
        append: function() {
            return N(this, arguments, function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = j(this, e);
                    t.appendChild(e)
                }
            })
        },
        prepend: function() {
            return N(this, arguments, function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = j(this, e);
                    t.insertBefore(e, t.firstChild)
                }
            })
        },
        before: function() {
            return N(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            })
        },
        after: function() {
            return N(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            })
        },
        empty: function() {
            for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (Et.cleanData(_(e, !1)), e.textContent = "");
            return this
        },
        clone: function(e, t) {
            return e = null == e ? !1 : e, t = null == t ? e : t, this.map(function() {
                return Et.clone(this, e, t)
            })
        },
        html: function(e) {
            return Mt(this, function(e) {
                var t = this[0] || {},
                    n = 0,
                    i = this.length;
                if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                if ("string" == typeof e && !ln.test(e) && !rn[(tn.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = Et.htmlPrefilter(e);
                    try {
                        for (; i > n; n++) t = this[n] || {}, 1 === t.nodeType && (Et.cleanData(_(t, !1)), t.innerHTML = e);
                        t = 0
                    } catch (r) {}
                }
                t && this.empty().append(e)
            }, null, e, arguments.length)
        },
        replaceWith: function() {
            var e = [];
            return N(this, arguments, function(t) {
                var n = this.parentNode;
                Et.inArray(this, e) < 0 && (Et.cleanData(_(this)), n && n.replaceChild(t, this))
            }, e)
        }
    }), Et.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(e, t) {
        Et.fn[e] = function(e) {
            for (var n, i = [], r = Et(e), s = r.length - 1, o = 0; s >= o; o++) n = o === s ? this : this.clone(!0), Et(r[o])[t](n), dt.apply(i, n.get());
            return this.pushStack(i)
        }
    });
    var fn = new RegExp("^(" + Ut + ")(?!px)[a-z%]+$", "i"),
        hn = function(t) {
            var n = t.ownerDocument.defaultView;
            return n && n.opener || (n = e), n.getComputedStyle(t)
        },
        pn = function(e, t, n) {
            var i, r, s = {};
            for (r in t) s[r] = e.style[r], e.style[r] = t[r];
            i = n.call(e);
            for (r in t) e.style[r] = s[r];
            return i
        },
        mn = new RegExp(Yt.join("|"), "i");
    ! function() {
        function t() {
            if (c) {
                l.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", c.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", Kt.appendChild(l).appendChild(c);
                var t = e.getComputedStyle(c);
                i = "1%" !== t.top, u = 12 === n(t.marginLeft), c.style.right = "60%", o = 36 === n(t.right), r = 36 === n(t.width), c.style.position = "absolute", s = 12 === n(c.offsetWidth / 3), Kt.removeChild(l), c = null
            }
        }

        function n(e) {
            return Math.round(parseFloat(e))
        }
        var i, r, s, o, a, u, l = _t.createElement("div"),
            c = _t.createElement("div");
        c.style && (c.style.backgroundClip = "content-box", c.cloneNode(!0).style.backgroundClip = "", vt.clearCloneStyle = "content-box" === c.style.backgroundClip, Et.extend(vt, {
            boxSizingReliable: function() {
                return t(), r
            },
            pixelBoxStyles: function() {
                return t(), o
            },
            pixelPosition: function() {
                return t(), i
            },
            reliableMarginLeft: function() {
                return t(), u
            },
            scrollboxSize: function() {
                return t(), s
            },
            reliableTrDimensions: function() {
                var t, n, i, r;
                return null == a && (t = _t.createElement("table"), n = _t.createElement("tr"), i = _t.createElement("div"), t.style.cssText = "position:absolute;left:-11111px", n.style.height = "1px", i.style.height = "9px", Kt.appendChild(t).appendChild(n).appendChild(i), r = e.getComputedStyle(n), a = parseInt(r.height) > 3, Kt.removeChild(t)), a
            }
        }))
    }();
    var gn = ["Webkit", "Moz", "ms"],
        yn = _t.createElement("div").style,
        vn = {},
        wn = /^(none|table(?!-c[ea]).+)/,
        bn = /^--/,
        _n = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        xn = {
            letterSpacing: "0",
            fontWeight: "400"
        };
    Et.extend({
        cssHooks: {
            opacity: {
                get: function(e, t) {
                    if (t) {
                        var n = R(e, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {},
        style: function(e, t, n, i) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var r, s, o, a = p(t),
                    u = bn.test(t),
                    l = e.style;
                return u || (t = L(a)), o = Et.cssHooks[t] || Et.cssHooks[a], void 0 === n ? o && "get" in o && void 0 !== (r = o.get(e, !1, i)) ? r : l[t] : (s = typeof n, "string" === s && (r = Gt.exec(n)) && r[1] && (n = v(e, t, r), s = "number"), null != n && n === n && ("number" !== s || u || (n += r && r[3] || (Et.cssNumber[a] ? "" : "px")), vt.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), o && "set" in o && void 0 === (n = o.set(e, n, i)) || (u ? l.setProperty(t, n) : l[t] = n)), void 0)
            }
        },
        css: function(e, t, n, i) {
            var r, s, o, a = p(t),
                u = bn.test(t);
            return u || (t = L(a)), o = Et.cssHooks[t] || Et.cssHooks[a], o && "get" in o && (r = o.get(e, !0, n)), void 0 === r && (r = R(e, t, i)), "normal" === r && t in xn && (r = xn[t]), "" === n || n ? (s = parseFloat(r), n === !0 || isFinite(s) ? s || 0 : r) : r
        }
    }), Et.each(["height", "width"], function(e, t) {
        Et.cssHooks[t] = {
            get: function(e, n, i) {
                return n ? !wn.test(Et.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? B(e, t, i) : pn(e, _n, function() {
                    return B(e, t, i)
                }) : void 0
            },
            set: function(e, n, i) {
                var r, s = hn(e),
                    o = !vt.scrollboxSize() && "absolute" === s.position,
                    a = o || i,
                    u = a && "border-box" === Et.css(e, "boxSizing", !1, s),
                    l = i ? H(e, t, i, u, s) : 0;
                return u && o && (l -= Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - parseFloat(s[t]) - H(e, t, "border", !1, s) - .5)), l && (r = Gt.exec(n)) && "px" !== (r[3] || "px") && (e.style[t] = n, n = Et.css(e, t)), V(e, n, l)
            }
        }
    }), Et.cssHooks.marginLeft = M(vt.reliableMarginLeft, function(e, t) {
        return t ? (parseFloat(R(e, "marginLeft")) || e.getBoundingClientRect().left - pn(e, {
            marginLeft: 0
        }, function() {
            return e.getBoundingClientRect().left
        })) + "px" : void 0
    }), Et.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(e, t) {
        Et.cssHooks[e + t] = {
            expand: function(n) {
                for (var i = 0, r = {}, s = "string" == typeof n ? n.split(" ") : [n]; 4 > i; i++) r[e + Yt[i] + t] = s[i] || s[i - 2] || s[0];
                return r
            }
        }, "margin" !== e && (Et.cssHooks[e + t].set = V)
    }), Et.fn.extend({
        css: function(e, t) {
            return Mt(this, function(e, t, n) {
                var i, r, s = {},
                    o = 0;
                if (Array.isArray(t)) {
                    for (i = hn(e), r = t.length; r > o; o++) s[t[o]] = Et.css(e, t[o], !1, i);
                    return s
                }
                return void 0 !== n ? Et.style(e, t, n) : Et.css(e, t)
            }, e, t, arguments.length > 1)
        }
    }), Et.Tween = W, W.prototype = {
        constructor: W,
        init: function(e, t, n, i, r, s) {
            this.elem = e, this.prop = n, this.easing = r || Et.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = i, this.unit = s || (Et.cssNumber[n] ? "" : "px")
        },
        cur: function() {
            var e = W.propHooks[this.prop];
            return e && e.get ? e.get(this) : W.propHooks._default.get(this)
        },
        run: function(e) {
            var t, n = W.propHooks[this.prop];
            return this.pos = t = this.options.duration ? Et.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : W.propHooks._default.set(this), this
        }
    }, W.prototype.init.prototype = W.prototype, W.propHooks = {
        _default: {
            get: function(e) {
                var t;
                return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = Et.css(e.elem, e.prop, ""), t && "auto" !== t ? t : 0)
            },
            set: function(e) {
                Et.fx.step[e.prop] ? Et.fx.step[e.prop](e) : 1 !== e.elem.nodeType || !Et.cssHooks[e.prop] && null == e.elem.style[L(e.prop)] ? e.elem[e.prop] = e.now : Et.style(e.elem, e.prop, e.now + e.unit)
            }
        }
    }, W.propHooks.scrollTop = W.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, Et.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    }, Et.fx = W.prototype.init, Et.fx.step = {};
    var Cn, En, Fn = /^(?:toggle|show|hide)$/,
        Tn = /queueHooks$/;
    Et.Animation = Et.extend(J, {
            tweeners: {
                "*": [function(e, t) {
                    var n = this.createTween(e, t);
                    return v(n.elem, e, Gt.exec(t), n), n
                }]
            },
            tweener: function(e, t) {
                wt(e) ? (t = e, e = ["*"]) : e = e.match(Nt);
                for (var n, i = 0, r = e.length; r > i; i++) n = e[i], J.tweeners[n] = J.tweeners[n] || [], J.tweeners[n].unshift(t)
            },
            prefilters: [K],
            prefilter: function(e, t) {
                t ? J.prefilters.unshift(e) : J.prefilters.push(e)
            }
        }), Et.speed = function(e, t, n) {
            var i = e && "object" == typeof e ? Et.extend({}, e) : {
                complete: n || !n && t || wt(e) && e,
                duration: e,
                easing: n && t || t && !wt(t) && t
            };
            return Et.fx.off ? i.duration = 0 : "number" != typeof i.duration && (i.duration = i.duration in Et.fx.speeds ? Et.fx.speeds[i.duration] : Et.fx.speeds._default), (null == i.queue || i.queue === !0) && (i.queue = "fx"), i.old = i.complete, i.complete = function() {
                wt(i.old) && i.old.call(this), i.queue && Et.dequeue(this, i.queue)
            }, i
        }, Et.fn.extend({
            fadeTo: function(e, t, n, i) {
                return this.filter(Qt).css("opacity", 0).show().end().animate({
                    opacity: t
                }, e, n, i)
            },
            animate: function(e, t, n, i) {
                var r = Et.isEmptyObject(e),
                    s = Et.speed(t, n, i),
                    o = function() {
                        var t = J(this, Et.extend({}, e), s);
                        (r || Ht.get(this, "finish")) && t.stop(!0)
                    };
                return o.finish = o, r || s.queue === !1 ? this.each(o) : this.queue(s.queue, o)
            },
            stop: function(e, t, n) {
                var i = function(e) {
                    var t = e.stop;
                    delete e.stop, t(n)
                };
                return "string" != typeof e && (n = t, t = e, e = void 0), t && this.queue(e || "fx", []), this.each(function() {
                    var t = !0,
                        r = null != e && e + "queueHooks",
                        s = Et.timers,
                        o = Ht.get(this);
                    if (r) o[r] && o[r].stop && i(o[r]);
                    else
                        for (r in o) o[r] && o[r].stop && Tn.test(r) && i(o[r]);
                    for (r = s.length; r--;) s[r].elem !== this || null != e && s[r].queue !== e || (s[r].anim.stop(n), t = !1, s.splice(r, 1));
                    (t || !n) && Et.dequeue(this, e)
                })
            },
            finish: function(e) {
                return e !== !1 && (e = e || "fx"), this.each(function() {
                    var t, n = Ht.get(this),
                        i = n[e + "queue"],
                        r = n[e + "queueHooks"],
                        s = Et.timers,
                        o = i ? i.length : 0;
                    for (n.finish = !0, Et.queue(this, e, []), r && r.stop && r.stop.call(this, !0), t = s.length; t--;) s[t].elem === this && s[t].queue === e && (s[t].anim.stop(!0), s.splice(t, 1));
                    for (t = 0; o > t; t++) i[t] && i[t].finish && i[t].finish.call(this);
                    delete n.finish
                })
            }
        }), Et.each(["toggle", "show", "hide"], function(e, t) {
            var n = Et.fn[t];
            Et.fn[t] = function(e, i, r) {
                return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(G(t, !0), e, i, r)
            }
        }), Et.each({
            slideDown: G("show"),
            slideUp: G("hide"),
            slideToggle: G("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        }, function(e, t) {
            Et.fn[e] = function(e, n, i) {
                return this.animate(t, e, n, i)
            }
        }), Et.timers = [], Et.fx.tick = function() {
            var e, t = 0,
                n = Et.timers;
            for (Cn = Date.now(); t < n.length; t++) e = n[t], e() || n[t] !== e || n.splice(t--, 1);
            n.length || Et.fx.stop(), Cn = void 0
        }, Et.fx.timer = function(e) {
            Et.timers.push(e), Et.fx.start()
        }, Et.fx.interval = 13, Et.fx.start = function() {
            En || (En = !0, z())
        }, Et.fx.stop = function() {
            En = null
        }, Et.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        }, Et.fn.delay = function(t, n) {
            return t = Et.fx ? Et.fx.speeds[t] || t : t, n = n || "fx", this.queue(n, function(n, i) {
                var r = e.setTimeout(n, t);
                i.stop = function() {
                    e.clearTimeout(r)
                }
            })
        },
        function() {
            var e = _t.createElement("input"),
                t = _t.createElement("select"),
                n = t.appendChild(_t.createElement("option"));
            e.type = "checkbox", vt.checkOn = "" !== e.value, vt.optSelected = n.selected, e = _t.createElement("input"), e.value = "t", e.type = "radio", vt.radioValue = "t" === e.value
        }();
    var kn, $n = Et.expr.attrHandle;
    Et.fn.extend({
        attr: function(e, t) {
            return Mt(this, Et.attr, e, t, arguments.length > 1)
        },
        removeAttr: function(e) {
            return this.each(function() {
                Et.removeAttr(this, e)
            })
        }
    }), Et.extend({
        attr: function(e, t, n) {
            var i, r, s = e.nodeType;
            if (3 !== s && 8 !== s && 2 !== s) return "undefined" == typeof e.getAttribute ? Et.prop(e, t, n) : (1 === s && Et.isXMLDoc(e) || (r = Et.attrHooks[t.toLowerCase()] || (Et.expr.match.bool.test(t) ? kn : void 0)), void 0 !== n ? null === n ? void Et.removeAttr(e, t) : r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i : (e.setAttribute(t, n + ""), n) : r && "get" in r && null !== (i = r.get(e, t)) ? i : (i = Et.find.attr(e, t), null == i ? void 0 : i))
        },
        attrHooks: {
            type: {
                set: function(e, t) {
                    if (!vt.radioValue && "radio" === t && s(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            }
        },
        removeAttr: function(e, t) {
            var n, i = 0,
                r = t && t.match(Nt);
            if (r && 1 === e.nodeType)
                for (; n = r[i++];) e.removeAttribute(n)
        }
    }), kn = {
        set: function(e, t, n) {
            return t === !1 ? Et.removeAttr(e, n) : e.setAttribute(n, n), n
        }
    }, Et.each(Et.expr.match.bool.source.match(/\w+/g), function(e, t) {
        var n = $n[t] || Et.find.attr;
        $n[t] = function(e, t, i) {
            var r, s, o = t.toLowerCase();
            return i || (s = $n[o], $n[o] = r, r = null != n(e, t, i) ? o : null, $n[o] = s), r
        }
    });
    var Sn = /^(?:input|select|textarea|button)$/i,
        jn = /^(?:a|area)$/i;
    Et.fn.extend({
        prop: function(e, t) {
            return Mt(this, Et.prop, e, t, arguments.length > 1)
        },
        removeProp: function(e) {
            return this.each(function() {
                delete this[Et.propFix[e] || e]
            })
        }
    }), Et.extend({
        prop: function(e, t, n) {
            var i, r, s = e.nodeType;
            if (3 !== s && 8 !== s && 2 !== s) return 1 === s && Et.isXMLDoc(e) || (t = Et.propFix[t] || t, r = Et.propHooks[t]), void 0 !== n ? r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i : e[t] = n : r && "get" in r && null !== (i = r.get(e, t)) ? i : e[t]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var t = Et.find.attr(e, "tabindex");
                    return t ? parseInt(t, 10) : Sn.test(e.nodeName) || jn.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            "for": "htmlFor",
            "class": "className"
        }
    }), vt.optSelected || (Et.propHooks.selected = {
        get: function(e) {
            var t = e.parentNode;
            return t && t.parentNode && t.parentNode.selectedIndex, null
        },
        set: function(e) {
            var t = e.parentNode;
            t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
        }
    }), Et.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
        Et.propFix[this.toLowerCase()] = this
    }), Et.fn.extend({
        addClass: function(e) {
            var t, n, i, r, s, o, a, u = 0;
            if (wt(e)) return this.each(function(t) {
                Et(this).addClass(e.call(this, t, Z(this)))
            });
            if (t = et(e), t.length)
                for (; n = this[u++];)
                    if (r = Z(n), i = 1 === n.nodeType && " " + Q(r) + " ") {
                        for (o = 0; s = t[o++];) i.indexOf(" " + s + " ") < 0 && (i += s + " ");
                        a = Q(i), r !== a && n.setAttribute("class", a)
                    }
            return this
        },
        removeClass: function(e) {
            var t, n, i, r, s, o, a, u = 0;
            if (wt(e)) return this.each(function(t) {
                Et(this).removeClass(e.call(this, t, Z(this)))
            });
            if (!arguments.length) return this.attr("class", "");
            if (t = et(e), t.length)
                for (; n = this[u++];)
                    if (r = Z(n), i = 1 === n.nodeType && " " + Q(r) + " ") {
                        for (o = 0; s = t[o++];)
                            for (; i.indexOf(" " + s + " ") > -1;) i = i.replace(" " + s + " ", " ");
                        a = Q(i), r !== a && n.setAttribute("class", a)
                    }
            return this
        },
        toggleClass: function(e, t) {
            var n = typeof e,
                i = "string" === n || Array.isArray(e);
            return "boolean" == typeof t && i ? t ? this.addClass(e) : this.removeClass(e) : this.each(wt(e) ? function(n) {
                Et(this).toggleClass(e.call(this, n, Z(this), t), t)
            } : function() {
                var t, r, s, o;
                if (i)
                    for (r = 0, s = Et(this), o = et(e); t = o[r++];) s.hasClass(t) ? s.removeClass(t) : s.addClass(t);
                else(void 0 === e || "boolean" === n) && (t = Z(this), t && Ht.set(this, "__className__", t), this.setAttribute && this.setAttribute("class", t || e === !1 ? "" : Ht.get(this, "__className__") || ""))
            })
        },
        hasClass: function(e) {
            var t, n, i = 0;
            for (t = " " + e + " "; n = this[i++];)
                if (1 === n.nodeType && (" " + Q(Z(n)) + " ").indexOf(t) > -1) return !0;
            return !1
        }
    });
    var An = /\r/g;
    Et.fn.extend({
        val: function(e) {
            var t, n, i, r = this[0]; {
                if (arguments.length) return i = wt(e), this.each(function(n) {
                    var r;
                    1 === this.nodeType && (r = i ? e.call(this, n, Et(this).val()) : e, null == r ? r = "" : "number" == typeof r ? r += "" : Array.isArray(r) && (r = Et.map(r, function(e) {
                        return null == e ? "" : e + ""
                    })), t = Et.valHooks[this.type] || Et.valHooks[this.nodeName.toLowerCase()], t && "set" in t && void 0 !== t.set(this, r, "value") || (this.value = r))
                });
                if (r) return t = Et.valHooks[r.type] || Et.valHooks[r.nodeName.toLowerCase()], t && "get" in t && void 0 !== (n = t.get(r, "value")) ? n : (n = r.value, "string" == typeof n ? n.replace(An, "") : null == n ? "" : n)
            }
        }
    }), Et.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var t = Et.find.attr(e, "value");
                    return null != t ? t : Q(Et.text(e))
                }
            },
            select: {
                get: function(e) {
                    var t, n, i, r = e.options,
                        o = e.selectedIndex,
                        a = "select-one" === e.type,
                        u = a ? null : [],
                        l = a ? o + 1 : r.length;
                    for (i = 0 > o ? l : a ? o : 0; l > i; i++)
                        if (n = r[i], !(!n.selected && i !== o || n.disabled || n.parentNode.disabled && s(n.parentNode, "optgroup"))) {
                            if (t = Et(n).val(), a) return t;
                            u.push(t)
                        }
                    return u
                },
                set: function(e, t) {
                    for (var n, i, r = e.options, s = Et.makeArray(t), o = r.length; o--;) i = r[o], (i.selected = Et.inArray(Et.valHooks.option.get(i), s) > -1) && (n = !0);
                    return n || (e.selectedIndex = -1), s
                }
            }
        }
    }), Et.each(["radio", "checkbox"], function() {
        Et.valHooks[this] = {
            set: function(e, t) {
                return Array.isArray(t) ? e.checked = Et.inArray(Et(e).val(), t) > -1 : void 0
            }
        }, vt.checkOn || (Et.valHooks[this].get = function(e) {
            return null === e.getAttribute("value") ? "on" : e.value
        })
    }), vt.focusin = "onfocusin" in e;
    var On = /^(?:focusinfocus|focusoutblur)$/,
        Pn = function(e) {
            e.stopPropagation()
        };
    Et.extend(Et.event, {
        trigger: function(t, n, i, r) {
            var s, o, a, u, l, c, d, f, h = [i || _t],
                p = mt.call(t, "type") ? t.type : t,
                m = mt.call(t, "namespace") ? t.namespace.split(".") : [];
            if (o = f = a = i = i || _t, 3 !== i.nodeType && 8 !== i.nodeType && !On.test(p + Et.event.triggered) && (p.indexOf(".") > -1 && (m = p.split("."), p = m.shift(), m.sort()), l = p.indexOf(":") < 0 && "on" + p, t = t[Et.expando] ? t : new Et.Event(p, "object" == typeof t && t), t.isTrigger = r ? 2 : 3, t.namespace = m.join("."), t.rnamespace = t.namespace ? new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = i), n = null == n ? [t] : Et.makeArray(n, [t]), d = Et.event.special[p] || {}, r || !d.trigger || d.trigger.apply(i, n) !== !1)) {
                if (!r && !d.noBubble && !bt(i)) {
                    for (u = d.delegateType || p, On.test(u + p) || (o = o.parentNode); o; o = o.parentNode) h.push(o), a = o;
                    a === (i.ownerDocument || _t) && h.push(a.defaultView || a.parentWindow || e)
                }
                for (s = 0;
                    (o = h[s++]) && !t.isPropagationStopped();) f = o, t.type = s > 1 ? u : d.bindType || p, c = (Ht.get(o, "events") || Object.create(null))[t.type] && Ht.get(o, "handle"), c && c.apply(o, n), c = l && o[l], c && c.apply && Vt(o) && (t.result = c.apply(o, n), t.result === !1 && t.preventDefault());
                return t.type = p, r || t.isDefaultPrevented() || d._default && d._default.apply(h.pop(), n) !== !1 || !Vt(i) || l && wt(i[p]) && !bt(i) && (a = i[l], a && (i[l] = null), Et.event.triggered = p, t.isPropagationStopped() && f.addEventListener(p, Pn), i[p](), t.isPropagationStopped() && f.removeEventListener(p, Pn), Et.event.triggered = void 0, a && (i[l] = a)), t.result
            }
        },
        simulate: function(e, t, n) {
            var i = Et.extend(new Et.Event, n, {
                type: e,
                isSimulated: !0
            });
            Et.event.trigger(i, null, t)
        }
    }), Et.fn.extend({
        trigger: function(e, t) {
            return this.each(function() {
                Et.event.trigger(e, t, this)
            })
        },
        triggerHandler: function(e, t) {
            var n = this[0];
            return n ? Et.event.trigger(e, t, n, !0) : void 0
        }
    }), vt.focusin || Et.each({
        focus: "focusin",
        blur: "focusout"
    }, function(e, t) {
        var n = function(e) {
            Et.event.simulate(t, e.target, Et.event.fix(e))
        };
        Et.event.special[t] = {
            setup: function() {
                var i = this.ownerDocument || this.document || this,
                    r = Ht.access(i, t);
                r || i.addEventListener(e, n, !0), Ht.access(i, t, (r || 0) + 1)
            },
            teardown: function() {
                var i = this.ownerDocument || this.document || this,
                    r = Ht.access(i, t) - 1;
                r ? Ht.access(i, t, r) : (i.removeEventListener(e, n, !0), Ht.remove(i, t))
            }
        }
    });
    var Dn = e.location,
        Nn = {
            guid: Date.now()
        },
        qn = /\?/;
    Et.parseXML = function(t) {
        var n;
        if (!t || "string" != typeof t) return null;
        try {
            n = (new e.DOMParser).parseFromString(t, "text/xml")
        } catch (i) {
            n = void 0
        }
        return (!n || n.getElementsByTagName("parsererror").length) && Et.error("Invalid XML: " + t), n
    };
    var Rn = /\[\]$/,
        Mn = /\r?\n/g,
        In = /^(?:submit|button|image|reset|file)$/i,
        Ln = /^(?:input|select|textarea|keygen)/i;
    Et.param = function(e, t) {
        var n, i = [],
            r = function(e, t) {
                var n = wt(t) ? t() : t;
                i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n)
            };
        if (null == e) return "";
        if (Array.isArray(e) || e.jquery && !Et.isPlainObject(e)) Et.each(e, function() {
            r(this.name, this.value)
        });
        else
            for (n in e) tt(n, e[n], t, r);
        return i.join("&")
    }, Et.fn.extend({
        serialize: function() {
            return Et.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var e = Et.prop(this, "elements");
                return e ? Et.makeArray(e) : this
            }).filter(function() {
                var e = this.type;
                return this.name && !Et(this).is(":disabled") && Ln.test(this.nodeName) && !In.test(e) && (this.checked || !en.test(e))
            }).map(function(e, t) {
                var n = Et(this).val();
                return null == n ? null : Array.isArray(n) ? Et.map(n, function(e) {
                    return {
                        name: t.name,
                        value: e.replace(Mn, "\r\n")
                    }
                }) : {
                    name: t.name,
                    value: n.replace(Mn, "\r\n")
                }
            }).get()
        }
    });
    var Vn = /%20/g,
        Hn = /#.*$/,
        Bn = /([?&])_=[^&]*/,
        Wn = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        zn = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
        Un = /^(?:GET|HEAD)$/,
        Gn = /^\/\//,
        Yn = {},
        Kn = {},
        Xn = "*/".concat("*"),
        Jn = _t.createElement("a");
    Jn.href = Dn.href, Et.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Dn.href,
            type: "GET",
            isLocal: zn.test(Dn.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Xn,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": Et.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, t) {
            return t ? rt(rt(e, Et.ajaxSettings), t) : rt(Et.ajaxSettings, e)
        },
        ajaxPrefilter: nt(Yn),
        ajaxTransport: nt(Kn),
        ajax: function(t, n) {
            function i(t, n, i, a) {
                var l, f, h, b, _, x = n;
                c || (c = !0, u && e.clearTimeout(u), r = void 0, o = a || "", C.readyState = t > 0 ? 4 : 0, l = t >= 200 && 300 > t || 304 === t, i && (b = st(p, C, i)), !l && Et.inArray("script", p.dataTypes) > -1 && (p.converters["text script"] = function() {}), b = ot(p, b, C, l), l ? (p.ifModified && (_ = C.getResponseHeader("Last-Modified"), _ && (Et.lastModified[s] = _), _ = C.getResponseHeader("etag"), _ && (Et.etag[s] = _)), 204 === t || "HEAD" === p.type ? x = "nocontent" : 304 === t ? x = "notmodified" : (x = b.state, f = b.data, h = b.error, l = !h)) : (h = x, (t || !x) && (x = "error", 0 > t && (t = 0))), C.status = t, C.statusText = (n || x) + "", l ? y.resolveWith(m, [f, x, C]) : y.rejectWith(m, [C, x, h]), C.statusCode(w), w = void 0, d && g.trigger(l ? "ajaxSuccess" : "ajaxError", [C, p, l ? f : h]), v.fireWith(m, [C, x]), d && (g.trigger("ajaxComplete", [C, p]), --Et.active || Et.event.trigger("ajaxStop")))
            }
            "object" == typeof t && (n = t, t = void 0), n = n || {};
            var r, s, o, a, u, l, c, d, f, h, p = Et.ajaxSetup({}, n),
                m = p.context || p,
                g = p.context && (m.nodeType || m.jquery) ? Et(m) : Et.event,
                y = Et.Deferred(),
                v = Et.Callbacks("once memory"),
                w = p.statusCode || {},
                b = {},
                _ = {},
                x = "canceled",
                C = {
                    readyState: 0,
                    getResponseHeader: function(e) {
                        var t;
                        if (c) {
                            if (!a)
                                for (a = {}; t = Wn.exec(o);) a[t[1].toLowerCase() + " "] = (a[t[1].toLowerCase() + " "] || []).concat(t[2]);
                            t = a[e.toLowerCase() + " "]
                        }
                        return null == t ? null : t.join(", ")
                    },
                    getAllResponseHeaders: function() {
                        return c ? o : null
                    },
                    setRequestHeader: function(e, t) {
                        return null == c && (e = _[e.toLowerCase()] = _[e.toLowerCase()] || e, b[e] = t), this
                    },
                    overrideMimeType: function(e) {
                        return null == c && (p.mimeType = e), this
                    },
                    statusCode: function(e) {
                        var t;
                        if (e)
                            if (c) C.always(e[C.status]);
                            else
                                for (t in e) w[t] = [w[t], e[t]];
                        return this
                    },
                    abort: function(e) {
                        var t = e || x;
                        return r && r.abort(t), i(0, t), this
                    }
                };
            if (y.promise(C), p.url = ((t || p.url || Dn.href) + "").replace(Gn, Dn.protocol + "//"), p.type = n.method || n.type || p.method || p.type, p.dataTypes = (p.dataType || "*").toLowerCase().match(Nt) || [""], null == p.crossDomain) {
                l = _t.createElement("a");
                try {
                    l.href = p.url, l.href = l.href, p.crossDomain = Jn.protocol + "//" + Jn.host != l.protocol + "//" + l.host
                } catch (E) {
                    p.crossDomain = !0
                }
            }
            if (p.data && p.processData && "string" != typeof p.data && (p.data = Et.param(p.data, p.traditional)), it(Yn, p, n, C), c) return C;
            d = Et.event && p.global, d && 0 === Et.active++ && Et.event.trigger("ajaxStart"), p.type = p.type.toUpperCase(), p.hasContent = !Un.test(p.type), s = p.url.replace(Hn, ""), p.hasContent ? p.data && p.processData && 0 === (p.contentType || "").indexOf("application/x-www-form-urlencoded") && (p.data = p.data.replace(Vn, "+")) : (h = p.url.slice(s.length), p.data && (p.processData || "string" == typeof p.data) && (s += (qn.test(s) ? "&" : "?") + p.data, delete p.data), p.cache === !1 && (s = s.replace(Bn, "$1"), h = (qn.test(s) ? "&" : "?") + "_=" + Nn.guid++ + h), p.url = s + h), p.ifModified && (Et.lastModified[s] && C.setRequestHeader("If-Modified-Since", Et.lastModified[s]), Et.etag[s] && C.setRequestHeader("If-None-Match", Et.etag[s])), (p.data && p.hasContent && p.contentType !== !1 || n.contentType) && C.setRequestHeader("Content-Type", p.contentType), C.setRequestHeader("Accept", p.dataTypes[0] && p.accepts[p.dataTypes[0]] ? p.accepts[p.dataTypes[0]] + ("*" !== p.dataTypes[0] ? ", " + Xn + "; q=0.01" : "") : p.accepts["*"]);
            for (f in p.headers) C.setRequestHeader(f, p.headers[f]);
            if (p.beforeSend && (p.beforeSend.call(m, C, p) === !1 || c)) return C.abort();
            if (x = "abort", v.add(p.complete), C.done(p.success), C.fail(p.error), r = it(Kn, p, n, C)) {
                if (C.readyState = 1, d && g.trigger("ajaxSend", [C, p]), c) return C;
                p.async && p.timeout > 0 && (u = e.setTimeout(function() {
                    C.abort("timeout")
                }, p.timeout));
                try {
                    c = !1, r.send(b, i)
                } catch (E) {
                    if (c) throw E;
                    i(-1, E)
                }
            } else i(-1, "No Transport");
            return C
        },
        getJSON: function(e, t, n) {
            return Et.get(e, t, n, "json")
        },
        getScript: function(e, t) {
            return Et.get(e, void 0, t, "script")
        }
    }), Et.each(["get", "post"], function(e, t) {
        Et[t] = function(e, n, i, r) {
            return wt(n) && (r = r || i, i = n, n = void 0), Et.ajax(Et.extend({
                url: e,
                type: t,
                dataType: r,
                data: n,
                success: i
            }, Et.isPlainObject(e) && e))
        }
    }), Et.ajaxPrefilter(function(e) {
        var t;
        for (t in e.headers) "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "")
    }), Et._evalUrl = function(e, t, n) {
        return Et.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            converters: {
                "text script": function() {}
            },
            dataFilter: function(e) {
                Et.globalEval(e, t, n)
            }
        })
    }, Et.fn.extend({
        wrapAll: function(e) {
            var t;
            return this[0] && (wt(e) && (e = e.call(this[0])), t = Et(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
                for (var e = this; e.firstElementChild;) e = e.firstElementChild;
                return e
            }).append(this)), this
        },
        wrapInner: function(e) {
            return this.each(wt(e) ? function(t) {
                Et(this).wrapInner(e.call(this, t))
            } : function() {
                var t = Et(this),
                    n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            })
        },
        wrap: function(e) {
            var t = wt(e);
            return this.each(function(n) {
                Et(this).wrapAll(t ? e.call(this, n) : e)
            })
        },
        unwrap: function(e) {
            return this.parent(e).not("body").each(function() {
                Et(this).replaceWith(this.childNodes)
            }), this
        }
    }), Et.expr.pseudos.hidden = function(e) {
        return !Et.expr.pseudos.visible(e)
    }, Et.expr.pseudos.visible = function(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }, Et.ajaxSettings.xhr = function() {
        try {
            return new e.XMLHttpRequest
        } catch (t) {}
    };
    var Qn = {
            0: 200,
            1223: 204
        },
        Zn = Et.ajaxSettings.xhr();
    vt.cors = !!Zn && "withCredentials" in Zn, vt.ajax = Zn = !!Zn, Et.ajaxTransport(function(t) {
        var n, i;
        return vt.cors || Zn && !t.crossDomain ? {
            send: function(r, s) {
                var o, a = t.xhr();
                if (a.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields)
                    for (o in t.xhrFields) a[o] = t.xhrFields[o];
                t.mimeType && a.overrideMimeType && a.overrideMimeType(t.mimeType), t.crossDomain || r["X-Requested-With"] || (r["X-Requested-With"] = "XMLHttpRequest");
                for (o in r) a.setRequestHeader(o, r[o]);
                n = function(e) {
                    return function() {
                        n && (n = i = a.onload = a.onerror = a.onabort = a.ontimeout = a.onreadystatechange = null, "abort" === e ? a.abort() : "error" === e ? "number" != typeof a.status ? s(0, "error") : s(a.status, a.statusText) : s(Qn[a.status] || a.status, a.statusText, "text" !== (a.responseType || "text") || "string" != typeof a.responseText ? {
                            binary: a.response
                        } : {
                            text: a.responseText
                        }, a.getAllResponseHeaders()))
                    }
                }, a.onload = n(), i = a.onerror = a.ontimeout = n("error"), void 0 !== a.onabort ? a.onabort = i : a.onreadystatechange = function() {
                    4 === a.readyState && e.setTimeout(function() {
                        n && i()
                    })
                }, n = n("abort");
                try {
                    a.send(t.hasContent && t.data || null)
                } catch (u) {
                    if (n) throw u
                }
            },
            abort: function() {
                n && n()
            }
        } : void 0
    }), Et.ajaxPrefilter(function(e) {
        e.crossDomain && (e.contents.script = !1)
    }), Et.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function(e) {
                return Et.globalEval(e), e
            }
        }
    }), Et.ajaxPrefilter("script", function(e) {
        void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
    }), Et.ajaxTransport("script", function(e) {
        if (e.crossDomain || e.scriptAttrs) {
            var t, n;
            return {
                send: function(i, r) {
                    t = Et("<script>").attr(e.scriptAttrs || {}).prop({
                        charset: e.scriptCharset,
                        src: e.url
                    }).on("load error", n = function(e) {
                        t.remove(), n = null, e && r("error" === e.type ? 404 : 200, e.type)
                    }), _t.head.appendChild(t[0])
                },
                abort: function() {
                    n && n()
                }
            }
        }
    });
    var ei = [],
        ti = /(=)\?(?=&|$)|\?\?/;
    Et.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = ei.pop() || Et.expando + "_" + Nn.guid++;
            return this[e] = !0, e
        }
    }), Et.ajaxPrefilter("json jsonp", function(t, n, i) {
        var r, s, o, a = t.jsonp !== !1 && (ti.test(t.url) ? "url" : "string" == typeof t.data && 0 === (t.contentType || "").indexOf("application/x-www-form-urlencoded") && ti.test(t.data) && "data");
        return a || "jsonp" === t.dataTypes[0] ? (r = t.jsonpCallback = wt(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, a ? t[a] = t[a].replace(ti, "$1" + r) : t.jsonp !== !1 && (t.url += (qn.test(t.url) ? "&" : "?") + t.jsonp + "=" + r), t.converters["script json"] = function() {
            return o || Et.error(r + " was not called"), o[0]
        }, t.dataTypes[0] = "json", s = e[r], e[r] = function() {
            o = arguments
        }, i.always(function() {
            void 0 === s ? Et(e).removeProp(r) : e[r] = s, t[r] && (t.jsonpCallback = n.jsonpCallback, ei.push(r)), o && wt(s) && s(o[0]), o = s = void 0
        }), "script") : void 0
    }), vt.createHTMLDocument = function() {
        var e = _t.implementation.createHTMLDocument("").body;
        return e.innerHTML = "<form></form><form></form>", 2 === e.childNodes.length
    }(), Et.parseHTML = function(e, t, n) {
        if ("string" != typeof e) return [];
        "boolean" == typeof t && (n = t, t = !1);
        var i, r, s;
        return t || (vt.createHTMLDocument ? (t = _t.implementation.createHTMLDocument(""), i = t.createElement("base"), i.href = _t.location.href, t.head.appendChild(i)) : t = _t), r = St.exec(e), s = !n && [], r ? [t.createElement(r[1])] : (r = C([e], t, s), s && s.length && Et(s).remove(), Et.merge([], r.childNodes))
    }, Et.fn.load = function(e, t, n) {
        var i, r, s, o = this,
            a = e.indexOf(" ");
        return a > -1 && (i = Q(e.slice(a)), e = e.slice(0, a)), wt(t) ? (n = t, t = void 0) : t && "object" == typeof t && (r = "POST"), o.length > 0 && Et.ajax({
            url: e,
            type: r || "GET",
            dataType: "html",
            data: t
        }).done(function(e) {
            s = arguments, o.html(i ? Et("<div>").append(Et.parseHTML(e)).find(i) : e)
        }).always(n && function(e, t) {
            o.each(function() {
                n.apply(this, s || [e.responseText, t, e])
            })
        }), this
    }, Et.expr.pseudos.animated = function(e) {
        return Et.grep(Et.timers, function(t) {
            return e === t.elem
        }).length
    }, Et.offset = {
        setOffset: function(e, t, n) {
            var i, r, s, o, a, u, l, c = Et.css(e, "position"),
                d = Et(e),
                f = {};
            "static" === c && (e.style.position = "relative"), a = d.offset(), s = Et.css(e, "top"), u = Et.css(e, "left"), l = ("absolute" === c || "fixed" === c) && (s + u).indexOf("auto") > -1, l ? (i = d.position(), o = i.top, r = i.left) : (o = parseFloat(s) || 0, r = parseFloat(u) || 0), wt(t) && (t = t.call(e, n, Et.extend({}, a))), null != t.top && (f.top = t.top - a.top + o), null != t.left && (f.left = t.left - a.left + r), "using" in t ? t.using.call(e, f) : ("number" == typeof f.top && (f.top += "px"), "number" == typeof f.left && (f.left += "px"), d.css(f))
        }
    }, Et.fn.extend({
        offset: function(e) {
            if (arguments.length) return void 0 === e ? this : this.each(function(t) {
                Et.offset.setOffset(this, e, t)
            });
            var t, n, i = this[0];
            if (i) return i.getClientRects().length ? (t = i.getBoundingClientRect(), n = i.ownerDocument.defaultView, {
                top: t.top + n.pageYOffset,
                left: t.left + n.pageXOffset
            }) : {
                top: 0,
                left: 0
            }
        },
        position: function() {
            if (this[0]) {
                var e, t, n, i = this[0],
                    r = {
                        top: 0,
                        left: 0
                    };
                if ("fixed" === Et.css(i, "position")) t = i.getBoundingClientRect();
                else {
                    for (t = this.offset(), n = i.ownerDocument, e = i.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === Et.css(e, "position");) e = e.parentNode;
                    e && e !== i && 1 === e.nodeType && (r = Et(e).offset(), r.top += Et.css(e, "borderTopWidth", !0), r.left += Et.css(e, "borderLeftWidth", !0))
                }
                return {
                    top: t.top - r.top - Et.css(i, "marginTop", !0),
                    left: t.left - r.left - Et.css(i, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var e = this.offsetParent; e && "static" === Et.css(e, "position");) e = e.offsetParent;
                return e || Kt
            })
        }
    }), Et.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(e, t) {
        var n = "pageYOffset" === t;
        Et.fn[e] = function(i) {
            return Mt(this, function(e, i, r) {
                var s;
                return bt(e) ? s = e : 9 === e.nodeType && (s = e.defaultView), void 0 === r ? s ? s[t] : e[i] : void(s ? s.scrollTo(n ? s.pageXOffset : r, n ? r : s.pageYOffset) : e[i] = r)
            }, e, i, arguments.length)
        }
    }), Et.each(["top", "left"], function(e, t) {
        Et.cssHooks[t] = M(vt.pixelPosition, function(e, n) {
            return n ? (n = R(e, t), fn.test(n) ? Et(e).position()[t] + "px" : n) : void 0
        })
    }), Et.each({
        Height: "height",
        Width: "width"
    }, function(e, t) {
        Et.each({
            padding: "inner" + e,
            content: t,
            "": "outer" + e
        }, function(n, i) {
            Et.fn[i] = function(r, s) {
                var o = arguments.length && (n || "boolean" != typeof r),
                    a = n || (r === !0 || s === !0 ? "margin" : "border");
                return Mt(this, function(t, n, r) {
                    var s;
                    return bt(t) ? 0 === i.indexOf("outer") ? t["inner" + e] : t.document.documentElement["client" + e] : 9 === t.nodeType ? (s = t.documentElement, Math.max(t.body["scroll" + e], s["scroll" + e], t.body["offset" + e], s["offset" + e], s["client" + e])) : void 0 === r ? Et.css(t, n, a) : Et.style(t, n, r, a)
                }, t, o ? r : void 0, o)
            }
        })
    }), Et.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
        Et.fn[t] = function(e) {
            return this.on(t, e)
        }
    }), Et.fn.extend({
        bind: function(e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function(e, t) {
            return this.off(e, null, t)
        },
        delegate: function(e, t, n, i) {
            return this.on(t, e, n, i)
        },
        undelegate: function(e, t, n) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
        },
        hover: function(e, t) {
            return this.mouseenter(e).mouseleave(t || e)
        }
    }), Et.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(e, t) {
        Et.fn[t] = function(e, n) {
            return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
        }
    });
    var ni = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
    Et.proxy = function(e, t) {
        var n, i, r;
        return "string" == typeof t && (n = e[t], t = e, e = n), wt(e) ? (i = lt.call(arguments, 2), r = function() {
            return e.apply(t || this, i.concat(lt.call(arguments)))
        }, r.guid = e.guid = e.guid || Et.guid++, r) : void 0
    }, Et.holdReady = function(e) {
        e ? Et.readyWait++ : Et.ready(!0)
    }, Et.isArray = Array.isArray, Et.parseJSON = JSON.parse, Et.nodeName = s, Et.isFunction = wt, Et.isWindow = bt, Et.camelCase = p, Et.type = i, Et.now = Date.now, Et.isNumeric = function(e) {
        var t = Et.type(e);
        return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
    }, Et.trim = function(e) {
        return null == e ? "" : (e + "").replace(ni, "")
    }, "function" == typeof define && define.amd && define("jquery", [], function() {
        return Et
    });
    var ii = e.jQuery,
        ri = e.$;
    return Et.noConflict = function(t) {
        return e.$ === Et && (e.$ = ri), t && e.jQuery === Et && (e.jQuery = ii), Et
    }, "undefined" == typeof t && (e.jQuery = e.$ = Et), Et
}),
function() {
    function e(e) {
        function t(t, n, i, r, s, o) {
            for (; s >= 0 && o > s; s += e) {
                var a = r ? r[s] : s;
                i = n(i, t[a], a, t)
            }
            return i
        }
        return function(n, i, r, s) {
            i = v(i, s, 4);
            var o = !C(n) && y.keys(n),
                a = (o || n).length,
                u = e > 0 ? 0 : a - 1;
            return arguments.length < 3 && (r = n[o ? o[u] : u], u += e), t(n, i, r, o, u, a)
        }
    }

    function t(e) {
        return function(t, n, i) {
            n = w(n, i);
            for (var r = null != t && t.length, s = e > 0 ? 0 : r - 1; s >= 0 && r > s; s += e)
                if (n(t[s], s, t)) return s;
            return -1
        }
    }

    function n(e, t) {
        var n = $.length,
            i = e.constructor,
            r = y.isFunction(i) && i.prototype || o,
            s = "constructor";
        for (y.has(e, s) && !y.contains(t, s) && t.push(s); n--;) s = $[n], s in e && e[s] !== r[s] && !y.contains(t, s) && t.push(s)
    }
    var i = this,
        r = i._,
        s = Array.prototype,
        o = Object.prototype,
        a = Function.prototype,
        u = s.push,
        l = s.slice,
        c = o.toString,
        d = o.hasOwnProperty,
        f = Array.isArray,
        h = Object.keys,
        p = a.bind,
        m = Object.create,
        g = function() {},
        y = function(e) {
            return e instanceof y ? e : this instanceof y ? void(this._wrapped = e) : new y(e)
        };
    "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = y), exports._ = y) : i._ = y, y.VERSION = "1.8.2";
    var v = function(e, t, n) {
            if (void 0 === t) return e;
            switch (null == n ? 3 : n) {
                case 1:
                    return function(n) {
                        return e.call(t, n)
                    };
                case 2:
                    return function(n, i) {
                        return e.call(t, n, i)
                    };
                case 3:
                    return function(n, i, r) {
                        return e.call(t, n, i, r)
                    };
                case 4:
                    return function(n, i, r, s) {
                        return e.call(t, n, i, r, s)
                    }
            }
            return function() {
                return e.apply(t, arguments)
            }
        },
        w = function(e, t, n) {
            return null == e ? y.identity : y.isFunction(e) ? v(e, t, n) : y.isObject(e) ? y.matcher(e) : y.property(e)
        };
    y.iteratee = function(e, t) {
        return w(e, t, 1 / 0)
    };
    var b = function(e, t) {
            return function(n) {
                var i = arguments.length;
                if (2 > i || null == n) return n;
                for (var r = 1; i > r; r++)
                    for (var s = arguments[r], o = e(s), a = o.length, u = 0; a > u; u++) {
                        var l = o[u];
                        t && void 0 !== n[l] || (n[l] = s[l])
                    }
                return n
            }
        },
        _ = function(e) {
            if (!y.isObject(e)) return {};
            if (m) return m(e);
            g.prototype = e;
            var t = new g;
            return g.prototype = null, t
        },
        x = Math.pow(2, 53) - 1,
        C = function(e) {
            var t = e && e.length;
            return "number" == typeof t && t >= 0 && x >= t
        };
    y.each = y.forEach = function(e, t, n) {
        t = v(t, n);
        var i, r;
        if (C(e))
            for (i = 0, r = e.length; r > i; i++) t(e[i], i, e);
        else {
            var s = y.keys(e);
            for (i = 0, r = s.length; r > i; i++) t(e[s[i]], s[i], e)
        }
        return e
    }, y.map = y.collect = function(e, t, n) {
        t = w(t, n);
        for (var i = !C(e) && y.keys(e), r = (i || e).length, s = Array(r), o = 0; r > o; o++) {
            var a = i ? i[o] : o;
            s[o] = t(e[a], a, e)
        }
        return s
    }, y.reduce = y.foldl = y.inject = e(1), y.reduceRight = y.foldr = e(-1), y.find = y.detect = function(e, t, n) {
        var i;
        return i = C(e) ? y.findIndex(e, t, n) : y.findKey(e, t, n), void 0 !== i && -1 !== i ? e[i] : void 0
    }, y.filter = y.select = function(e, t, n) {
        var i = [];
        return t = w(t, n), y.each(e, function(e, n, r) {
            t(e, n, r) && i.push(e)
        }), i
    }, y.reject = function(e, t, n) {
        return y.filter(e, y.negate(w(t)), n)
    }, y.every = y.all = function(e, t, n) {
        t = w(t, n);
        for (var i = !C(e) && y.keys(e), r = (i || e).length, s = 0; r > s; s++) {
            var o = i ? i[s] : s;
            if (!t(e[o], o, e)) return !1
        }
        return !0
    }, y.some = y.any = function(e, t, n) {
        t = w(t, n);
        for (var i = !C(e) && y.keys(e), r = (i || e).length, s = 0; r > s; s++) {
            var o = i ? i[s] : s;
            if (t(e[o], o, e)) return !0
        }
        return !1
    }, y.contains = y.includes = y.include = function(e, t, n) {
        return C(e) || (e = y.values(e)), y.indexOf(e, t, "number" == typeof n && n) >= 0
    }, y.invoke = function(e, t) {
        var n = l.call(arguments, 2),
            i = y.isFunction(t);
        return y.map(e, function(e) {
            var r = i ? t : e[t];
            return null == r ? r : r.apply(e, n)
        })
    }, y.pluck = function(e, t) {
        return y.map(e, y.property(t))
    }, y.where = function(e, t) {
        return y.filter(e, y.matcher(t))
    }, y.findWhere = function(e, t) {
        return y.find(e, y.matcher(t))
    }, y.max = function(e, t, n) {
        var i, r, s = -1 / 0,
            o = -1 / 0;
        if (null == t && null != e) {
            e = C(e) ? e : y.values(e);
            for (var a = 0, u = e.length; u > a; a++) i = e[a], i > s && (s = i)
        } else t = w(t, n), y.each(e, function(e, n, i) {
            r = t(e, n, i), (r > o || r === -1 / 0 && s === -1 / 0) && (s = e, o = r)
        });
        return s
    }, y.min = function(e, t, n) {
        var i, r, s = 1 / 0,
            o = 1 / 0;
        if (null == t && null != e) {
            e = C(e) ? e : y.values(e);
            for (var a = 0, u = e.length; u > a; a++) i = e[a], s > i && (s = i)
        } else t = w(t, n), y.each(e, function(e, n, i) {
            r = t(e, n, i), (o > r || 1 / 0 === r && 1 / 0 === s) && (s = e, o = r)
        });
        return s
    }, y.shuffle = function(e) {
        for (var t, n = C(e) ? e : y.values(e), i = n.length, r = Array(i), s = 0; i > s; s++) t = y.random(0, s), t !== s && (r[s] = r[t]), r[t] = n[s];
        return r
    }, y.sample = function(e, t, n) {
        return null == t || n ? (C(e) || (e = y.values(e)), e[y.random(e.length - 1)]) : y.shuffle(e).slice(0, Math.max(0, t))
    }, y.sortBy = function(e, t, n) {
        return t = w(t, n), y.pluck(y.map(e, function(e, n, i) {
            return {
                value: e,
                index: n,
                criteria: t(e, n, i)
            }
        }).sort(function(e, t) {
            var n = e.criteria,
                i = t.criteria;
            if (n !== i) {
                if (n > i || void 0 === n) return 1;
                if (i > n || void 0 === i) return -1
            }
            return e.index - t.index
        }), "value")
    };
    var E = function(e) {
        return function(t, n, i) {
            var r = {};
            return n = w(n, i), y.each(t, function(i, s) {
                var o = n(i, s, t);
                e(r, i, o)
            }), r
        }
    };
    y.groupBy = E(function(e, t, n) {
        y.has(e, n) ? e[n].push(t) : e[n] = [t]
    }), y.indexBy = E(function(e, t, n) {
        e[n] = t
    }), y.countBy = E(function(e, t, n) {
        y.has(e, n) ? e[n]++ : e[n] = 1
    }), y.toArray = function(e) {
        return e ? y.isArray(e) ? l.call(e) : C(e) ? y.map(e, y.identity) : y.values(e) : []
    }, y.size = function(e) {
        return null == e ? 0 : C(e) ? e.length : y.keys(e).length
    }, y.partition = function(e, t, n) {
        t = w(t, n);
        var i = [],
            r = [];
        return y.each(e, function(e, n, s) {
            (t(e, n, s) ? i : r).push(e)
        }), [i, r]
    }, y.first = y.head = y.take = function(e, t, n) {
        return null == e ? void 0 : null == t || n ? e[0] : y.initial(e, e.length - t)
    }, y.initial = function(e, t, n) {
        return l.call(e, 0, Math.max(0, e.length - (null == t || n ? 1 : t)))
    }, y.last = function(e, t, n) {
        return null == e ? void 0 : null == t || n ? e[e.length - 1] : y.rest(e, Math.max(0, e.length - t))
    }, y.rest = y.tail = y.drop = function(e, t, n) {
        return l.call(e, null == t || n ? 1 : t)
    }, y.compact = function(e) {
        return y.filter(e, y.identity)
    };
    var F = function(e, t, n, i) {
        for (var r = [], s = 0, o = i || 0, a = e && e.length; a > o; o++) {
            var u = e[o];
            if (C(u) && (y.isArray(u) || y.isArguments(u))) {
                t || (u = F(u, t, n));
                var l = 0,
                    c = u.length;
                for (r.length += c; c > l;) r[s++] = u[l++]
            } else n || (r[s++] = u)
        }
        return r
    };
    y.flatten = function(e, t) {
        return F(e, t, !1)
    }, y.without = function(e) {
        return y.difference(e, l.call(arguments, 1))
    }, y.uniq = y.unique = function(e, t, n, i) {
        if (null == e) return [];
        y.isBoolean(t) || (i = n, n = t, t = !1), null != n && (n = w(n, i));
        for (var r = [], s = [], o = 0, a = e.length; a > o; o++) {
            var u = e[o],
                l = n ? n(u, o, e) : u;
            t ? (o && s === l || r.push(u), s = l) : n ? y.contains(s, l) || (s.push(l), r.push(u)) : y.contains(r, u) || r.push(u)
        }
        return r
    }, y.union = function() {
        return y.uniq(F(arguments, !0, !0))
    }, y.intersection = function(e) {
        if (null == e) return [];
        for (var t = [], n = arguments.length, i = 0, r = e.length; r > i; i++) {
            var s = e[i];
            if (!y.contains(t, s)) {
                for (var o = 1; n > o && y.contains(arguments[o], s); o++);
                o === n && t.push(s)
            }
        }
        return t
    }, y.difference = function(e) {
        var t = F(arguments, !0, !0, 1);
        return y.filter(e, function(e) {
            return !y.contains(t, e)
        })
    }, y.zip = function() {
        return y.unzip(arguments)
    }, y.unzip = function(e) {
        for (var t = e && y.max(e, "length").length || 0, n = Array(t), i = 0; t > i; i++) n[i] = y.pluck(e, i);
        return n
    }, y.object = function(e, t) {
        for (var n = {}, i = 0, r = e && e.length; r > i; i++) t ? n[e[i]] = t[i] : n[e[i][0]] = e[i][1];
        return n
    }, y.indexOf = function(e, t, n) {
        var i = 0,
            r = e && e.length;
        if ("number" == typeof n) i = 0 > n ? Math.max(0, r + n) : n;
        else if (n && r) return i = y.sortedIndex(e, t), e[i] === t ? i : -1;
        if (t !== t) return y.findIndex(l.call(e, i), y.isNaN);
        for (; r > i; i++)
            if (e[i] === t) return i;
        return -1
    }, y.lastIndexOf = function(e, t, n) {
        var i = e ? e.length : 0;
        if ("number" == typeof n && (i = 0 > n ? i + n + 1 : Math.min(i, n + 1)), t !== t) return y.findLastIndex(l.call(e, 0, i), y.isNaN);
        for (; --i >= 0;)
            if (e[i] === t) return i;
        return -1
    }, y.findIndex = t(1), y.findLastIndex = t(-1), y.sortedIndex = function(e, t, n, i) {
        n = w(n, i, 1);
        for (var r = n(t), s = 0, o = e.length; o > s;) {
            var a = Math.floor((s + o) / 2);
            n(e[a]) < r ? s = a + 1 : o = a
        }
        return s
    }, y.range = function(e, t, n) {
        arguments.length <= 1 && (t = e || 0, e = 0), n = n || 1;
        for (var i = Math.max(Math.ceil((t - e) / n), 0), r = Array(i), s = 0; i > s; s++, e += n) r[s] = e;
        return r
    };
    var T = function(e, t, n, i, r) {
        if (!(i instanceof t)) return e.apply(n, r);
        var s = _(e.prototype),
            o = e.apply(s, r);
        return y.isObject(o) ? o : s
    };
    y.bind = function(e, t) {
        if (p && e.bind === p) return p.apply(e, l.call(arguments, 1));
        if (!y.isFunction(e)) throw new TypeError("Bind must be called on a function");
        var n = l.call(arguments, 2),
            i = function() {
                return T(e, i, t, this, n.concat(l.call(arguments)))
            };
        return i
    }, y.partial = function(e) {
        var t = l.call(arguments, 1),
            n = function() {
                for (var i = 0, r = t.length, s = Array(r), o = 0; r > o; o++) s[o] = t[o] === y ? arguments[i++] : t[o];
                for (; i < arguments.length;) s.push(arguments[i++]);
                return T(e, n, this, this, s)
            };
        return n
    }, y.bindAll = function(e) {
        var t, n, i = arguments.length;
        if (1 >= i) throw new Error("bindAll must be passed function names");
        for (t = 1; i > t; t++) n = arguments[t], e[n] = y.bind(e[n], e);
        return e
    }, y.memoize = function(e, t) {
        var n = function(i) {
            var r = n.cache,
                s = "" + (t ? t.apply(this, arguments) : i);
            return y.has(r, s) || (r[s] = e.apply(this, arguments)), r[s]
        };
        return n.cache = {}, n
    }, y.delay = function(e, t) {
        var n = l.call(arguments, 2);
        return setTimeout(function() {
            return e.apply(null, n)
        }, t)
    }, y.defer = y.partial(y.delay, y, 1), y.throttle = function(e, t, n) {
        var i, r, s, o = null,
            a = 0;
        n || (n = {});
        var u = function() {
            a = n.leading === !1 ? 0 : y.now(), o = null, s = e.apply(i, r), o || (i = r = null)
        };
        return function() {
            var l = y.now();
            a || n.leading !== !1 || (a = l);
            var c = t - (l - a);
            return i = this, r = arguments, 0 >= c || c > t ? (o && (clearTimeout(o), o = null), a = l, s = e.apply(i, r), o || (i = r = null)) : o || n.trailing === !1 || (o = setTimeout(u, c)), s
        }
    }, y.debounce = function(e, t, n) {
        var i, r, s, o, a, u = function() {
            var l = y.now() - o;
            t > l && l >= 0 ? i = setTimeout(u, t - l) : (i = null, n || (a = e.apply(s, r), i || (s = r = null)))
        };
        return function() {
            s = this, r = arguments, o = y.now();
            var l = n && !i;
            return i || (i = setTimeout(u, t)), l && (a = e.apply(s, r), s = r = null), a
        }
    }, y.wrap = function(e, t) {
        return y.partial(t, e)
    }, y.negate = function(e) {
        return function() {
            return !e.apply(this, arguments)
        }
    }, y.compose = function() {
        var e = arguments,
            t = e.length - 1;
        return function() {
            for (var n = t, i = e[t].apply(this, arguments); n--;) i = e[n].call(this, i);
            return i
        }
    }, y.after = function(e, t) {
        return function() {
            return --e < 1 ? t.apply(this, arguments) : void 0
        }
    }, y.before = function(e, t) {
        var n;
        return function() {
            return --e > 0 && (n = t.apply(this, arguments)), 1 >= e && (t = null), n
        }
    }, y.once = y.partial(y.before, 2);
    var k = !{
            toString: null
        }.propertyIsEnumerable("toString"),
        $ = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"];
    y.keys = function(e) {
        if (!y.isObject(e)) return [];
        if (h) return h(e);
        var t = [];
        for (var i in e) y.has(e, i) && t.push(i);
        return k && n(e, t), t
    }, y.allKeys = function(e) {
        if (!y.isObject(e)) return [];
        var t = [];
        for (var i in e) t.push(i);
        return k && n(e, t), t
    }, y.values = function(e) {
        for (var t = y.keys(e), n = t.length, i = Array(n), r = 0; n > r; r++) i[r] = e[t[r]];
        return i
    }, y.mapObject = function(e, t, n) {
        t = w(t, n);
        for (var i, r = y.keys(e), s = r.length, o = {}, a = 0; s > a; a++) i = r[a], o[i] = t(e[i], i, e);
        return o
    }, y.pairs = function(e) {
        for (var t = y.keys(e), n = t.length, i = Array(n), r = 0; n > r; r++) i[r] = [t[r], e[t[r]]];
        return i
    }, y.invert = function(e) {
        for (var t = {}, n = y.keys(e), i = 0, r = n.length; r > i; i++) t[e[n[i]]] = n[i];
        return t
    }, y.functions = y.methods = function(e) {
        var t = [];
        for (var n in e) y.isFunction(e[n]) && t.push(n);
        return t.sort()
    }, y.extend = b(y.allKeys), y.extendOwn = y.assign = b(y.keys), y.findKey = function(e, t, n) {
        t = w(t, n);
        for (var i, r = y.keys(e), s = 0, o = r.length; o > s; s++)
            if (i = r[s], t(e[i], i, e)) return i
    }, y.pick = function(e, t, n) {
        var i, r, s = {},
            o = e;
        if (null == o) return s;
        y.isFunction(t) ? (r = y.allKeys(o), i = v(t, n)) : (r = F(arguments, !1, !1, 1), i = function(e, t, n) {
            return t in n
        }, o = Object(o));
        for (var a = 0, u = r.length; u > a; a++) {
            var l = r[a],
                c = o[l];
            i(c, l, o) && (s[l] = c)
        }
        return s
    }, y.omit = function(e, t, n) {
        if (y.isFunction(t)) t = y.negate(t);
        else {
            var i = y.map(F(arguments, !1, !1, 1), String);
            t = function(e, t) {
                return !y.contains(i, t)
            }
        }
        return y.pick(e, t, n)
    }, y.defaults = b(y.allKeys, !0), y.clone = function(e) {
        return y.isObject(e) ? y.isArray(e) ? e.slice() : y.extend({}, e) : e
    }, y.tap = function(e, t) {
        return t(e), e
    }, y.isMatch = function(e, t) {
        var n = y.keys(t),
            i = n.length;
        if (null == e) return !i;
        for (var r = Object(e), s = 0; i > s; s++) {
            var o = n[s];
            if (t[o] !== r[o] || !(o in r)) return !1
        }
        return !0
    };
    var S = function(e, t, n, i) {
        if (e === t) return 0 !== e || 1 / e === 1 / t;
        if (null == e || null == t) return e === t;
        e instanceof y && (e = e._wrapped), t instanceof y && (t = t._wrapped);
        var r = c.call(e);
        if (r !== c.call(t)) return !1;
        switch (r) {
            case "[object RegExp]":
            case "[object String]":
                return "" + e == "" + t;
            case "[object Number]":
                return +e !== +e ? +t !== +t : 0 === +e ? 1 / +e === 1 / t : +e === +t;
            case "[object Date]":
            case "[object Boolean]":
                return +e === +t
        }
        var s = "[object Array]" === r;
        if (!s) {
            if ("object" != typeof e || "object" != typeof t) return !1;
            var o = e.constructor,
                a = t.constructor;
            if (o !== a && !(y.isFunction(o) && o instanceof o && y.isFunction(a) && a instanceof a) && "constructor" in e && "constructor" in t) return !1
        }
        n = n || [], i = i || [];
        for (var u = n.length; u--;)
            if (n[u] === e) return i[u] === t;
        if (n.push(e), i.push(t), s) {
            if (u = e.length, u !== t.length) return !1;
            for (; u--;)
                if (!S(e[u], t[u], n, i)) return !1
        } else {
            var l, d = y.keys(e);
            if (u = d.length, y.keys(t).length !== u) return !1;
            for (; u--;)
                if (l = d[u], !y.has(t, l) || !S(e[l], t[l], n, i)) return !1
        }
        return n.pop(), i.pop(), !0
    };
    y.isEqual = function(e, t) {
        return S(e, t)
    }, y.isEmpty = function(e) {
        return null == e ? !0 : C(e) && (y.isArray(e) || y.isString(e) || y.isArguments(e)) ? 0 === e.length : 0 === y.keys(e).length
    }, y.isElement = function(e) {
        return !(!e || 1 !== e.nodeType)
    }, y.isArray = f || function(e) {
        return "[object Array]" === c.call(e)
    }, y.isObject = function(e) {
        var t = typeof e;
        return "function" === t || "object" === t && !!e
    }, y.each(["Arguments", "Function", "String", "Number", "Date", "RegExp", "Error"], function(e) {
        y["is" + e] = function(t) {
            return c.call(t) === "[object " + e + "]"
        }
    }), y.isArguments(arguments) || (y.isArguments = function(e) {
        return y.has(e, "callee")
    }), "function" != typeof /./ && "object" != typeof Int8Array && (y.isFunction = function(e) {
        return "function" == typeof e || !1
    }), y.isFinite = function(e) {
        return isFinite(e) && !isNaN(parseFloat(e))
    }, y.isNaN = function(e) {
        return y.isNumber(e) && e !== +e
    }, y.isBoolean = function(e) {
        return e === !0 || e === !1 || "[object Boolean]" === c.call(e)
    }, y.isNull = function(e) {
        return null === e
    }, y.isUndefined = function(e) {
        return void 0 === e
    }, y.has = function(e, t) {
        return null != e && d.call(e, t)
    }, y.noConflict = function() {
        return i._ = r, this
    }, y.identity = function(e) {
        return e
    }, y.constant = function(e) {
        return function() {
            return e
        }
    }, y.noop = function() {}, y.property = function(e) {
        return function(t) {
            return null == t ? void 0 : t[e]
        }
    }, y.propertyOf = function(e) {
        return null == e ? function() {} : function(t) {
            return e[t]
        }
    }, y.matcher = y.matches = function(e) {
        return e = y.extendOwn({}, e),
            function(t) {
                return y.isMatch(t, e)
            }
    }, y.times = function(e, t, n) {
        var i = Array(Math.max(0, e));
        t = v(t, n, 1);
        for (var r = 0; e > r; r++) i[r] = t(r);
        return i
    }, y.random = function(e, t) {
        return null == t && (t = e, e = 0), e + Math.floor(Math.random() * (t - e + 1))
    }, y.now = Date.now || function() {
        return (new Date).getTime()
    };
    var j = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#x27;",
            "`": "&#x60;"
        },
        A = y.invert(j),
        O = function(e) {
            var t = function(t) {
                    return e[t]
                },
                n = "(?:" + y.keys(e).join("|") + ")",
                i = RegExp(n),
                r = RegExp(n, "g");
            return function(e) {
                return e = null == e ? "" : "" + e, i.test(e) ? e.replace(r, t) : e
            }
        };
    y.escape = O(j), y.unescape = O(A), y.result = function(e, t, n) {
        var i = null == e ? void 0 : e[t];
        return void 0 === i && (i = n), y.isFunction(i) ? i.call(e) : i
    };
    var P = 0;
    y.uniqueId = function(e) {
        var t = ++P + "";
        return e ? e + t : t
    }, y.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
    };
    var D = /(.)^/,
        N = {
            "'": "'",
            "\\": "\\",
            "\r": "r",
            "\n": "n",
            "\u2028": "u2028",
            "\u2029": "u2029"
        },
        q = /\\|'|\r|\n|\u2028|\u2029/g,
        R = function(e) {
            return "\\" + N[e]
        };
    y.template = function(e, t, n) {
        !t && n && (t = n), t = y.defaults({}, t, y.templateSettings);
        var i = RegExp([(t.escape || D).source, (t.interpolate || D).source, (t.evaluate || D).source].join("|") + "|$", "g"),
            r = 0,
            s = "__p+='";
        e.replace(i, function(t, n, i, o, a) {
            return s += e.slice(r, a).replace(q, R), r = a + t.length, n ? s += "'+\n((__t=(" + n + "))==null?'':_.escape(__t))+\n'" : i ? s += "'+\n((__t=(" + i + "))==null?'':__t)+\n'" : o && (s += "';\n" + o + "\n__p+='"), t
        }), s += "';\n", t.variable || (s = "with(obj||{}){\n" + s + "}\n"), s = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + s + "return __p;\n";
        try {
            var o = new Function(t.variable || "obj", "_", s)
        } catch (a) {
            throw a.source = s, a
        }
        var u = function(e) {
                return o.call(this, e, y)
            },
            l = t.variable || "obj";
        return u.source = "function(" + l + "){\n" + s + "}", u
    }, y.chain = function(e) {
        var t = y(e);
        return t._chain = !0, t
    };
    var M = function(e, t) {
        return e._chain ? y(t).chain() : t
    };
    y.mixin = function(e) {
        y.each(y.functions(e), function(t) {
            var n = y[t] = e[t];
            y.prototype[t] = function() {
                var e = [this._wrapped];
                return u.apply(e, arguments), M(this, n.apply(y, e))
            }
        })
    }, y.mixin(y), y.each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(e) {
        var t = s[e];
        y.prototype[e] = function() {
            var n = this._wrapped;
            return t.apply(n, arguments), "shift" !== e && "splice" !== e || 0 !== n.length || delete n[0], M(this, n)
        }
    }), y.each(["concat", "join", "slice"], function(e) {
        var t = s[e];
        y.prototype[e] = function() {
            return M(this, t.apply(this._wrapped, arguments))
        }
    }), y.prototype.value = function() {
        return this._wrapped
    }, y.prototype.valueOf = y.prototype.toJSON = y.prototype.value, y.prototype.toString = function() {
        return "" + this._wrapped
    }, "function" == typeof define && define.amd && define("underscore", [], function() {
        return y
    })
}.call(this),
    function(e, t) {
        "use strict";
        e.rails !== t && e.error("jquery-ujs has already been loaded!");
        var n, i = e(document);
        e.rails = n = {
            linkClickSelector: "a[data-confirm], a[data-method], a[data-remote]:not([disabled]), a[data-disable-with], a[data-disable]",
            buttonClickSelector: "button[data-remote]:not([form]):not(form button), button[data-confirm]:not([form]):not(form button)",
            inputChangeSelector: "select[data-remote], input[data-remote], textarea[data-remote]",
            formSubmitSelector: "form",
            formInputClickSelector: "form input[type=submit], form input[type=image], form button[type=submit], form button:not([type]), input[type=submit][form], input[type=image][form], button[type=submit][form], button[form]:not([type])",
            disableSelector: "input[data-disable-with]:enabled, button[data-disable-with]:enabled, textarea[data-disable-with]:enabled, input[data-disable]:enabled, button[data-disable]:enabled, textarea[data-disable]:enabled",
            enableSelector: "input[data-disable-with]:disabled, button[data-disable-with]:disabled, textarea[data-disable-with]:disabled, input[data-disable]:disabled, button[data-disable]:disabled, textarea[data-disable]:disabled",
            requiredInputSelector: "input[name][required]:not([disabled]), textarea[name][required]:not([disabled])",
            fileInputSelector: "input[name][type=file]:not([disabled])",
            linkDisableSelector: "a[data-disable-with], a[data-disable]",
            buttonDisableSelector: "button[data-remote][data-disable-with], button[data-remote][data-disable]",
            csrfToken: function() {
                return e("meta[name=csrf-token]").attr("content")
            },
            csrfParam: function() {
                return e("meta[name=csrf-param]").attr("content")
            },
            CSRFProtection: function(e) {
                var t = n.csrfToken();
                t && e.setRequestHeader("X-CSRF-Token", t)
            },
            refreshCSRFTokens: function() {
                e('form input[name="' + n.csrfParam() + '"]').val(n.csrfToken())
            },
            fire: function(t, n, i) {
                var r = e.Event(n);
                return t.trigger(r, i), r.result !== !1
            },
            confirm: function(e) {
                return confirm(e)
            },
            ajax: function(t) {
                return e.ajax(t)
            },
            href: function(e) {
                return e[0].href
            },
            isRemote: function(e) {
                return e.data("remote") !== t && e.data("remote") !== !1
            },
            handleRemote: function(i) {
                var r, s, o, a, u, l;
                if (n.fire(i, "ajax:before")) {
                    if (a = i.data("with-credentials") || null, u = i.data("type") || e.ajaxSettings && e.ajaxSettings.dataType, i.is("form")) {
                        r = i.data("ujs:submit-button-formmethod") || i.attr("method"), s = i.data("ujs:submit-button-formaction") || i.attr("action"), o = e(i[0]).serializeArray();
                        var c = i.data("ujs:submit-button");
                        c && (o.push(c), i.data("ujs:submit-button", null)), i.data("ujs:submit-button-formmethod", null), i.data("ujs:submit-button-formaction", null)
                    } else i.is(n.inputChangeSelector) ? (r = i.data("method"), s = i.data("url"), o = i.serialize(), i.data("params") && (o = o + "&" + i.data("params"))) : i.is(n.buttonClickSelector) ? (r = i.data("method") || "get", s = i.data("url"), o = i.serialize(), i.data("params") && (o = o + "&" + i.data("params"))) : (r = i.data("method"), s = n.href(i), o = i.data("params") || null);
                    return l = {
                        type: r || "GET",
                        data: o,
                        dataType: u,
                        beforeSend: function(e, r) {
                            return r.dataType === t && e.setRequestHeader("accept", "*/*;q=0.5, " + r.accepts.script), n.fire(i, "ajax:beforeSend", [e, r]) ? void i.trigger("ajax:send", e) : !1
                        },
                        success: function(e, t, n) {
                            i.trigger("ajax:success", [e, t, n])
                        },
                        complete: function(e, t) {
                            i.trigger("ajax:complete", [e, t])
                        },
                        error: function(e, t, n) {
                            i.trigger("ajax:error", [e, t, n])
                        },
                        crossDomain: n.isCrossDomain(s)
                    }, a && (l.xhrFields = {
                        withCredentials: a
                    }), s && (l.url = s), n.ajax(l)
                }
                return !1
            },
            isCrossDomain: function(e) {
                var t = document.createElement("a");
                t.href = location.href;
                var n = document.createElement("a");
                try {
                    return n.href = e, n.href = n.href, !((!n.protocol || ":" === n.protocol) && !n.host || t.protocol + "//" + t.host == n.protocol + "//" + n.host)
                } catch (i) {
                    return !0
                }
            },
            handleMethod: function(i) {
                var r = n.href(i),
                    s = i.data("method"),
                    o = i.attr("target"),
                    a = n.csrfToken(),
                    u = n.csrfParam(),
                    l = e('<form method="post" action="' + r + '"></form>'),
                    c = '<input name="_method" value="' + s + '" type="hidden" />';
                u === t || a === t || n.isCrossDomain(r) || (c += '<input name="' + u + '" value="' + a + '" type="hidden" />'), o && l.attr("target", o), l.hide().append(c).appendTo("body"), l.submit()
            },
            formElements: function(t, n) {
                return t.is("form") ? e(t[0].elements).filter(n) : t.find(n)
            },
            disableFormElements: function(t) {
                n.formElements(t, n.disableSelector).each(function() {
                    n.disableFormElement(e(this))
                })
            },
            disableFormElement: function(e) {
                var n, i;
                n = e.is("button") ? "html" : "val", i = e.data("disable-with"), i !== t && (e.data("ujs:enable-with", e[n]()), e[n](i)), e.prop("disabled", !0), e.data("ujs:disabled", !0)
            },
            enableFormElements: function(t) {
                n.formElements(t, n.enableSelector).each(function() {
                    n.enableFormElement(e(this))
                })
            },
            enableFormElement: function(e) {
                var n = e.is("button") ? "html" : "val";
                e.data("ujs:enable-with") !== t && (e[n](e.data("ujs:enable-with")), e.removeData("ujs:enable-with")), e.prop("disabled", !1), e.removeData("ujs:disabled")
            },
            allowAction: function(e) {
                var t, i = e.data("confirm"),
                    r = !1;
                if (!i) return !0;
                if (n.fire(e, "confirm")) {
                    try {
                        r = n.confirm(i)
                    } catch (s) {
                        (console.error || console.log).call(console, s.stack || s)
                    }
                    t = n.fire(e, "confirm:complete", [r])
                }
                return r && t
            },
            blankInputs: function(t, n, i) {
                var r, s, o, a, u = e(),
                    l = n || "input,textarea",
                    c = t.find(l),
                    d = {};
                return c.each(function() {
                    r = e(this), r.is("input[type=radio]") ? (a = r.attr("name"), d[a] || (0 === t.find('input[type=radio]:checked[name="' + a + '"]').length && (o = t.find('input[type=radio][name="' + a + '"]'), u = u.add(o)), d[a] = a)) : (s = r.is("input[type=checkbox],input[type=radio]") ? r.is(":checked") : !!r.val(), s === i && (u = u.add(r)))
                }), u.length ? u : !1
            },
            nonBlankInputs: function(e, t) {
                return n.blankInputs(e, t, !0)
            },
            stopEverything: function(t) {
                return e(t.target).trigger("ujs:everythingStopped"), t.stopImmediatePropagation(), !1
            },
            disableElement: function(e) {
                var i = e.data("disable-with");
                i !== t && (e.data("ujs:enable-with", e.html()), e.html(i)), e.bind("click.railsDisable", function(e) {
                    return n.stopEverything(e)
                }), e.data("ujs:disabled", !0)
            },
            enableElement: function(e) {
                e.data("ujs:enable-with") !== t && (e.html(e.data("ujs:enable-with")), e.removeData("ujs:enable-with")), e.unbind("click.railsDisable"), e.removeData("ujs:disabled")
            }
        }, n.fire(i, "rails:attachBindings") && (e.ajaxPrefilter(function(e, t, i) {
            e.crossDomain || n.CSRFProtection(i)
        }), e(window).on("pageshow.rails", function() {
            e(e.rails.enableSelector).each(function() {
                var t = e(this);
                t.data("ujs:disabled") && e.rails.enableFormElement(t)
            }), e(e.rails.linkDisableSelector).each(function() {
                var t = e(this);
                t.data("ujs:disabled") && e.rails.enableElement(t)
            })
        }), i.on("ajax:complete", n.linkDisableSelector, function() {
            n.enableElement(e(this))
        }), i.on("ajax:complete", n.buttonDisableSelector, function() {
            n.enableFormElement(e(this))
        }), i.on("click.rails", n.linkClickSelector, function(t) {
            var i = e(this),
                r = i.data("method"),
                s = i.data("params"),
                o = t.metaKey || t.ctrlKey;
            if (!n.allowAction(i)) return n.stopEverything(t);
            if (!o && i.is(n.linkDisableSelector) && n.disableElement(i), n.isRemote(i)) {
                if (o && (!r || "GET" === r) && !s) return !0;
                var a = n.handleRemote(i);
                return a === !1 ? n.enableElement(i) : a.fail(function() {
                    n.enableElement(i)
                }), !1
            }
            return r ? (n.handleMethod(i), !1) : void 0
        }), i.on("click.rails", n.buttonClickSelector, function(t) {
            var i = e(this);
            if (!n.allowAction(i) || !n.isRemote(i)) return n.stopEverything(t);
            i.is(n.buttonDisableSelector) && n.disableFormElement(i);
            var r = n.handleRemote(i);
            return r === !1 ? n.enableFormElement(i) : r.fail(function() {
                n.enableFormElement(i)
            }), !1
        }), i.on("change.rails", n.inputChangeSelector, function(t) {
            var i = e(this);
            return n.allowAction(i) && n.isRemote(i) ? (n.handleRemote(i), !1) : n.stopEverything(t)
        }), i.on("submit.rails", n.formSubmitSelector, function(i) {
            var r, s, o = e(this),
                a = n.isRemote(o);
            if (!n.allowAction(o)) return n.stopEverything(i);
            if (o.attr("novalidate") === t)
                if (o.data("ujs:formnovalidate-button") === t) {
                    if (r = n.blankInputs(o, n.requiredInputSelector, !1), r && n.fire(o, "ajax:aborted:required", [r])) return n.stopEverything(i)
                } else o.data("ujs:formnovalidate-button", t);
            if (a) {
                if (s = n.nonBlankInputs(o, n.fileInputSelector)) {
                    setTimeout(function() {
                        n.disableFormElements(o)
                    }, 13);
                    var u = n.fire(o, "ajax:aborted:file", [s]);
                    return u || setTimeout(function() {
                        n.enableFormElements(o)
                    }, 13), u
                }
                return n.handleRemote(o), !1
            }
            setTimeout(function() {
                n.disableFormElements(o)
            }, 13)
        }), i.on("click.rails", n.formInputClickSelector, function(t) {
            var i = e(this);
            if (!n.allowAction(i)) return n.stopEverything(t);
            var r = i.attr("name"),
                s = r ? {
                    name: r,
                    value: i.val()
                } : null,
                o = i.closest("form");
            0 === o.length && (o = e("#" + i.attr("form"))), o.data("ujs:submit-button", s), o.data("ujs:formnovalidate-button", i.attr("formnovalidate")), o.data("ujs:submit-button-formaction", i.attr("formaction")), o.data("ujs:submit-button-formmethod", i.attr("formmethod"))
        }), i.on("ajax:send.rails", n.formSubmitSelector, function(t) {
            this === t.target && n.disableFormElements(e(this))
        }), i.on("ajax:complete.rails", n.formSubmitSelector, function(t) {
            this === t.target && n.enableFormElements(e(this))
        }), e(function() {
            n.refreshCSRFTokens()
        }))
    }(jQuery),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e("object" == typeof exports ? require("jquery") : jQuery)
    }(function(e) {
        function t(e) {
            return a.raw ? e : encodeURIComponent(e)
        }

        function n(e) {
            return a.raw ? e : decodeURIComponent(e)
        }

        function i(e) {
            return t(a.json ? JSON.stringify(e) : String(e))
        }

        function r(e) {
            0 === e.indexOf('"') && (e = e.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\"));
            try {
                return e = decodeURIComponent(e.replace(o, " ")), a.json ? JSON.parse(e) : e
            } catch (t) {}
        }

        function s(t, n) {
            var i = a.raw ? t : r(t);
            return e.isFunction(n) ? n(i) : i
        }
        var o = /\+/g,
            a = e.cookie = function(r, o, u) {
                if (void 0 !== o && !e.isFunction(o)) {
                    if (u = e.extend({}, a.defaults, u), "number" == typeof u.expires) {
                        var l = u.expires,
                            c = u.expires = new Date;
                        c.setTime(+c + 864e5 * l)
                    }
                    return document.cookie = [t(r), "=", i(o), u.expires ? "; expires=" + u.expires.toUTCString() : "", u.path ? "; path=" + u.path : "", u.domain ? "; domain=" + u.domain : "", u.secure ? "; secure" : ""].join("")
                }
                for (var d = r ? void 0 : {}, f = document.cookie ? document.cookie.split("; ") : [], h = 0, p = f.length; p > h; h++) {
                    var m = f[h].split("="),
                        g = n(m.shift()),
                        y = m.join("=");
                    if (r && r === g) {
                        d = s(y, o);
                        break
                    }
                    r || void 0 === (y = s(y)) || (d[g] = y)
                }
                return d
            };
        a.defaults = {}, e.removeCookie = function(t, n) {
            return void 0 === e.cookie(t) ? !1 : (e.cookie(t, "", e.extend({}, n, {
                expires: -1
            })), !e.cookie(t))
        }
    }), $(document).on("page:update", function() {
        $(document).install("product_tracking", function() {
            productTrackingListeners(), productTrackingVideoSetup()
        })
    }), $(window).on("message", function(e) {
        var t = e.originalEvent.data;
        t && t.type && $(window).trigger("message:" + t.type, t)
    }), ThemeEditorBindings = function() {
        this.editing = !0, $(window).on("message:reload", this.reload.bind(this)), $(window).on("message:reloadSection", this.reloadSection.bind(this)), $(window).on("message:reloadSettings", this.reloadSettings.bind(this)), $(window).on("message:reorderSection", this.reorderSection.bind(this)), $(window).on("message:removeSection", this.removeSection.bind(this)), $(window).on("message:addSection", this.addSection.bind(this)), $(window).on("message:scrollToSection", this.scrollToSection.bind(this)), $(window).on("message:scrollToBlock", this.scrollToBlock.bind(this)), $(window).on("message:highlightSection", this.highlightSection.bind(this)), $(window).on("message:endHighlight", this.endHighlight.bind(this)), $(window).on("message:toggleEditing", this.toggleEditing.bind(this));
        var e = this.isClickableElement.bind(this);
        $(window).on("click", function(t) {
            e(t.target) || t.preventDefault()
        }), $(document).on({
            mouseenter: this.onMouseEnter.bind(this),
            mouseleave: this.onMouseLeave.bind(this),
            click: this.onClick.bind(this)
        }, "[kjb-settings-id]"), $("[data-method]").each(function(e, t) {
            t.removeAttribute("data-method")
        }), $("[href='#two-step']").each(function(e, t) {
            t.removeAttribute("href")
        }), $("body").append("<div id='editor-overlay'><div class='editor-overlay-button'>Edit</div></div>"), $("body").attr("data-kjb-editing", this.editing)
    }, ThemeEditorBindings.prototype = {
        reload: function() {
            window.location.reload()
        },
        reloadSection: function(e, t) {
            var n = this,
                i = t.overrides;
            i.overrides && i.overrides.block_order && !i.overrides.block_order.length && (i.overrides.block_order = [""]);
            var r = $.extend({
                theme_section_type: t.sectionType,
                theme_section_id: t.id,
                _method: "GET"
            }, i);
            $.post("", r, function(e) {
                n.section(t.id).replaceWith(e), n.postMessage("finishedLoadingSection"), $(window).trigger("section:reload", t)
            })
        },
        reloadSettings: function(e, t) {
            var n = new URLSearchParams(location.search);
            t.settingsOverrides && n.set("settings_overrides", JSON.stringify(t.settingsOverrides)), window.location.href = window.location.pathname + "?" + n.toString()
        },
        reorderSection: function(e, t) {
            var n = this.section(t.id),
                i = this.section(t.nextId);
            i.length ? n.insertBefore(i) : $("[data-dynamic-sections]").append(n), this.scrollTo(n)
        },
        removeSection: function(e, t) {
            this.section(t.id).remove()
        },
        findNextSection: function(e, t) {
            var n = t.findIndex(function(t) {
                return t === e
            });
            return this.section(t[n + 1])
        },
        addSection: function(e, t) {
            var n = this,
                i = this.scrollTo,
                r = t.overrides,
                s = this.findNextSection(t.id, t.sectionOrder || []),
                o = {
                    theme_section_type: t.sectionType,
                    theme_section_id: t.id,
                    _method: "GET"
                };
            r && -1 === _.keys(r)[0].indexOf("override") ? o.overrides = r : $.extend(o, r), $.post("", o, function(e) {
                var t = $(e);
                s.length ? s.before(t) : $("[data-dynamic-sections]").append(t), i(t), n.postMessage("finishedLoadingSection")
            })
        },
        scrollToBlock: function(e, t) {
            var n = $("#block-" + t.id);
            n.length && !n.find("[data-kjb-inline-editing-active]").length && this.scrollTo(n)
        },
        scrollToSection: function(e, t) {
            var n = this.section(t.id);
            n.length && !n.find("[data-kjb-inline-editing-active]").length && this.scrollTo(n)
        },
        highlightSection: function(e, t) {
            $("[data-section-id]").css("opacity", .3);
            var n = this.section(t.id);
            n.css("opacity", 1), n.css("box-shadow", "0 5px 45px 5px rgba(0, 0, 0, 0.3)"), this.scrollTo(n)
        },
        endHighlight: function() {
            $("[data-section-id]").removeAttr("style")
        },
        toggleEditing: function(e, t) {
            this.editing = t.edit, $("body").attr("data-kjb-editing", !!this.editing)
        },
        scrollTo: function(e) {
            var t = $(window),
                n = $(e),
                i = n.offset().top,
                r = n.height(),
                s = t.height(),
                o = i - (s - r) / 2;
            $("html, body").stop().animate({
                scrollTop: o
            })
        },
        section: function(e) {
            return $("[data-section-id='" + e + "']")
        },
        postMessage: function(e, t) {
            t = t || {}, t.type = e, window.parent.postMessage(t, "*")
        },
        isClickableElement: function(e) {
            return e.hasAttribute("data-kjb-clickable") && !e.hasAttribute("kjb-settings-id")
        },
        disableEditorOverlay: function(e) {
            return e.hasAttribute("data-kjb-disable-editor-overlay") || null !== e.querySelector("[data-kjb-inline-editing-active]")
        },
        onMouseEnter: function(e) {
            if (this.editing && !this.disableEditorOverlay(e.currentTarget)) {
                var t = $(e.currentTarget);
                $("#editor-overlay").css({
                    width: t.outerWidth() + 16,
                    height: t.outerHeight() + 16,
                    top: t.offset().top - 8,
                    left: t.offset().left - 8
                }).show()
            }
        },
        onMouseLeave: function() {
            $("#editor-overlay").hide()
        },
        onClick: function(e) {
            this.editing && (this.isClickableElement(e.target) || (e.preventDefault(), e.stopPropagation(), this.postMessage("editSetting", {
                setting: e.currentTarget.getAttribute("kjb-settings-id")
            })))
        }
    },
    function() {
        ThemeMedias = function() {
            this.loadedScripts = {}, this.isMobileView = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent), this.wistiaScriptOptions = {
                charset: "ISO-8859-1"
            }, this.wistiaScriptUrl = "https://fast.wistia.com/assets/external/E-v1.js", this.wistiaPluginUrls = {
                cropFill: "https://fast.wistia.com/labs/crop-fill/plugin.js"
            }, this.intersectionObserverOptions = {
                rootMargin: "300px 0px",
                threshold: .01
            }
        }, ThemeMedias.prototype = {
            loadScript: function(e, t) {
                return this.loadedScripts[e] ? this.loadedScripts[e] : this.loadedScripts[e] = new Promise(function(n, i) {
                    var r = document.createElement("script");
                    r.defer = !0, r.src = e, t && t.charset && (r.charset = t.charset), r.onload = function() {
                        n(r)
                    }, r.onerror = function() {
                        i(new Error("Failed to load script " + e))
                    }, document.head.appendChild(r)
                })
            },
            loadWistiaPlugins: function(e) {
                if (!e || !e.length) return Promise.resolve();
                var t = this,
                    n = e.map(function(e) {
                        return t.loadScript(t.wistiaPluginUrls[e], t.wistiaScriptOptions)
                    });
                return Promise.all(n)
            },
            loadWistiaScript: function(e, t) {
                var n = this,
                    i = function(e) {
                        console.error(e)
                    },
                    r = t && t.plugins || [],
                    s = e || function() {};
                "undefined" != typeof Wistia && Wistia.embed ? n.loadWistiaPlugins(r).then(s)["catch"](i) : n.loadScript(n.wistiaScriptUrl, n.wistiaScriptOptions).then(function() {
                    n.loadWistiaPlugins(r).then(s)["catch"](i)
                })["catch"](i)
            },
            observe: function(e, t) {
                var n = this,
                    i = function(e) {
                        e.forEach(function(e) {
                            e.isIntersecting > 0 && (r.unobserve(e.target), t(e.target))
                        })
                    };
                if ("IntersectionObserver" in window) {
                    var r = new IntersectionObserver(i, n.intersectionObserverOptions);
                    e.forEach(function(e) {
                        r.observe(e)
                    })
                } else e.forEach(t)
            }
        }, window.ThemeMedias = new ThemeMedias
    }();
var isFramed = function() {
    return self !== top
};
! function() {
    function e() {
        return "0" === $.cookie("_abv")
    }
    if ("object" == typeof Kajabi && !isFramed() && "User" === Kajabi.currentSiteUser.type) {
        var t = "<style>  #admin_bar_iframe {    height: 50px;    position: fixed;     top: 0px;    left: auto;    right: 0;    z-index: 2147483647;    width: 30px;    background: transparent;  }</style>";
        $("head").prepend(t);
        var n = "/preview_bar?preview_theme_id=" + Kajabi.theme.previewThemeId,
            i = '<iframe allowtransparency="true" frameborder="0" id="admin_bar_iframe" src="' + n + '" width="30px">{}</iframe>';
        $("body").prepend(i), $("#admin_bar_iframe").on("load", function() {
            e() || $("html").css("padding-top", "50px")
        })
    }
}(),
function() {
    "object" == typeof Kajabi && isFramed() && Kajabi.theme.previewThemeId && Kajabi.theme.editor && new ThemeEditorBindings
}(),
function() {
    "object" == typeof Kajabi && isFramed() && Kajabi.theme.editor && document.addEventListener("play", function() {
        if (!$(event.target).parents().hasClass("backgroundVideo") && !$(event.target).hasClass("backgroundVideo")) {
            var e = $(event.target);
            e.get(0).pause()
        }
    }, !0)
}(), window.addEventListener("DOMContentLoaded", function() {
        window.addEventListener("everboardingUpdate", function(e) {
            setTimeout(function() {
                var t = e.detail.message.guidance_dots;
                if (t) {
                    var n = t.filter(function(e) {
                        return e.hasOwnProperty("action") && e.hidden
                    });
                    n && n.forEach(function(e) {
                        if (e.inject) {
                            var t = document.querySelectorAll(e.inject.querySelector),
                                n = document.querySelector(e.inject.withinParent);
                            n && t.forEach(function(e) {
                                function t() {
                                    window.parent.dispatchEvent(new CustomEvent("checkStepCompletion", {
                                        detail: {
                                            message: "Trigger completion event"
                                        }
                                    })), e.removeEventListener("click", t)
                                }
                                e.addEventListener("click", t)
                            })
                        }
                    })
                }
            }, 1500)
        })
    }),
    function() {
        var e = this;
        (function() {
            (function() {
                var e = [].slice;
                this.LocalTime = {
                    config: {},
                    run: function() {
                        return this.getController().processElements()
                    },
                    process: function() {
                        var t, n, i, r;
                        for (n = 1 <= arguments.length ? e.call(arguments, 0) : [], i = 0, r = n.length; r > i; i++) t = n[i], this.getController().processElement(t);
                        return n.length
                    },
                    getController: function() {
                        return null != this.controller ? this.controller : this.controller = new t.Controller
                    }
                }
            }).call(this)
        }).call(e);
        var t = e.LocalTime;
        (function() {
            (function() {
                t.config.i18n = {
                    en: {
                        date: {
                            dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                            abbrDayNames: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                            monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                            abbrMonthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                            yesterday: "yesterday",
                            today: "today",
                            tomorrow: "tomorrow",
                            on: "on {date}",
                            formats: {
                                "default": "%b %e, %Y",
                                thisYear: "%b %e"
                            }
                        },
                        time: {
                            am: "am",
                            pm: "pm",
                            singular: "a {time}",
                            singularAn: "an {time}",
                            elapsed: "{time} ago",
                            second: "second",
                            seconds: "seconds",
                            minute: "minute",
                            minutes: "minutes",
                            hour: "hour",
                            hours: "hours",
                            formats: {
                                "default": "%l:%M%P"
                            }
                        },
                        datetime: {
                            at: "{date} at {time}",
                            formats: {
                                "default": "%B %e, %Y at %l:%M%P %Z"
                            }
                        }
                    }
                }
            }).call(this),
                function() {
                    t.config.locale = "en", t.config.defaultLocale = "en"
                }.call(this),
                function() {
                    t.config.timerInterval = 6e4
                }.call(this),
                function() {
                    var e, n, i;
                    i = !isNaN(Date.parse("2011-01-01T12:00:00-05:00")), t.parseDate = function(e) {
                        return e = e.toString(), i || (e = n(e)), new Date(Date.parse(e))
                    }, e = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(Z|[-+]?[\d:]+)$/, n = function(t) {
                        var n, i, r, s, o, a, u, l, c;
                        return (r = t.match(e)) ? (r[0], l = r[1], o = r[2], n = r[3], i = r[4], s = r[5], u = r[6], c = r[7], "Z" !== c && (a = c.replace(":", "")), l + "/" + o + "/" + n + " " + i + ":" + s + ":" + u + " GMT" + [a]) : void 0
                    }
                }.call(this),
                function() {
                    t.elementMatchesSelector = function() {
                        var e, t, n, i, r, s;
                        return e = document.documentElement, t = null != (n = null != (i = null != (r = null != (s = e.matches) ? s : e.matchesSelector) ? r : e.webkitMatchesSelector) ? i : e.mozMatchesSelector) ? n : e.msMatchesSelector,
                            function(e, n) {
                                return (null != e ? e.nodeType : void 0) === Node.ELEMENT_NODE ? t.call(e, n) : void 0
                            }
                    }()
                }.call(this),
                function() {
                    var e, n, i;
                    e = t.config, i = e.i18n, t.getI18nValue = function(r, s) {
                        var o, a;
                        return null == r && (r = ""), o = (null != s ? s : {
                            locale: e.locale
                        }).locale, a = n(i[o], r), null != a ? a : o !== e.defaultLocale ? t.getI18nValue(r, {
                            locale: e.defaultLocale
                        }) : void 0
                    }, t.translate = function(e, n, i) {
                        var r, s, o;
                        null == n && (n = {}), o = t.getI18nValue(e, i);
                        for (r in n) s = n[r], o = o.replace("{" + r + "}", s);
                        return o
                    }, n = function(e, t) {
                        var n, i, r, s, o;
                        for (o = e, s = t.split("."), n = 0, r = s.length; r > n; n++) {
                            if (i = s[n], null == o[i]) return null;
                            o = o[i]
                        }
                        return o
                    }
                }.call(this),
                function() {
                    var e, n, i, r, s;
                    e = t.getI18nValue, s = t.translate, t.strftime = r = function(t, o) {
                        var a, u, l, c, d, f, h;
                        return u = t.getDay(), a = t.getDate(), d = t.getMonth(), h = t.getFullYear(), l = t.getHours(), c = t.getMinutes(), f = t.getSeconds(), o.replace(/%(-?)([%aAbBcdeHIlmMpPSwyYZ])/g, function(o, p, m) {
                            switch (m) {
                                case "%":
                                    return "%";
                                case "a":
                                    return e("date.abbrDayNames")[u];
                                case "A":
                                    return e("date.dayNames")[u];
                                case "b":
                                    return e("date.abbrMonthNames")[d];
                                case "B":
                                    return e("date.monthNames")[d];
                                case "c":
                                    return t.toString();
                                case "d":
                                    return n(a, p);
                                case "e":
                                    return a;
                                case "H":
                                    return n(l, p);
                                case "I":
                                    return n(r(t, "%l"), p);
                                case "l":
                                    return 0 === l || 12 === l ? 12 : (l + 12) % 12;
                                case "m":
                                    return n(d + 1, p);
                                case "M":
                                    return n(c, p);
                                case "p":
                                    return s("time." + (l > 11 ? "pm" : "am")).toUpperCase();
                                case "P":
                                    return s("time." + (l > 11 ? "pm" : "am"));
                                case "S":
                                    return n(f, p);
                                case "w":
                                    return u;
                                case "y":
                                    return n(h % 100, p);
                                case "Y":
                                    return h;
                                case "Z":
                                    return i(t)
                            }
                        })
                    }, n = function(e, t) {
                        switch (t) {
                            case "-":
                                return e;
                            default:
                                return ("0" + e).slice(-2)
                        }
                    }, i = function(e) {
                        var t, n, i, r, s;
                        return s = e.toString(), (t = null != (n = s.match(/\(([\w\s]+)\)$/)) ? n[1] : void 0) ? /\s/.test(t) ? t.match(/\b(\w)/g).join("") : t : (t = null != (i = s.match(/(\w{3,4})\s\d{4}$/)) ? i[1] : void 0) ? t : (t = null != (r = s.match(/(UTC[\+\-]\d+)/)) ? r[1] : void 0) ? t : ""
                    }
                }.call(this),
                function() {
                    t.CalendarDate = function() {
                        function e(e, t, n) {
                            this.date = new Date(Date.UTC(e, t - 1)), this.date.setUTCDate(n), this.year = this.date.getUTCFullYear(), this.month = this.date.getUTCMonth() + 1, this.day = this.date.getUTCDate(), this.value = this.date.getTime()
                        }
                        return e.fromDate = function(e) {
                            return new this(e.getFullYear(), e.getMonth() + 1, e.getDate())
                        }, e.today = function() {
                            return this.fromDate(new Date)
                        }, e.prototype.equals = function(e) {
                            return (null != e ? e.value : void 0) === this.value
                        }, e.prototype.is = function(e) {
                            return this.equals(e)
                        }, e.prototype.isToday = function() {
                            return this.is(this.constructor.today())
                        }, e.prototype.occursOnSameYearAs = function(e) {
                            return this.year === (null != e ? e.year : void 0)
                        }, e.prototype.occursThisYear = function() {
                            return this.occursOnSameYearAs(this.constructor.today())
                        }, e.prototype.daysSince = function(e) {
                            return e ? (this.date - e.date) / 864e5 : void 0
                        }, e.prototype.daysPassed = function() {
                            return this.constructor.today().daysSince(this)
                        }, e
                    }()
                }.call(this),
                function() {
                    var e, n, i;
                    n = t.strftime, i = t.translate, e = t.getI18nValue, t.RelativeTime = function() {
                        function r(e) {
                            this.date = e, this.calendarDate = t.CalendarDate.fromDate(this.date)
                        }
                        return r.prototype.toString = function() {
                            var e, t;
                            return (t = this.toTimeElapsedString()) ? i("time.elapsed", {
                                time: t
                            }) : (e = this.toWeekdayString()) ? (t = this.toTimeString(), i("datetime.at", {
                                date: e,
                                time: t
                            })) : i("date.on", {
                                date: this.toDateString()
                            })
                        }, r.prototype.toTimeOrDateString = function() {
                            return this.calendarDate.isToday() ? this.toTimeString() : this.toDateString()
                        }, r.prototype.toTimeElapsedString = function() {
                            var e, t, n, r, s;
                            return n = (new Date).getTime() - this.date.getTime(), r = Math.round(n / 1e3), t = Math.round(r / 60), e = Math.round(t / 60), 0 > n ? null : 10 > r ? (s = i("time.second"), i("time.singular", {
                                time: s
                            })) : 45 > r ? r + " " + i("time.seconds") : 90 > r ? (s = i("time.minute"), i("time.singular", {
                                time: s
                            })) : 45 > t ? t + " " + i("time.minutes") : 90 > t ? (s = i("time.hour"), i("time.singularAn", {
                                time: s
                            })) : 24 > e ? e + " " + i("time.hours") : ""
                        }, r.prototype.toWeekdayString = function() {
                            switch (this.calendarDate.daysPassed()) {
                                case 0:
                                    return i("date.today");
                                case 1:
                                    return i("date.yesterday");
                                case -1:
                                    return i("date.tomorrow");
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                    return n(this.date, "%A");
                                default:
                                    return ""
                            }
                        }, r.prototype.toDateString = function() {
                            var t;
                            return t = e(this.calendarDate.occursThisYear() ? "date.formats.thisYear" : "date.formats.default"), n(this.date, t)
                        }, r.prototype.toTimeString = function() {
                            return n(this.date, e("time.formats.default"))
                        }, r
                    }()
                }.call(this),
                function() {
                    var e, n = function(e, t) {
                        return function() {
                            return e.apply(t, arguments)
                        }
                    };
                    e = t.elementMatchesSelector, t.PageObserver = function() {
                        function t(e, t) {
                            this.selector = e, this.callback = t, this.processInsertion = n(this.processInsertion, this), this.processMutations = n(this.processMutations, this)
                        }
                        return t.prototype.start = function() {
                            return this.started ? void 0 : (this.observeWithMutationObserver() || this.observeWithMutationEvent(), this.started = !0)
                        }, t.prototype.observeWithMutationObserver = function() {
                            var e;
                            return "undefined" != typeof MutationObserver && null !== MutationObserver ? (e = new MutationObserver(this.processMutations), e.observe(document.documentElement, {
                                childList: !0,
                                subtree: !0
                            }), !0) : void 0
                        }, t.prototype.observeWithMutationEvent = function() {
                            return addEventListener("DOMNodeInserted", this.processInsertion, !1), !0
                        }, t.prototype.findSignificantElements = function(t) {
                            var n;
                            return n = [], (null != t ? t.nodeType : void 0) === Node.ELEMENT_NODE && (e(t, this.selector) && n.push(t), n.push.apply(n, t.querySelectorAll(this.selector))), n
                        }, t.prototype.processMutations = function(e) {
                            var t, n, i, r, s, o, a, u;
                            for (t = [], n = 0, r = e.length; r > n; n++) switch (o = e[n], o.type) {
                                case "childList":
                                    for (u = o.addedNodes, i = 0, s = u.length; s > i; i++) a = u[i], t.push.apply(t, this.findSignificantElements(a))
                            }
                            return this.notify(t)
                        }, t.prototype.processInsertion = function(e) {
                            var t;
                            return t = this.findSignificantElements(e.target), this.notify(t)
                        }, t.prototype.notify = function(e) {
                            return (null != e ? e.length : void 0) && "function" == typeof this.callback ? this.callback(e) : void 0
                        }, t
                    }()
                }.call(this),
                function() {
                    var e, n, i, r, s = function(e, t) {
                        return function() {
                            return e.apply(t, arguments)
                        }
                    };
                    i = t.parseDate, r = t.strftime, n = t.getI18nValue, e = t.config, t.Controller = function() {
                        function o() {
                            this.processElements = s(this.processElements, this), this.pageObserver = new t.PageObserver(a, this.processElements)
                        }
                        var a, u, l;
                        return a = "time[data-local]:not([data-localized])", o.prototype.start = function() {
                            return this.started ? void 0 : (this.processElements(), this.startTimer(), this.pageObserver.start(), this.started = !0)
                        }, o.prototype.startTimer = function() {
                            var t;
                            return (t = e.timerInterval) ? null != this.timer ? this.timer : this.timer = setInterval(this.processElements, t) : void 0
                        }, o.prototype.processElements = function(e) {
                            var t, n, i;
                            for (null == e && (e = document.querySelectorAll(a)), n = 0, i = e.length; i > n; n++) t = e[n], this.processElement(t);
                            return e.length
                        }, o.prototype.processElement = function(e) {
                            var t, s, o, a, c, d;
                            return s = e.getAttribute("datetime"), o = e.getAttribute("data-format"), a = e.getAttribute("data-local"), c = i(s), isNaN(c) ? void 0 : (e.hasAttribute("title") || (d = r(c, n("datetime.formats.default")), e.setAttribute("title", d)), e.textContent = t = function() {
                                switch (a) {
                                    case "time":
                                        return u(e), r(c, o);
                                    case "date":
                                        return u(e), l(c).toDateString();
                                    case "time-ago":
                                        return l(c).toString();
                                    case "time-or-date":
                                        return l(c).toTimeOrDateString();
                                    case "weekday":
                                        return l(c).toWeekdayString();
                                    case "weekday-or-date":
                                        return l(c).toWeekdayString() || l(c).toDateString()
                                }
                            }(), e.hasAttribute("aria-label") ? void 0 : e.setAttribute("aria-label", t))
                        }, u = function(e) {
                            return e.setAttribute("data-localized", "")
                        }, l = function(e) {
                            return new t.RelativeTime(e)
                        }, o
                    }()
                }.call(this),
                function() {
                    var e, n, i, r;
                    r = !1, e = function() {
                        return document.attachEvent ? "complete" === document.readyState : "loading" !== document.readyState
                    }, n = function(e) {
                        var t;
                        return null != (t = "function" == typeof requestAnimationFrame ? requestAnimationFrame(e) : void 0) ? t : setTimeout(e, 17)
                    }, i = function() {
                        var e;
                        return e = t.getController(), e.start()
                    }, t.start = function() {
                        return r ? void 0 : (r = !0, "undefined" != typeof MutationObserver && null !== MutationObserver || e() ? i() : n(i))
                    }, window.LocalTime === t && t.start()
                }.call(this)
        }).call(this), "object" == typeof module && module.exports ? module.exports = t : "function" == typeof define && define.amd && define(t)
    }.call(this), window.ParsleyExtend = {
        asyncValidators: {
            kjb_offer_checkout_email_validator: {
                fn: function(e) {
                    return 200 !== e.status && e.responseJSON && e.responseJSON.message && window.ParsleyValidator.addMessage("en", "remote", e.responseJSON.message), 200 === e.status
                },
                url: "checkout/validate_email",
                options: {
                    data: {
                        preview: function() {
                            var e = new URLSearchParams(location.search);
                            if (null !== document.querySelector(".offer-checkout")) return "true" === e.get("preview")
                        }()
                    }
                }
            },
            kjb_email_validator: {
                fn: function(e) {
                    return 200 !== e.status && e.responseJSON && e.responseJSON.message && window.ParsleyValidator.addMessage("en", "remote", e.responseJSON.message), 200 === e.status
                },
                url: "/email_validations",
                options: {
                    type: "POST"
                }
            }
        }
    }, window.ParsleyExtend = window.ParsleyExtend || {}, window.ParsleyExtend = $.extend(window.ParsleyExtend, {
        asyncSupport: !0,
        asyncValidators: $.extend({
            "default": {
                fn: function(e) {
                    return "resolved" === e.state()
                },
                url: !1
            },
            reverse: {
                fn: function(e) {
                    return "rejected" === e.state()
                },
                url: !1
            }
        }, window.ParsleyExtend.asyncValidators),
        addAsyncValidator: function(e, t, n, i) {
            return this.asyncValidators[e.toLowerCase()] = {
                fn: t,
                url: n || !1,
                options: i || {}
            }, this
        },
        asyncValidate: function() {
            return "ParsleyForm" === this.__class__ ? this._asyncValidateForm.apply(this, arguments) : this._asyncValidateField.apply(this, arguments)
        },
        asyncIsValid: function() {
            return "ParsleyField" === this.__class__ ? this._asyncIsValidField.apply(this, arguments) : this._asyncIsValidForm.apply(this, arguments)
        },
        onSubmitValidate: function(e) {
            var t = this;
            if (!0 !== e.parsley) return this.submitEvent = $.extend(!0, {}, e), e instanceof $.Event && (e.stopImmediatePropagation(), e.preventDefault()), this._asyncValidateForm(void 0, e).done(function() {
                t.submitEvent.isDefaultPrevented() || t.$element.trigger($.extend($.Event("submit"), {
                    parsley: !0
                }))
            })
        },
        eventValidate: function(e) {
            new RegExp("key").test(e.type) && !this._ui.validationInformationVisible && this.getValue().length <= this.options.validationThreshold || (this._ui.validatedOnce = !0, this.asyncValidate())
        },
        _asyncValidateForm: function(e) {
            var t = this,
                n = [];
            this._refreshFields(), $.emit("parsley:form:validate", this);
            for (var i = 0; i < this.fields.length; i++) e && e !== this.fields[i].options.group || n.push(this.fields[i]._asyncValidateField());
            return $.when.apply($, n).done(function() {
                $.emit("parsley:form:success", t)
            }).fail(function() {
                $.emit("parsley:form:error", t)
            }).always(function() {
                $.emit("parsley:form:validated", t)
            })
        },
        _asyncIsValidForm: function(e, t) {
            var n = [];
            this._refreshFields();
            for (var i = 0; i < this.fields.length; i++) e && e !== this.fields[i].options.group || n.push(this.fields[i]._asyncIsValidField(t));
            return $.when.apply($, n)
        },
        _asyncValidateField: function(e) {
            var t = this;
            return $.emit("parsley:field:validate", this), this._asyncIsValidField(e).done(function() {
                $.emit("parsley:field:success", t)
            }).fail(function() {
                $.emit("parsley:field:error", t)
            }).always(function() {
                $.emit("parsley:field:validated", t)
            })
        },
        _asyncIsValidField: function(e, t) {
            var n = $.Deferred();
            return !1 === this.isValid(e, t) ? n.rejectWith(this) : "undefined" != typeof this.constraintsByName.remote ? this._remote(n) : n.resolveWith(this), n.promise()
        },
        _remote: function(e) {
            var t, n, i = this,
                r = {},
                s = this.options.remoteValidator || (!0 === this.options.remoteReverse ? "reverse" : "default");
            if (s = s.toLowerCase(), "undefined" == typeof this.asyncValidators[s]) throw new Error("Calling an undefined async validator: `" + s + "`");
            r[this.$element.attr("name") || this.$element.attr("id")] = this.getValue(), this.options.remoteOptions = $.extend(!0, this.options.remoteOptions || {}, this.asyncValidators[s].options), t = $.extend(!0, {}, {
                url: this.asyncValidators[s].url || this.options.remote,
                data: r,
                type: "GET"
            }, this.options.remoteOptions || {}), n = $.param(t), "undefined" == typeof this._remoteCache && (this._remoteCache = {}), this._remoteCache[n] || (this._xhr && "pending" === this._xhr.state() && this._xhr.abort(), this._xhr = $.ajax(t), this._remoteCache[n] = this._xhr), this._remoteCache[n].done(function(t, n, r) {
                i._handleRemoteResult(s, r, e)
            }).fail(function(t, n) {
                "abort" !== n && i._handleRemoteResult(s, t, e)
            })
        },
        _handleRemoteResult: function(e, t, n) {
            return "function" == typeof this.asyncValidators[e].fn && this.asyncValidators[e].fn.call(this, t) ? void n.resolveWith(this) : (this.validationResult = [new window.ParsleyValidator.Validator.Violation(this.constraintsByName.remote, this.getValue(), null)], void n.rejectWith(this))
        }
    }), window.ParsleyConfig = window.ParsleyConfig || {}, window.ParsleyConfig.validators = window.ParsleyConfig.validators || {}, window.ParsleyConfig.validators.remote = {
        fn: function() {
            return !0
        },
        priority: -1
    }, ! function(e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery)
    }(function(e) {
        "undefined" == typeof e && "undefined" != typeof window.jQuery && (e = window.jQuery);
        var t = {
                attr: function(e, t, n) {
                    var i, r = {},
                        s = this.msieversion(),
                        o = new RegExp("^" + t, "i");
                    if ("undefined" == typeof e || "undefined" == typeof e[0]) return {};
                    for (var a in e[0].attributes)
                        if (i = e[0].attributes[a], "undefined" != typeof i && null !== i && (!s || s >= 8 || i.specified) && o.test(i.name)) {
                            if ("undefined" != typeof n && new RegExp(n + "$", "i").test(i.name)) return !0;
                            r[this.camelize(i.name.replace(t, ""))] = this.deserializeValue(i.value)
                        }
                    return "undefined" == typeof n ? r : !1
                },
                setAttr: function(e, t, n, i) {
                    e[0].setAttribute(this.dasherize(t + n), String(i))
                },
                get: function(e, t) {
                    for (var n = 0, i = (t || "").split("."); this.isObject(e) || this.isArray(e);)
                        if (e = e[i[n++]], n === i.length) return e;
                    return void 0
                },
                hash: function(e) {
                    return String(Math.random()).substring(2, e ? e + 2 : 9)
                },
                isArray: function(e) {
                    return "[object Array]" === Object.prototype.toString.call(e)
                },
                isObject: function(e) {
                    return e === Object(e)
                },
                deserializeValue: function(t) {
                    var n;
                    try {
                        return t ? "true" == t || ("false" == t ? !1 : "null" == t ? null : isNaN(n = Number(t)) ? /^[\[\{]/.test(t) ? e.parseJSON(t) : t : n) : t
                    } catch (i) {
                        return t
                    }
                },
                camelize: function(e) {
                    return e.replace(/-+(.)?/g, function(e, t) {
                        return t ? t.toUpperCase() : ""
                    })
                },
                dasherize: function(e) {
                    return e.replace(/::/g, "/").replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2").replace(/([a-z\d])([A-Z])/g, "$1_$2").replace(/_/g, "-").toLowerCase()
                },
                msieversion: function() {
                    var e = window.navigator.userAgent,
                        t = e.indexOf("MSIE ");
                    return t > 0 || navigator.userAgent.match(/Trident.*rv\:11\./) ? parseInt(e.substring(t + 5, e.indexOf(".", t)), 10) : 0
                }
            },
            n = {
                namespace: "data-parsley-",
                inputs: "input, textarea, select",
                excluded: "input[type=button], input[type=submit], input[type=reset], input[type=hidden]",
                priorityEnabled: !0,
                uiEnabled: !0,
                validationThreshold: 3,
                focus: "first",
                trigger: !1,
                errorClass: "parsley-error",
                successClass: "parsley-success",
                classHandler: function() {},
                errorsContainer: function() {},
                errorsWrapper: '<ul class="parsley-errors-list"></ul>',
                errorTemplate: "<li></li>"
            },
            i = function() {};
        i.prototype = {
            asyncSupport: !1,
            actualizeOptions: function() {
                return this.options = this.OptionsFactory.get(this), this
            },
            validateThroughValidator: function(e, t, n) {
                return window.ParsleyValidator.validate(e, t, n)
            },
            subscribe: function(t, n) {
                return e.listenTo(this, t.toLowerCase(), n), this
            },
            unsubscribe: function(t) {
                return e.unsubscribeTo(this, t.toLowerCase()), this
            },
            reset: function() {
                if ("ParsleyForm" !== this.__class__) return e.emit("parsley:field:reset", this);
                for (var t = 0; t < this.fields.length; t++) e.emit("parsley:field:reset", this.fields[t]);
                e.emit("parsley:form:reset", this)
            },
            destroy: function() {
                if ("ParsleyForm" !== this.__class__) return this.$element.removeData("Parsley"), this.$element.removeData("ParsleyFieldMultiple"), void e.emit("parsley:field:destroy", this);
                for (var t = 0; t < this.fields.length; t++) this.fields[t].destroy();
                this.$element.removeData("Parsley"), e.emit("parsley:form:destroy", this)
            }
        };
        var r = function() {
            var e = {},
                t = function(e) {
                    this.__class__ = "Validator", this.__version__ = "1.0.1", this.options = e || {}, this.bindingKey = this.options.bindingKey || "_validatorjsConstraint"
                };
            t.prototype = {
                constructor: t,
                validate: function(e, t, n) {
                    if ("string" != typeof e && "object" != typeof e) throw new Error("You must validate an object or a string");
                    return "string" == typeof e || o(e) ? this._validateString(e, t, n) : this.isBinded(e) ? this._validateBindedObject(e, t) : this._validateObject(e, t, n)
                },
                bind: function(e, t) {
                    if ("object" != typeof e) throw new Error("Must bind a Constraint to an object");
                    return e[this.bindingKey] = new n(t), this
                },
                unbind: function(e) {
                    return "undefined" == typeof e._validatorjsConstraint ? this : (delete e[this.bindingKey], this)
                },
                isBinded: function(e) {
                    return "undefined" != typeof e[this.bindingKey]
                },
                getBinded: function(e) {
                    return this.isBinded(e) ? e[this.bindingKey] : null
                },
                _validateString: function(e, t, n) {
                    var s, a = [];
                    o(t) || (t = [t]);
                    for (var u = 0; u < t.length; u++) {
                        if (!(t[u] instanceof r)) throw new Error("You must give an Assert or an Asserts array to validate a string");
                        s = t[u].check(e, n), s instanceof i && a.push(s)
                    }
                    return a.length ? a : !0
                },
                _validateObject: function(e, t, i) {
                    if ("object" != typeof t) throw new Error("You must give a constraint to validate an object");
                    return t instanceof n ? t.check(e, i) : new n(t).check(e, i)
                },
                _validateBindedObject: function(e, t) {
                    return e[this.bindingKey].check(e, t)
                }
            }, t.errorCode = {
                must_be_a_string: "must_be_a_string",
                must_be_an_array: "must_be_an_array",
                must_be_a_number: "must_be_a_number",
                must_be_a_string_or_array: "must_be_a_string_or_array"
            };
            var n = function(e, t) {
                if (this.__class__ = "Constraint", this.options = t || {}, this.nodes = {}, e) try {
                    this._bootstrap(e)
                } catch (n) {
                    throw new Error("Should give a valid mapping object to Constraint", n, e)
                }
            };
            n.prototype = {
                constructor: n,
                check: function(e, t) {
                    var n, i = {};
                    for (var a in this.nodes) {
                        for (var u = !1, l = this.get(a), c = o(l) ? l : [l], d = c.length - 1; d >= 0; d--) "Required" !== c[d].__class__ || (u = c[d].requiresValidation(t));
                        if (this.has(a, e) || this.options.strict || u) try {
                            this.has(a, this.options.strict || u ? e : void 0) || (new r).HaveProperty(a).validate(e), n = this._check(a, e[a], t), (o(n) && n.length > 0 || !o(n) && !s(n)) && (i[a] = n)
                        } catch (f) {
                            i[a] = f
                        }
                    }
                    return s(i) ? !0 : i
                },
                add: function(e, t) {
                    if (t instanceof r || o(t) && t[0] instanceof r) return this.nodes[e] = t, this;
                    if ("object" == typeof t && !o(t)) return this.nodes[e] = t instanceof n ? t : new n(t), this;
                    throw new Error("Should give an Assert, an Asserts array, a Constraint", t)
                },
                has: function(e, t) {
                    return t = "undefined" != typeof t ? t : this.nodes, "undefined" != typeof t[e]
                },
                get: function(e, t) {
                    return this.has(e) ? this.nodes[e] : t || null
                },
                remove: function(e) {
                    var t = [];
                    for (var n in this.nodes) n !== e && (t[n] = this.nodes[n]);
                    return this.nodes = t, this
                },
                _bootstrap: function(e) {
                    if (e instanceof n) return this.nodes = e.nodes;
                    for (var t in e) this.add(t, e[t])
                },
                _check: function(e, t, i) {
                    if (this.nodes[e] instanceof r) return this._checkAsserts(t, [this.nodes[e]], i);
                    if (o(this.nodes[e])) return this._checkAsserts(t, this.nodes[e], i);
                    if (this.nodes[e] instanceof n) return this.nodes[e].check(t, i);
                    throw new Error("Invalid node", this.nodes[e])
                },
                _checkAsserts: function(e, t, n) {
                    for (var i, r = [], s = 0; s < t.length; s++) i = t[s].check(e, n), "undefined" != typeof i && !0 !== i && r.push(i);
                    return r
                }
            };
            var i = function(e, t, n) {
                if (this.__class__ = "Violation", !(e instanceof r)) throw new Error("Should give an assertion implementing the Assert interface");
                this.assert = e, this.value = t, "undefined" != typeof n && (this.violation = n)
            };
            i.prototype = {
                show: function() {
                    var e = {
                        assert: this.assert.__class__,
                        value: this.value
                    };
                    return this.violation && (e.violation = this.violation), e
                },
                __toString: function() {
                    return "undefined" != typeof this.violation && (this.violation = '", ' + this.getViolation().constraint + " expected was " + this.getViolation().expected), this.assert.__class__ + ' assert failed for "' + this.value + this.violation || ""
                },
                getViolation: function() {
                    var e, t;
                    for (e in this.violation) t = this.violation[e];
                    return {
                        constraint: e,
                        expected: t
                    }
                }
            };
            var r = function(e) {
                this.__class__ = "Assert", this.__parentClass__ = this.__class__, this.groups = [], "undefined" != typeof e && this.addGroup(e)
            };
            r.prototype = {
                construct: r,
                requiresValidation: function(e) {
                    return e && !this.hasGroup(e) ? !1 : !e && this.hasGroups() ? !1 : !0
                },
                check: function(e, t) {
                    if (this.requiresValidation(t)) try {
                        return this.validate(e, t)
                    } catch (n) {
                        return n
                    }
                },
                hasGroup: function(e) {
                    return o(e) ? this.hasOneOf(e) : "Any" === e ? !0 : this.hasGroups() ? -1 !== this.groups.indexOf(e) : "Default" === e
                },
                hasOneOf: function(e) {
                    for (var t = 0; t < e.length; t++)
                        if (this.hasGroup(e[t])) return !0;
                    return !1
                },
                hasGroups: function() {
                    return this.groups.length > 0
                },
                addGroup: function(e) {
                    return o(e) ? this.addGroups(e) : (this.hasGroup(e) || this.groups.push(e), this)
                },
                removeGroup: function(e) {
                    for (var t = [], n = 0; n < this.groups.length; n++) e !== this.groups[n] && t.push(this.groups[n]);
                    return this.groups = t, this
                },
                addGroups: function(e) {
                    for (var t = 0; t < e.length; t++) this.addGroup(e[t]);
                    return this
                },
                HaveProperty: function(e) {
                    return this.__class__ = "HaveProperty", this.node = e, this.validate = function(e) {
                        if ("undefined" == typeof e[this.node]) throw new i(this, e, {
                            value: this.node
                        });
                        return !0
                    }, this
                },
                Blank: function() {
                    return this.__class__ = "Blank", this.validate = function(e) {
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if ("" !== e.replace(/^\s+/g, "").replace(/\s+$/g, "")) throw new i(this, e);
                        return !0
                    }, this
                },
                Callback: function(e) {
                    if (this.__class__ = "Callback", this.arguments = Array.prototype.slice.call(arguments), 1 === this.arguments.length ? this.arguments = [] : this.arguments.splice(0, 1), "function" != typeof e) throw new Error("Callback must be instanciated with a function");
                    return this.fn = e, this.validate = function(e) {
                        var t = this.fn.apply(this, [e].concat(this.arguments));
                        if (!0 !== t) throw new i(this, e, {
                            result: t
                        });
                        return !0
                    }, this
                },
                Choice: function(e) {
                    if (this.__class__ = "Choice", !o(e) && "function" != typeof e) throw new Error("Choice must be instanciated with an array or a function");
                    return this.list = e, this.validate = function(e) {
                        for (var t = "function" == typeof this.list ? this.list() : this.list, n = 0; n < t.length; n++)
                            if (e === t[n]) return !0;
                        throw new i(this, e, {
                            choices: t
                        })
                    }, this
                },
                Collection: function(e) {
                    return this.__class__ = "Collection", this.constraint = "undefined" != typeof e ? e instanceof r ? e : new n(e) : !1, this.validate = function(e, n) {
                        var r, a = new t,
                            u = 0,
                            l = {},
                            c = this.groups.length ? this.groups : n;
                        if (!o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_an_array
                        });
                        for (var d = 0; d < e.length; d++) r = this.constraint ? a.validate(e[d], this.constraint, c) : a.validate(e[d], c), s(r) || (l[u] = r), u++;
                        return s(l) ? !0 : l
                    }, this
                },
                Count: function(e) {
                    return this.__class__ = "Count", this.count = e, this.validate = function(e) {
                        if (!o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_an_array
                        });
                        var n = "function" == typeof this.count ? this.count(e) : this.count;
                        if (isNaN(Number(n))) throw new Error("Count must be a valid interger", n);
                        if (n !== e.length) throw new i(this, e, {
                            count: n
                        });
                        return !0
                    }, this
                },
                Email: function() {
                    return this.__class__ = "Email", this.validate = function(e) {
                        var n = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if (!n.test(e)) throw new i(this, e);
                        return !0
                    }, this
                },
                EqualTo: function(e) {
                    if (this.__class__ = "EqualTo", "undefined" == typeof e) throw new Error("EqualTo must be instanciated with a value or a function");
                    return this.reference = e, this.validate = function(e) {
                        var t = "function" == typeof this.reference ? this.reference(e) : this.reference;
                        if (t !== e) throw new i(this, e, {
                            value: t
                        });
                        return !0
                    }, this
                },
                GreaterThan: function(e) {
                    if (this.__class__ = "GreaterThan", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold >= e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                GreaterThanOrEqual: function(e) {
                    if (this.__class__ = "GreaterThanOrEqual", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold > e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                InstanceOf: function(e) {
                    if (this.__class__ = "InstanceOf", "undefined" == typeof e) throw new Error("InstanceOf must be instanciated with a value");
                    return this.classRef = e, this.validate = function(e) {
                        if (!0 != e instanceof this.classRef) throw new i(this, e, {
                            classRef: this.classRef
                        });
                        return !0
                    }, this
                },
                Length: function(e) {
                    if (this.__class__ = "Length", !e.min && !e.max) throw new Error("Lenth assert must be instanciated with a { min: x, max: y } object");
                    return this.min = e.min, this.max = e.max, this.validate = function(e) {
                        if ("string" != typeof e && !o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string_or_array
                        });
                        if ("undefined" != typeof this.min && this.min === this.max && e.length !== this.min) throw new i(this, e, {
                            min: this.min,
                            max: this.max
                        });
                        if ("undefined" != typeof this.max && e.length > this.max) throw new i(this, e, {
                            max: this.max
                        });
                        if ("undefined" != typeof this.min && e.length < this.min) throw new i(this, e, {
                            min: this.min
                        });
                        return !0
                    }, this
                },
                LessThan: function(e) {
                    if (this.__class__ = "LessThan", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold <= e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                LessThanOrEqual: function(e) {
                    if (this.__class__ = "LessThanOrEqual", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold < e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                NotNull: function() {
                    return this.__class__ = "NotNull", this.validate = function(e) {
                        if (null === e || "undefined" == typeof e) throw new i(this, e);
                        return !0
                    }, this
                },
                NotBlank: function() {
                    return this.__class__ = "NotBlank", this.validate = function(e) {
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if ("" === e.replace(/^\s+/g, "").replace(/\s+$/g, "")) throw new i(this, e);
                        return !0
                    }, this
                },
                Null: function() {
                    return this.__class__ = "Null", this.validate = function(e) {
                        if (null !== e) throw new i(this, e);
                        return !0
                    }, this
                },
                Range: function(e, t) {
                    if (this.__class__ = "Range", "undefined" == typeof e || "undefined" == typeof t) throw new Error("Range assert expects min and max values");
                    return this.min = e, this.max = t, this.validate = function(e) {
                        try {
                            return "string" == typeof e && isNaN(Number(e)) || o(e) ? (new r).Length({
                                min: this.min,
                                max: this.max
                            }).validate(e) : (new r).GreaterThanOrEqual(this.min).validate(e) && (new r).LessThanOrEqual(this.max).validate(e), !0
                        } catch (t) {
                            throw new i(this, e, t.violation)
                        }
                        return !0
                    }, this
                },
                Regexp: function(e, n) {
                    if (this.__class__ = "Regexp", "undefined" == typeof e) throw new Error("You must give a regexp");
                    return this.regexp = e, this.flag = n || "", this.validate = function(e) {
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if (!new RegExp(this.regexp, this.flag).test(e)) throw new i(this, e, {
                            regexp: this.regexp,
                            flag: this.flag
                        });
                        return !0
                    }, this
                },
                Required: function() {
                    return this.__class__ = "Required", this.validate = function(e) {
                        if ("undefined" == typeof e) throw new i(this, e);
                        try {
                            "string" == typeof e ? (new r).NotNull().validate(e) && (new r).NotBlank().validate(e) : !0 === o(e) && (new r).Length({
                                min: 1
                            }).validate(e)
                        } catch (t) {
                            throw new i(this, e)
                        }
                        return !0
                    }, this
                },
                Unique: function(e) {
                    return this.__class__ = "Unique", "object" == typeof e && (this.key = e.key), this.validate = function(e) {
                        var n, r = [];
                        if (!o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_an_array
                        });
                        for (var s = 0; s < e.length; s++)
                            if (n = "object" == typeof e[s] ? e[s][this.key] : e[s], "undefined" != typeof n) {
                                if (-1 !== r.indexOf(n)) throw new i(this, e, {
                                    value: n
                                });
                                r.push(n)
                            }
                        return !0
                    }, this
                }
            }, e.Assert = r, e.Validator = t, e.Violation = i, e.Constraint = n, Array.prototype.indexOf || (Array.prototype.indexOf = function(e) {
                if (null === this) throw new TypeError;
                var t = Object(this),
                    n = t.length >>> 0;
                if (0 === n) return -1;
                var i = 0;
                if (arguments.length > 1 && (i = Number(arguments[1]), i != i ? i = 0 : 0 !== i && 1 / 0 != i && i != -1 / 0 && (i = (i > 0 || -1) * Math.floor(Math.abs(i)))), i >= n) return -1;
                for (var r = i >= 0 ? i : Math.max(n - Math.abs(i), 0); n > r; r++)
                    if (r in t && t[r] === e) return r;
                return -1
            });
            var s = function(e) {
                    for (var t in e) return !1;
                    return !0
                },
                o = function(e) {
                    return "[object Array]" === Object.prototype.toString.call(e)
                };
            return "function" == typeof define && define.amd ? define("vendors/validator.js/dist/validator", [], function() {
                return e
            }) : "undefined" != typeof module && module.exports ? module.exports = e : window["undefined" != typeof validatorjs_ns ? validatorjs_ns : "Validator"] = e, e
        }();
        r = "undefined" != typeof r ? r : "undefined" != typeof module ? module.exports : null;
        var s = function(e, t) {
            this.__class__ = "ParsleyValidator", this.Validator = r, this.locale = "en", this.init(e || {}, t || {})
        };
        s.prototype = {
            init: function(t, n) {
                this.catalog = n;
                for (var i in t) this.addValidator(i, t[i].fn, t[i].priority, t[i].requirementsTransformer);
                e.emit("parsley:validator:init")
            },
            setLocale: function(e) {
                if ("undefined" == typeof this.catalog[e]) throw new Error(e + " is not available in the catalog");
                return this.locale = e, this
            },
            addCatalog: function(e, t, n) {
                return "object" == typeof t && (this.catalog[e] = t), !0 === n ? this.setLocale(e) : this
            },
            addMessage: function(e, t, n) {
                return "undefined" == typeof this.catalog[e] && (this.catalog[e] = {}), this.catalog[e][t.toLowerCase()] = n, this
            },
            validate: function() {
                return (new this.Validator.Validator).validate.apply(new r.Validator, arguments)
            },
            addValidator: function(t, n, i, s) {
                return this.validators[t.toLowerCase()] = function(t) {
                    return e.extend((new r.Assert).Callback(n, t), {
                        priority: i,
                        requirementsTransformer: s
                    })
                }, this
            },
            updateValidator: function(e, t, n, i) {
                return this.addValidator(e, t, n, i)
            },
            removeValidator: function(e) {
                return delete this.validators[e], this
            },
            getErrorMessage: function(e) {
                var t;
                return t = "type" === e.name ? this.catalog[this.locale][e.name][e.requirements] : this.formatMessage(this.catalog[this.locale][e.name], e.requirements), "" !== t ? t : this.catalog[this.locale].defaultMessage
            },
            formatMessage: function(e, t) {
                if ("object" == typeof t) {
                    for (var n in t) e = this.formatMessage(e, t[n]);
                    return e
                }
                return "string" == typeof e ? e.replace(new RegExp("%s", "i"), t) : ""
            },
            validators: {
                notblank: function() {
                    return e.extend((new r.Assert).NotBlank(), {
                        priority: 2
                    })
                },
                required: function() {
                    return e.extend((new r.Assert).Required(), {
                        priority: 512
                    })
                },
                type: function(t) {
                    var n;
                    switch (t) {
                        case "email":
                            n = (new r.Assert).Email();
                            break;
                        case "range":
                        case "number":
                            n = (new r.Assert).Regexp("^-?(?:\\d+|\\d{1,3}(?:,\\d{3})+)?(?:\\.\\d+)?$");
                            break;
                        case "integer":
                            n = (new r.Assert).Regexp("^-?\\d+$");
                            break;
                        case "digits":
                            n = (new r.Assert).Regexp("^\\d+$");
                            break;
                        case "alphanum":
                            n = (new r.Assert).Regexp("^\\w+$", "i");
                            break;
                        case "url":
                            n = (new r.Assert).Regexp("(https?:\\/\\/)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,24}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)", "i");
                            break;
                        default:
                            throw new Error("validator type `" + t + "` is not supported")
                    }
                    return e.extend(n, {
                        priority: 256
                    })
                },
                pattern: function(t) {
                    var n = "";
                    return /^\/.*\/(?:[gimy]*)$/.test(t) && (n = t.replace(/.*\/([gimy]*)$/, "$1"), t = t.replace(new RegExp("^/(.*?)/" + n + "$"), "$1")), e.extend((new r.Assert).Regexp(t, n), {
                        priority: 64
                    })
                },
                minlength: function(t) {
                    return e.extend((new r.Assert).Length({
                        min: t
                    }), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                maxlength: function(t) {
                    return e.extend((new r.Assert).Length({
                        max: t
                    }), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                length: function(t) {
                    return e.extend((new r.Assert).Length({
                        min: t[0],
                        max: t[1]
                    }), {
                        priority: 32
                    })
                },
                mincheck: function(e) {
                    return this.minlength(e)
                },
                maxcheck: function(e) {
                    return this.maxlength(e)
                },
                check: function(e) {
                    return this.length(e)
                },
                min: function(t) {
                    return e.extend((new r.Assert).GreaterThanOrEqual(t), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                max: function(t) {
                    return e.extend((new r.Assert).LessThanOrEqual(t), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                range: function(t) {
                    return e.extend((new r.Assert).Range(t[0], t[1]), {
                        priority: 32,
                        requirementsTransformer: function() {
                            for (var e = 0; e < t.length; e++) t[e] = "string" != typeof t[e] || isNaN(t[e]) ? t[e] : parseInt(t[e], 10);
                            return t
                        }
                    })
                },
                equalto: function(t) {
                    return e.extend((new r.Assert).EqualTo(t), {
                        priority: 256,
                        requirementsTransformer: function() {
                            return e(t).length ? e(t).val() : t
                        }
                    })
                }
            }
        };
        var o = function() {
            this.__class__ = "ParsleyUI"
        };
        o.prototype = {
            listen: function() {
                return e.listen("parsley:form:init", this, this.setupForm), e.listen("parsley:field:init", this, this.setupField), e.listen("parsley:field:validated", this, this.reflow), e.listen("parsley:form:validated", this, this.focus), e.listen("parsley:field:reset", this, this.reset), e.listen("parsley:form:destroy", this, this.destroy), e.listen("parsley:field:destroy", this, this.destroy), this
            },
            reflow: function(e) {
                if ("undefined" != typeof e._ui && !1 !== e._ui.active) {
                    var t = this._diff(e.validationResult, e._ui.lastValidationResult);
                    e._ui.lastValidationResult = e.validationResult, e._ui.validatedOnce = !0, this.manageStatusClass(e), this.manageErrorsMessages(e, t), this.actualizeTriggers(e), (t.kept.length || t.added.length) && "undefined" == typeof e._ui.failedOnce && this.manageFailingFieldTrigger(e)
                }
            },
            getErrorsMessages: function(e) {
                if (!0 === e.validationResult) return [];
                for (var t = [], n = 0; n < e.validationResult.length; n++) t.push(this._getErrorMessage(e, e.validationResult[n].assert));
                return t
            },
            manageStatusClass: function(e) {
                !0 === e.validationResult ? this._successClass(e) : e.validationResult.length > 0 ? this._errorClass(e) : this._resetClass(e)
            },
            manageErrorsMessages: function(t, n) {
                if ("undefined" == typeof t.options.errorsMessagesDisabled) {
                    if ("undefined" != typeof t.options.errorMessage) return n.added.length || n.kept.length ? (0 === t._ui.$errorsWrapper.find(".parsley-custom-error-message").length && t._ui.$errorsWrapper.append(e(t.options.errorTemplate).addClass("parsley-custom-error-message")), t._ui.$errorsWrapper.addClass("filled").find(".parsley-custom-error-message").html(t.options.errorMessage)) : t._ui.$errorsWrapper.removeClass("filled").find(".parsley-custom-error-message").remove();
                    for (var i = 0; i < n.removed.length; i++) this.removeError(t, n.removed[i].assert.name, !0);
                    for (i = 0; i < n.added.length; i++) this.addError(t, n.added[i].assert.name, void 0, n.added[i].assert, !0);
                    for (i = 0; i < n.kept.length; i++) this.updateError(t, n.kept[i].assert.name, void 0, n.kept[i].assert, !0)
                }
            },
            addError: function(t, n, i, r, s) {
                t._ui.$errorsWrapper.addClass("filled").append(e(t.options.errorTemplate).addClass("parsley-" + n).html(i || this._getErrorMessage(t, r))), !0 !== s && this._errorClass(t)
            },
            updateError: function(e, t, n, i, r) {
                e._ui.$errorsWrapper.addClass("filled").find(".parsley-" + t).html(n || this._getErrorMessage(e, i)), !0 !== r && this._errorClass(e)
            },
            removeError: function(e, t, n) {
                e._ui.$errorsWrapper.removeClass("filled").find(".parsley-" + t).remove(), !0 !== n && this.manageStatusClass(e)
            },
            focus: function(e) {
                if (!0 === e.validationResult || "none" === e.options.focus) return e._focusedField = null;
                e._focusedField = null;
                for (var t = 0; t < e.fields.length; t++)
                    if (!0 !== e.fields[t].validationResult && e.fields[t].validationResult.length > 0 && "undefined" == typeof e.fields[t].options.noFocus) {
                        if ("first" === e.options.focus) return e._focusedField = e.fields[t].$element, e._focusedField.focus();
                        e._focusedField = e.fields[t].$element
                    }
                return null === e._focusedField ? null : e._focusedField.focus()
            },
            _getErrorMessage: function(e, t) {
                var n = t.name + "Message";
                return "undefined" != typeof e.options[n] ? window.ParsleyValidator.formatMessage(e.options[n], t.requirements) : window.ParsleyValidator.getErrorMessage(t)
            },
            _diff: function(e, t, n) {
                for (var i = [], r = [], s = 0; s < e.length; s++) {
                    for (var o = !1, a = 0; a < t.length; a++)
                        if (e[s].assert.name === t[a].assert.name) {
                            o = !0;
                            break
                        }
                    o ? r.push(e[s]) : i.push(e[s])
                }
                return {
                    kept: r,
                    added: i,
                    removed: n ? [] : this._diff(t, e, !0).added
                }
            },
            setupForm: function(t) {
                t.$element.on("submit.Parsley", !1, e.proxy(t.onSubmitValidate, t)), !1 !== t.options.uiEnabled && t.$element.attr("novalidate", "")
            },
            setupField: function(t) {
                var n = {
                    active: !1
                };
                !1 !== t.options.uiEnabled && (n.active = !0, t.$element.attr(t.options.namespace + "id", t.__id__), n.$errorClassHandler = this._manageClassHandler(t), n.errorsWrapperId = "parsley-id-" + ("undefined" != typeof t.options.multiple ? "multiple-" + t.options.multiple : t.__id__), n.$errorsWrapper = e(t.options.errorsWrapper).attr("id", n.errorsWrapperId), n.lastValidationResult = [], n.validatedOnce = !1, n.validationInformationVisible = !1, t._ui = n, t.$element.is(t.options.excluded) || this._insertErrorWrapper(t), this.actualizeTriggers(t))
            },
            _manageClassHandler: function(t) {
                if ("string" == typeof t.options.classHandler && e(t.options.classHandler).length) return e(t.options.classHandler);
                var n = t.options.classHandler(t);
                return "undefined" != typeof n && n.length ? n : "undefined" == typeof t.options.multiple || t.$element.is("select") ? t.$element : t.$element.parent()
            },
            _insertErrorWrapper: function(t) {
                var n;
                if ("string" == typeof t.options.errorsContainer) {
                    if (e(t.options.errorsContainer).length) return e(t.options.errorsContainer).append(t._ui.$errorsWrapper);
                    window.console && window.console.warn && window.console.warn("The errors container `" + t.options.errorsContainer + "` does not exist in DOM")
                } else "function" == typeof t.options.errorsContainer && (n = t.options.errorsContainer(t));
                return "undefined" != typeof n && n.length ? n.append(t._ui.$errorsWrapper) : "undefined" == typeof t.options.multiple ? t.$element.after(t._ui.$errorsWrapper) : t.$element.parent().after(t._ui.$errorsWrapper)
            },
            actualizeTriggers: function(t) {
                var n = t.$element;
                if (t.options.multiple && (n = e("[" + t.options.namespace + 'multiple="' + t.options.multiple + '"]')), n.off(".Parsley"), !1 !== t.options.trigger) {
                    var i = t.options.trigger.replace(/^\s+/g, "").replace(/\s+$/g, "");
                    "" !== i && n.on(i.split(" ").join(".Parsley ") + ".Parsley", e.proxy("function" == typeof t.eventValidate ? t.eventValidate : this.eventValidate, t))
                }
            },
            eventValidate: function(e) {
                new RegExp("key").test(e.type) && !this._ui.validationInformationVisible && this.getValue().length <= this.options.validationThreshold || (this._ui.validatedOnce = !0, this.validate())
            },
            manageFailingFieldTrigger: function(t) {
                return t._ui.failedOnce = !0, t.options.multiple && e("[" + t.options.namespace + 'multiple="' + t.options.multiple + '"]').each(function() {
                    return new RegExp("change", "i").test(e(this).parsley().options.trigger || "") ? void 0 : e(this).on("change.ParsleyFailedOnce", !1, e.proxy(t.validate, t))
                }), t.$element.is("select") && !new RegExp("change", "i").test(t.options.trigger || "") ? t.$element.on("change.ParsleyFailedOnce", !1, e.proxy(t.validate, t)) : new RegExp("keyup", "i").test(t.options.trigger || "") ? void 0 : t.$element.on("keyup.ParsleyFailedOnce", !1, e.proxy(t.validate, t))
            },
            reset: function(e) {
                e.$element.off(".Parsley"), e.$element.off(".ParsleyFailedOnce"), "undefined" != typeof e._ui && "ParsleyForm" !== e.__class__ && (e._ui.$errorsWrapper.removeClass("filled").children().remove(), this._resetClass(e), e._ui.validatedOnce = !1, e._ui.lastValidationResult = [], e._ui.validationInformationVisible = !1)
            },
            destroy: function(e) {
                this.reset(e), "ParsleyForm" !== e.__class__ && ("undefined" != typeof e._ui && e._ui.$errorsWrapper.remove(), delete e._ui)
            },
            _successClass: function(e) {
                e._ui.validationInformationVisible = !0, e._ui.$errorClassHandler.removeClass(e.options.errorClass).addClass(e.options.successClass)
            },
            _errorClass: function(e) {
                e._ui.validationInformationVisible = !0, e._ui.$errorClassHandler.removeClass(e.options.successClass).addClass(e.options.errorClass)
            },
            _resetClass: function(e) {
                e._ui.$errorClassHandler.removeClass(e.options.successClass).removeClass(e.options.errorClass)
            }
        };
        var a = function(n, i, r, s) {
            this.__class__ = "OptionsFactory", this.__id__ = t.hash(4), this.formOptions = null, this.fieldOptions = null, this.staticOptions = e.extend(!0, {}, n, i, r, {
                namespace: s
            })
        };
        a.prototype = {
            get: function(e) {
                if ("undefined" == typeof e.__class__) throw new Error("Parsley Instance expected");
                switch (e.__class__) {
                    case "Parsley":
                        return this.staticOptions;
                    case "ParsleyForm":
                        return this.getFormOptions(e);
                    case "ParsleyField":
                    case "ParsleyFieldMultiple":
                        return this.getFieldOptions(e);
                    default:
                        throw new Error("Instance " + e.__class__ + " is not supported")
                }
            },
            getFormOptions: function(n) {
                return this.formOptions = t.attr(n.$element, this.staticOptions.namespace), e.extend({}, this.staticOptions, this.formOptions)
            },
            getFieldOptions: function(n) {
                return this.fieldOptions = t.attr(n.$element, this.staticOptions.namespace), null === this.formOptions && "undefined" != typeof n.parent && (this.formOptions = this.getFormOptions(n.parent)), e.extend({}, this.staticOptions, this.formOptions, this.fieldOptions)
            }
        };
        var u = function(n, i) {
            if (this.__class__ = "ParsleyForm", this.__id__ = t.hash(4), "OptionsFactory" !== t.get(i, "__class__")) throw new Error("You must give an OptionsFactory instance");
            this.OptionsFactory = i, this.$element = e(n), this.validationResult = null, this.options = this.OptionsFactory.get(this)
        };
        u.prototype = {
            onSubmitValidate: function(t) {
                return this.validate(void 0, void 0, t), !1 === this.validationResult && t instanceof e.Event && (t.stopImmediatePropagation(), t.preventDefault()), this
            },
            validate: function(t, n, i) {
                this.submitEvent = i, this.validationResult = !0;
                var r = [];
                e.emit("parsley:form:validate", this), this._refreshFields();
                for (var s = 0; s < this.fields.length; s++)(!t || this._isFieldInGroup(this.fields[s], t)) && (r = this.fields[s].validate(n), !0 !== r && r.length > 0 && this.validationResult && (this.validationResult = !1));
                return e.emit("parsley:form:" + (this.validationResult ? "success" : "error"), this), e.emit("parsley:form:validated", this), this.validationResult
            },
            isValid: function(e, t) {
                this._refreshFields();
                for (var n = 0; n < this.fields.length; n++)
                    if ((!e || this._isFieldInGroup(this.fields[n], e)) && !1 === this.fields[n].isValid(t)) return !1;
                return !0
            },
            _isFieldInGroup: function(n, i) {
                return t.isArray(n.options.group) ? -1 !== e.inArray(i, n.options.group) : n.options.group === i
            },
            _refreshFields: function() {
                return this.actualizeOptions()._bindFields()
            },
            _bindFields: function() {
                var e = this;
                return this.fields = [], this.fieldsMappedById = {}, this.$element.find(this.options.inputs).each(function() {
                    var t = new window.Parsley(this, {}, e);
                    "ParsleyField" !== t.__class__ && "ParsleyFieldMultiple" !== t.__class__ || t.$element.is(t.options.excluded) || "undefined" == typeof e.fieldsMappedById[t.__class__ + "-" + t.__id__] && (e.fieldsMappedById[t.__class__ + "-" + t.__id__] = t, e.fields.push(t))
                }), this
            }
        };
        var l = function(n, i, r, s, o) {
                var a = {};
                if (!new RegExp("ParsleyField").test(t.get(n, "__class__"))) throw new Error("ParsleyField or ParsleyFieldMultiple instance expected");
                if ("function" == typeof window.ParsleyValidator.validators[i] && (a = window.ParsleyValidator.validators[i](r)), "Assert" !== a.__parentClass__) throw new Error("Valid validator expected");
                var u = function() {
                    return "undefined" != typeof n.options[i + "Priority"] ? n.options[i + "Priority"] : t.get(a, "priority") || 2
                };
                return s = s || u(), "function" == typeof a.requirementsTransformer && (r = a.requirementsTransformer(), a = window.ParsleyValidator.validators[i](r)), e.extend(a, {
                    name: i,
                    requirements: r,
                    priority: s,
                    groups: [s],
                    isDomConstraint: o || t.attr(n.$element, n.options.namespace, i)
                })
            },
            c = function(n, i, r) {
                this.__class__ = "ParsleyField", this.__id__ = t.hash(4), this.$element = e(n), "undefined" != typeof r ? (this.parent = r, this.OptionsFactory = this.parent.OptionsFactory, this.options = this.OptionsFactory.get(this)) : (this.OptionsFactory = i, this.options = this.OptionsFactory.get(this)), this.constraints = [], this.constraintsByName = {}, this.validationResult = [], this._bindConstraints()
            };
        c.prototype = {
            validate: function(t) {
                return this.value = this.getValue(), e.emit("parsley:field:validate", this), e.emit("parsley:field:" + (this.isValid(t, this.value) ? "success" : "error"), this), e.emit("parsley:field:validated", this), this.validationResult
            },
            isValid: function(e, t) {
                this.refreshConstraints();
                var n = this._getConstraintsSortedPriorities();
                if (0 === n.length) return this.validationResult = [];
                if (("undefined" == typeof t || null === t) && (t = this.getValue()), !t.length && !this._isRequired() && "undefined" == typeof this.options.validateIfEmpty && !0 !== e) return this.validationResult = [];
                if (!1 === this.options.priorityEnabled) return !0 === (this.validationResult = this.validateThroughValidator(t, this.constraints, "Any"));
                for (var i = 0; i < n.length; i++)
                    if (!0 !== (this.validationResult = this.validateThroughValidator(t, this.constraints, n[i]))) return !1;
                return !0
            },
            getValue: function() {
                var e;
                return e = "undefined" != typeof this.options.value ? this.options.value : this.$element.val(), "undefined" == typeof e || null === e ? "" : !0 === this.options.trimValue ? e.replace(/^\s+|\s+$/g, "") : e
            },
            refreshConstraints: function() {
                return this.actualizeOptions()._bindConstraints()
            },
            addConstraint: function(e, t, n, i) {
                if (e = e.toLowerCase(), "function" == typeof window.ParsleyValidator.validators[e]) {
                    var r = new l(this, e, t, n, i);
                    "undefined" !== this.constraintsByName[r.name] && this.removeConstraint(r.name), this.constraints.push(r), this.constraintsByName[r.name] = r
                }
                return this
            },
            removeConstraint: function(e) {
                for (var t = 0; t < this.constraints.length; t++)
                    if (e === this.constraints[t].name) {
                        this.constraints.splice(t, 1);
                        break
                    }
                return delete this.constraintsByName[e], this
            },
            updateConstraint: function(e, t, n) {
                return this.removeConstraint(e).addConstraint(e, t, n)
            },
            _bindConstraints: function() {
                for (var e = [], t = {}, n = 0; n < this.constraints.length; n++) !1 === this.constraints[n].isDomConstraint && (e.push(this.constraints[n]), t[this.constraints[n].name] = this.constraints[n]);
                this.constraints = e, this.constraintsByName = t;
                for (var i in this.options) this.addConstraint(i, this.options[i]);
                return this._bindHtml5Constraints()
            },
            _bindHtml5Constraints: function() {
                (this.$element.hasClass("required") || this.$element.attr("required")) && this.addConstraint("required", !0, void 0, !0), "string" == typeof this.$element.attr("pattern") && this.addConstraint("pattern", this.$element.attr("pattern"), void 0, !0), "undefined" != typeof this.$element.attr("min") && "undefined" != typeof this.$element.attr("max") ? this.addConstraint("range", [this.$element.attr("min"), this.$element.attr("max")], void 0, !0) : "undefined" != typeof this.$element.attr("min") ? this.addConstraint("min", this.$element.attr("min"), void 0, !0) : "undefined" != typeof this.$element.attr("max") && this.addConstraint("max", this.$element.attr("max"), void 0, !0), "undefined" != typeof this.$element.attr("minlength") && "undefined" != typeof this.$element.attr("maxlength") ? this.addConstraint("length", [this.$element.attr("minlength"), this.$element.attr("maxlength")], void 0, !0) : "undefined" != typeof this.$element.attr("minlength") ? this.addConstraint("minlength", this.$element.attr("minlength"), void 0, !0) : "undefined" != typeof this.$element.attr("maxlength") && this.addConstraint("maxlength", this.$element.attr("maxlength"), void 0, !0);
                var e = this.$element.attr("type");
                return "undefined" == typeof e ? this : "number" === e ? "undefined" == typeof this.$element.attr("step") || 0 === parseFloat(this.$element.attr("step")) % 1 ? this.addConstraint("type", "integer", void 0, !0) : this.addConstraint("type", "number", void 0, !0) : new RegExp(e, "i").test("email url range") ? this.addConstraint("type", e, void 0, !0) : this
            },
            _isRequired: function() {
                return "undefined" == typeof this.constraintsByName.required ? !1 : !1 !== this.constraintsByName.required.requirements
            },
            _getConstraintsSortedPriorities: function() {
                for (var e = [], t = 0; t < this.constraints.length; t++) - 1 === e.indexOf(this.constraints[t].priority) && e.push(this.constraints[t].priority);
                return e.sort(function(e, t) {
                    return t - e
                }), e
            }
        };
        var d = function() {
            this.__class__ = "ParsleyFieldMultiple"
        };
        d.prototype = {
            addElement: function(e) {
                return this.$elements.push(e), this
            },
            refreshConstraints: function() {
                var t;
                if (this.constraints = [], this.$element.is("select")) return this.actualizeOptions()._bindConstraints(), this;
                for (var n = 0; n < this.$elements.length; n++)
                    if (e("html").has(this.$elements[n]).length) {
                        t = this.$elements[n].data("ParsleyFieldMultiple").refreshConstraints().constraints;
                        for (var i = 0; i < t.length; i++) this.addConstraint(t[i].name, t[i].requirements, t[i].priority, t[i].isDomConstraint)
                    } else this.$elements.splice(n, 1);
                return this
            },
            getValue: function() {
                if ("undefined" != typeof this.options.value) return this.options.value;
                if (this.$element.is("input[type=radio]")) return e("[" + this.options.namespace + 'multiple="' + this.options.multiple + '"]:checked').val() || "";
                if (this.$element.is("input[type=checkbox]")) {
                    var t = [];
                    return e("[" + this.options.namespace + 'multiple="' + this.options.multiple + '"]:checked').each(function() {
                        t.push(e(this).val())
                    }), t.length ? t : []
                }
                return this.$element.is("select") && null === this.$element.val() ? [] : this.$element.val()
            },
            _init: function(e) {
                return this.$elements = [this.$element], this.options.multiple = e, this
            }
        };
        var f = e({}),
            h = {};
        e.listen = function(e) {
            if ("undefined" == typeof h[e] && (h[e] = []), "function" == typeof arguments[1]) return h[e].push({
                fn: arguments[1]
            });
            if ("object" == typeof arguments[1] && "function" == typeof arguments[2]) return h[e].push({
                fn: arguments[2],
                ctxt: arguments[1]
            });
            throw new Error("Wrong parameters")
        }, e.listenTo = function(e, t, n) {
            if ("undefined" == typeof h[t] && (h[t] = []), !(e instanceof c || e instanceof u)) throw new Error("Must give Parsley instance");
            if ("string" != typeof t || "function" != typeof n) throw new Error("Wrong parameters");
            h[t].push({
                instance: e,
                fn: n
            })
        }, e.unsubscribe = function(e, t) {
            if ("undefined" != typeof h[e]) {
                if ("string" != typeof e || "function" != typeof t) throw new Error("Wrong arguments");
                for (var n = 0; n < h[e].length; n++)
                    if (h[e][n].fn === t) return h[e].splice(n, 1)
            }
        }, e.unsubscribeTo = function(e, t) {
            if ("undefined" != typeof h[t]) {
                if (!(e instanceof c || e instanceof u)) throw new Error("Must give Parsley instance");
                for (var n = 0; n < h[t].length; n++)
                    if ("undefined" != typeof h[t][n].instance && h[t][n].instance.__id__ === e.__id__) return h[t].splice(n, 1)
            }
        }, e.unsubscribeAll = function(e) {
            "undefined" != typeof h[e] && delete h[e]
        }, e.emit = function(e, t) {
            if ("undefined" != typeof h[e])
                for (var n = 0; n < h[e].length; n++)
                    if ("undefined" != typeof h[e][n].instance) {
                        if (t instanceof c || t instanceof u)
                            if (h[e][n].instance.__id__ !== t.__id__) {
                                if (h[e][n].instance instanceof u && t instanceof c)
                                    for (var i = 0; i < h[e][n].instance.fields.length; i++)
                                        if (h[e][n].instance.fields[i].__id__ === t.__id__) {
                                            h[e][n].fn.apply(f, Array.prototype.slice.call(arguments, 1));
                                            continue
                                        }
                            } else h[e][n].fn.apply(f, Array.prototype.slice.call(arguments, 1))
                    } else h[e][n].fn.apply("undefined" != typeof h[e][n].ctxt ? h[e][n].ctxt : f, Array.prototype.slice.call(arguments, 1))
        }, e.subscribed = function() {
            return h
        }, window.ParsleyConfig = window.ParsleyConfig || {}, window.ParsleyConfig.i18n = window.ParsleyConfig.i18n || {}, window.ParsleyConfig.i18n.en = e.extend(window.ParsleyConfig.i18n.en || {}, {
            defaultMessage: "This value seems to be invalid.",
            type: {
                email: "This value should be a valid email.",
                url: "This value should be a valid url.",
                number: "This value should be a valid number.",
                integer: "This value should be a valid integer.",
                digits: "This value should be digits.",
                alphanum: "This value should be alphanumeric."
            },
            notblank: "This value should not be blank.",
            required: "This value is required.",
            pattern: "This value seems to be invalid.",
            min: "This value should be greater than or equal to %s.",
            max: "This value should be lower than or equal to %s.",
            range: "This value should be between %s and %s.",
            minlength: "This value is too short. It should have %s characters or more.",
            maxlength: "This value is too long. It should have %s characters or fewer.",
            length: "This value length is invalid. It should be between %s and %s characters long.",
            mincheck: "You must select at least %s choices.",
            maxcheck: "You must select %s choices or fewer.",
            check: "You must select between %s and %s choices.",
            equalto: "This value should be the same."
        }), "undefined" != typeof window.ParsleyValidator && window.ParsleyValidator.addCatalog("en", window.ParsleyConfig.i18n.en, !0);
        var p = function(n, i, r) {
            if (this.__class__ = "Parsley", this.__version__ = "2.0.6", this.__id__ = t.hash(4), "undefined" == typeof n) throw new Error("You must give an element");
            if ("undefined" != typeof r && "ParsleyForm" !== r.__class__) throw new Error("Parent instance must be a ParsleyForm instance");
            return this.init(e(n), i, r)
        };
        p.prototype = {
            init: function(e, i, r) {
                if (!e.length) throw new Error("You must bind Parsley on an existing element.");
                if (this.$element = e, this.$element.data("Parsley")) {
                    var s = this.$element.data("Parsley");
                    return "undefined" != typeof r && (s.parent = r), s
                }
                return this.OptionsFactory = new a(n, t.get(window, "ParsleyConfig") || {}, i, this.getNamespace(i)), this.options = this.OptionsFactory.get(this), this.$element.is("form") || t.attr(this.$element, this.options.namespace, "validate") && !this.$element.is(this.options.inputs) ? this.bind("parsleyForm") : this.$element.is(this.options.inputs) && !this.$element.is(this.options.excluded) ? this.isMultiple() ? this.handleMultiple(r) : this.bind("parsleyField", r) : this
            },
            isMultiple: function() {
                return this.$element.is("input[type=radio], input[type=checkbox]") && "undefined" == typeof this.options.multiple || this.$element.is("select") && "undefined" != typeof this.$element.attr("multiple")
            },
            handleMultiple: function(n) {
                var i, r, s, o = this;
                if (this.options = e.extend(this.options, n ? n.OptionsFactory.get(n) : {}, t.attr(this.$element, this.options.namespace)), this.options.multiple ? r = this.options.multiple : "undefined" != typeof this.$element.attr("name") && this.$element.attr("name").length ? r = i = this.$element.attr("name") : "undefined" != typeof this.$element.attr("id") && this.$element.attr("id").length && (r = this.$element.attr("id")), this.$element.is("select") && "undefined" != typeof this.$element.attr("multiple")) return this.bind("parsleyFieldMultiple", n, r || this.__id__);
                if ("undefined" == typeof r) return window.console && window.console.warn && window.console.warn("To be binded by Parsley, a radio, a checkbox and a multiple select input must have either a name or a multiple option.", this.$element), this;
                if (r = r.replace(/(:|\.|\[|\]|\{|\}|\$)/g, ""), "undefined" != typeof i && e('input[name="' + i + '"]').each(function() {
                        e(this).is("input[type=radio], input[type=checkbox]") && e(this).attr(o.options.namespace + "multiple", r)
                    }), e("[" + this.options.namespace + "multiple=" + r + "]").length)
                    for (var a = 0; a < e("[" + this.options.namespace + "multiple=" + r + "]").length; a++)
                        if ("undefined" != typeof e(e("[" + this.options.namespace + "multiple=" + r + "]").get(a)).data("Parsley")) {
                            s = e(e("[" + this.options.namespace + "multiple=" + r + "]").get(a)).data("Parsley"), this.$element.data("ParsleyFieldMultiple") || (s.addElement(this.$element), this.$element.attr(this.options.namespace + "id", s.__id__));
                            break
                        }
                return this.bind("parsleyField", n, r, !0), s || this.bind("parsleyFieldMultiple", n, r)
            },
            getNamespace: function(e) {
                return "undefined" != typeof this.$element.data("parsleyNamespace") ? this.$element.data("parsleyNamespace") : "undefined" != typeof t.get(e, "namespace") ? e.namespace : "undefined" != typeof t.get(window, "ParsleyConfig.namespace") ? window.ParsleyConfig.namespace : n.namespace
            },
            bind: function(n, r, s, o) {
                var a;
                switch (n) {
                    case "parsleyForm":
                        a = e.extend(new u(this.$element, this.OptionsFactory), new i, window.ParsleyExtend)._bindFields();
                        break;
                    case "parsleyField":
                        a = e.extend(new c(this.$element, this.OptionsFactory, r), new i, window.ParsleyExtend);
                        break;
                    case "parsleyFieldMultiple":
                        a = e.extend(new c(this.$element, this.OptionsFactory, r), new i, new d, window.ParsleyExtend)._init(s);
                        break;
                    default:
                        throw new Error(n + "is not a supported Parsley type")
                }
                return "undefined" != typeof s && t.setAttr(this.$element, this.options.namespace, "multiple", s), "undefined" != typeof o ? (this.$element.data("ParsleyFieldMultiple", a), a) : (new RegExp("ParsleyF", "i").test(a.__class__) && (this.$element.data("Parsley", a), e.emit("parsley:" + ("parsleyForm" === n ? "form" : "field") + ":init", a)), a)
            }
        }, e.fn.parsley = e.fn.psly = function(t) {
            if (this.length > 1) {
                var n = [];
                return this.each(function() {
                    n.push(e(this).parsley(t))
                }), n
            }
            return e(this).length ? new p(this, t) : void(window.console && window.console.warn && window.console.warn("You must bind Parsley on an existing element."))
        }, window.ParsleyUI = "function" == typeof t.get(window, "ParsleyConfig.ParsleyUI") ? (new window.ParsleyConfig.ParsleyUI).listen() : (new o).listen(), "undefined" == typeof window.ParsleyExtend && (window.ParsleyExtend = {}), "undefined" == typeof window.ParsleyConfig && (window.ParsleyConfig = {}), window.Parsley = window.psly = p, window.ParsleyUtils = t, window.ParsleyValidator = new s(window.ParsleyConfig.validators, window.ParsleyConfig.i18n), !1 !== t.get(window, "ParsleyConfig.autoBind") && e(function() {
            e("[data-parsley-validate]").length && e("[data-parsley-validate]").parsley()
        })
    }), ! function(e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery)
    }(function(e) {
        "undefined" == typeof e && "undefined" != typeof window.jQuery && (e = window.jQuery);
        var t = {
                attr: function(e, t, n) {
                    var i, r = {},
                        s = this.msieversion(),
                        o = new RegExp("^" + t, "i");
                    if ("undefined" == typeof e || "undefined" == typeof e[0]) return {};
                    for (var a in e[0].attributes)
                        if (i = e[0].attributes[a], "undefined" != typeof i && null !== i && (!s || s >= 8 || i.specified) && o.test(i.name)) {
                            if ("undefined" != typeof n && new RegExp(n + "$", "i").test(i.name)) return !0;
                            r[this.camelize(i.name.replace(t, ""))] = this.deserializeValue(i.value)
                        }
                    return "undefined" == typeof n ? r : !1
                },
                setAttr: function(e, t, n, i) {
                    e[0].setAttribute(this.dasherize(t + n), String(i))
                },
                get: function(e, t) {
                    for (var n = 0, i = (t || "").split("."); this.isObject(e) || this.isArray(e);)
                        if (e = e[i[n++]], n === i.length) return e;
                    return void 0
                },
                hash: function(e) {
                    return String(Math.random()).substring(2, e ? e + 2 : 9)
                },
                isArray: function(e) {
                    return "[object Array]" === Object.prototype.toString.call(e)
                },
                isObject: function(e) {
                    return e === Object(e)
                },
                deserializeValue: function(t) {
                    var n;
                    try {
                        return t ? "true" == t || ("false" == t ? !1 : "null" == t ? null : isNaN(n = Number(t)) ? /^[\[\{]/.test(t) ? e.parseJSON(t) : t : n) : t
                    } catch (i) {
                        return t
                    }
                },
                camelize: function(e) {
                    return e.replace(/-+(.)?/g, function(e, t) {
                        return t ? t.toUpperCase() : ""
                    })
                },
                dasherize: function(e) {
                    return e.replace(/::/g, "/").replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2").replace(/([a-z\d])([A-Z])/g, "$1_$2").replace(/_/g, "-").toLowerCase()
                },
                msieversion: function() {
                    var e = window.navigator.userAgent,
                        t = e.indexOf("MSIE ");
                    return t > 0 || navigator.userAgent.match(/Trident.*rv\:11\./) ? parseInt(e.substring(t + 5, e.indexOf(".", t)), 10) : 0
                }
            },
            n = {
                namespace: "data-parsley-",
                inputs: "input, textarea, select",
                excluded: "input[type=button], input[type=submit], input[type=reset], input[type=hidden]",
                priorityEnabled: !0,
                uiEnabled: !0,
                validationThreshold: 3,
                focus: "first",
                trigger: !1,
                errorClass: "parsley-error",
                successClass: "parsley-success",
                classHandler: function() {},
                errorsContainer: function() {},
                errorsWrapper: '<ul class="parsley-errors-list"></ul>',
                errorTemplate: "<li></li>"
            },
            i = function() {};
        i.prototype = {
            asyncSupport: !1,
            actualizeOptions: function() {
                return this.options = this.OptionsFactory.get(this), this
            },
            validateThroughValidator: function(e, t, n) {
                return window.ParsleyValidator.validate(e, t, n)
            },
            subscribe: function(t, n) {
                return e.listenTo(this, t.toLowerCase(), n), this
            },
            unsubscribe: function(t) {
                return e.unsubscribeTo(this, t.toLowerCase()), this
            },
            reset: function() {
                if ("ParsleyForm" !== this.__class__) return e.emit("parsley:field:reset", this);
                for (var t = 0; t < this.fields.length; t++) e.emit("parsley:field:reset", this.fields[t]);
                e.emit("parsley:form:reset", this)
            },
            destroy: function() {
                if ("ParsleyForm" !== this.__class__) return this.$element.removeData("Parsley"), this.$element.removeData("ParsleyFieldMultiple"), void e.emit("parsley:field:destroy", this);
                for (var t = 0; t < this.fields.length; t++) this.fields[t].destroy();
                this.$element.removeData("Parsley"), e.emit("parsley:form:destroy", this)
            }
        };
        var r = function() {
            var e = {},
                t = function(e) {
                    this.__class__ = "Validator", this.__version__ = "1.0.1", this.options = e || {}, this.bindingKey = this.options.bindingKey || "_validatorjsConstraint"
                };
            t.prototype = {
                constructor: t,
                validate: function(e, t, n) {
                    if ("string" != typeof e && "object" != typeof e) throw new Error("You must validate an object or a string");
                    return "string" == typeof e || o(e) ? this._validateString(e, t, n) : this.isBinded(e) ? this._validateBindedObject(e, t) : this._validateObject(e, t, n)
                },
                bind: function(e, t) {
                    if ("object" != typeof e) throw new Error("Must bind a Constraint to an object");
                    return e[this.bindingKey] = new n(t), this
                },
                unbind: function(e) {
                    return "undefined" == typeof e._validatorjsConstraint ? this : (delete e[this.bindingKey], this)
                },
                isBinded: function(e) {
                    return "undefined" != typeof e[this.bindingKey]
                },
                getBinded: function(e) {
                    return this.isBinded(e) ? e[this.bindingKey] : null
                },
                _validateString: function(e, t, n) {
                    var s, a = [];
                    o(t) || (t = [t]);
                    for (var u = 0; u < t.length; u++) {
                        if (!(t[u] instanceof r)) throw new Error("You must give an Assert or an Asserts array to validate a string");
                        s = t[u].check(e, n), s instanceof i && a.push(s)
                    }
                    return a.length ? a : !0
                },
                _validateObject: function(e, t, i) {
                    if ("object" != typeof t) throw new Error("You must give a constraint to validate an object");
                    return t instanceof n ? t.check(e, i) : new n(t).check(e, i)
                },
                _validateBindedObject: function(e, t) {
                    return e[this.bindingKey].check(e, t)
                }
            }, t.errorCode = {
                must_be_a_string: "must_be_a_string",
                must_be_an_array: "must_be_an_array",
                must_be_a_number: "must_be_a_number",
                must_be_a_string_or_array: "must_be_a_string_or_array"
            };
            var n = function(e, t) {
                if (this.__class__ = "Constraint", this.options = t || {}, this.nodes = {}, e) try {
                    this._bootstrap(e)
                } catch (n) {
                    throw new Error("Should give a valid mapping object to Constraint", n, e)
                }
            };
            n.prototype = {
                constructor: n,
                check: function(e, t) {
                    var n, i = {};
                    for (var a in this.nodes) {
                        for (var u = !1, l = this.get(a), c = o(l) ? l : [l], d = c.length - 1; d >= 0; d--) "Required" !== c[d].__class__ || (u = c[d].requiresValidation(t));
                        if (this.has(a, e) || this.options.strict || u) try {
                            this.has(a, this.options.strict || u ? e : void 0) || (new r).HaveProperty(a).validate(e), n = this._check(a, e[a], t), (o(n) && n.length > 0 || !o(n) && !s(n)) && (i[a] = n)
                        } catch (f) {
                            i[a] = f
                        }
                    }
                    return s(i) ? !0 : i
                },
                add: function(e, t) {
                    if (t instanceof r || o(t) && t[0] instanceof r) return this.nodes[e] = t, this;
                    if ("object" == typeof t && !o(t)) return this.nodes[e] = t instanceof n ? t : new n(t), this;
                    throw new Error("Should give an Assert, an Asserts array, a Constraint", t)
                },
                has: function(e, t) {
                    return t = "undefined" != typeof t ? t : this.nodes, "undefined" != typeof t[e]
                },
                get: function(e, t) {
                    return this.has(e) ? this.nodes[e] : t || null
                },
                remove: function(e) {
                    var t = [];
                    for (var n in this.nodes) n !== e && (t[n] = this.nodes[n]);
                    return this.nodes = t, this
                },
                _bootstrap: function(e) {
                    if (e instanceof n) return this.nodes = e.nodes;
                    for (var t in e) this.add(t, e[t])
                },
                _check: function(e, t, i) {
                    if (this.nodes[e] instanceof r) return this._checkAsserts(t, [this.nodes[e]], i);
                    if (o(this.nodes[e])) return this._checkAsserts(t, this.nodes[e], i);
                    if (this.nodes[e] instanceof n) return this.nodes[e].check(t, i);
                    throw new Error("Invalid node", this.nodes[e])
                },
                _checkAsserts: function(e, t, n) {
                    for (var i, r = [], s = 0; s < t.length; s++) i = t[s].check(e, n), "undefined" != typeof i && !0 !== i && r.push(i);
                    return r
                }
            };
            var i = function(e, t, n) {
                if (this.__class__ = "Violation", !(e instanceof r)) throw new Error("Should give an assertion implementing the Assert interface");
                this.assert = e, this.value = t, "undefined" != typeof n && (this.violation = n)
            };
            i.prototype = {
                show: function() {
                    var e = {
                        assert: this.assert.__class__,
                        value: this.value
                    };
                    return this.violation && (e.violation = this.violation), e
                },
                __toString: function() {
                    return "undefined" != typeof this.violation && (this.violation = '", ' + this.getViolation().constraint + " expected was " + this.getViolation().expected), this.assert.__class__ + ' assert failed for "' + this.value + this.violation || ""
                },
                getViolation: function() {
                    var e, t;
                    for (e in this.violation) t = this.violation[e];
                    return {
                        constraint: e,
                        expected: t
                    }
                }
            };
            var r = function(e) {
                this.__class__ = "Assert", this.__parentClass__ = this.__class__, this.groups = [], "undefined" != typeof e && this.addGroup(e)
            };
            r.prototype = {
                construct: r,
                requiresValidation: function(e) {
                    return e && !this.hasGroup(e) ? !1 : !e && this.hasGroups() ? !1 : !0
                },
                check: function(e, t) {
                    if (this.requiresValidation(t)) try {
                        return this.validate(e, t)
                    } catch (n) {
                        return n
                    }
                },
                hasGroup: function(e) {
                    return o(e) ? this.hasOneOf(e) : "Any" === e ? !0 : this.hasGroups() ? -1 !== this.groups.indexOf(e) : "Default" === e
                },
                hasOneOf: function(e) {
                    for (var t = 0; t < e.length; t++)
                        if (this.hasGroup(e[t])) return !0;
                    return !1
                },
                hasGroups: function() {
                    return this.groups.length > 0
                },
                addGroup: function(e) {
                    return o(e) ? this.addGroups(e) : (this.hasGroup(e) || this.groups.push(e), this)
                },
                removeGroup: function(e) {
                    for (var t = [], n = 0; n < this.groups.length; n++) e !== this.groups[n] && t.push(this.groups[n]);
                    return this.groups = t, this
                },
                addGroups: function(e) {
                    for (var t = 0; t < e.length; t++) this.addGroup(e[t]);
                    return this
                },
                HaveProperty: function(e) {
                    return this.__class__ = "HaveProperty", this.node = e, this.validate = function(e) {
                        if ("undefined" == typeof e[this.node]) throw new i(this, e, {
                            value: this.node
                        });
                        return !0
                    }, this
                },
                Blank: function() {
                    return this.__class__ = "Blank", this.validate = function(e) {
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if ("" !== e.replace(/^\s+/g, "").replace(/\s+$/g, "")) throw new i(this, e);
                        return !0
                    }, this
                },
                Callback: function(e) {
                    if (this.__class__ = "Callback", this.arguments = Array.prototype.slice.call(arguments), 1 === this.arguments.length ? this.arguments = [] : this.arguments.splice(0, 1), "function" != typeof e) throw new Error("Callback must be instanciated with a function");
                    return this.fn = e, this.validate = function(e) {
                        var t = this.fn.apply(this, [e].concat(this.arguments));
                        if (!0 !== t) throw new i(this, e, {
                            result: t
                        });
                        return !0
                    }, this
                },
                Choice: function(e) {
                    if (this.__class__ = "Choice", !o(e) && "function" != typeof e) throw new Error("Choice must be instanciated with an array or a function");
                    return this.list = e, this.validate = function(e) {
                        for (var t = "function" == typeof this.list ? this.list() : this.list, n = 0; n < t.length; n++)
                            if (e === t[n]) return !0;
                        throw new i(this, e, {
                            choices: t
                        })
                    }, this
                },
                Collection: function(e) {
                    return this.__class__ = "Collection", this.constraint = "undefined" != typeof e ? e instanceof r ? e : new n(e) : !1, this.validate = function(e, n) {
                        var r, a = new t,
                            u = 0,
                            l = {},
                            c = this.groups.length ? this.groups : n;
                        if (!o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_an_array
                        });
                        for (var d = 0; d < e.length; d++) r = this.constraint ? a.validate(e[d], this.constraint, c) : a.validate(e[d], c), s(r) || (l[u] = r), u++;
                        return s(l) ? !0 : l
                    }, this
                },
                Count: function(e) {
                    return this.__class__ = "Count", this.count = e, this.validate = function(e) {
                        if (!o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_an_array
                        });
                        var n = "function" == typeof this.count ? this.count(e) : this.count;
                        if (isNaN(Number(n))) throw new Error("Count must be a valid interger", n);
                        if (n !== e.length) throw new i(this, e, {
                            count: n
                        });
                        return !0
                    }, this
                },
                Email: function() {
                    return this.__class__ = "Email", this.validate = function(e) {
                        var n = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if (!n.test(e)) throw new i(this, e);
                        return !0
                    }, this
                },
                EqualTo: function(e) {
                    if (this.__class__ = "EqualTo", "undefined" == typeof e) throw new Error("EqualTo must be instanciated with a value or a function");
                    return this.reference = e, this.validate = function(e) {
                        var t = "function" == typeof this.reference ? this.reference(e) : this.reference;
                        if (t !== e) throw new i(this, e, {
                            value: t
                        });
                        return !0
                    }, this
                },
                GreaterThan: function(e) {
                    if (this.__class__ = "GreaterThan", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold >= e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                GreaterThanOrEqual: function(e) {
                    if (this.__class__ = "GreaterThanOrEqual", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold > e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                InstanceOf: function(e) {
                    if (this.__class__ = "InstanceOf", "undefined" == typeof e) throw new Error("InstanceOf must be instanciated with a value");
                    return this.classRef = e, this.validate = function(e) {
                        if (!0 != e instanceof this.classRef) throw new i(this, e, {
                            classRef: this.classRef
                        });
                        return !0
                    }, this
                },
                Length: function(e) {
                    if (this.__class__ = "Length", !e.min && !e.max) throw new Error("Lenth assert must be instanciated with a { min: x, max: y } object");
                    return this.min = e.min, this.max = e.max, this.validate = function(e) {
                        if ("string" != typeof e && !o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string_or_array
                        });
                        if ("undefined" != typeof this.min && this.min === this.max && e.length !== this.min) throw new i(this, e, {
                            min: this.min,
                            max: this.max
                        });
                        if ("undefined" != typeof this.max && e.length > this.max) throw new i(this, e, {
                            max: this.max
                        });
                        if ("undefined" != typeof this.min && e.length < this.min) throw new i(this, e, {
                            min: this.min
                        });
                        return !0
                    }, this
                },
                LessThan: function(e) {
                    if (this.__class__ = "LessThan", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold <= e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                LessThanOrEqual: function(e) {
                    if (this.__class__ = "LessThanOrEqual", "undefined" == typeof e) throw new Error("Should give a threshold value");
                    return this.threshold = e, this.validate = function(e) {
                        if ("" === e || isNaN(Number(e))) throw new i(this, e, {
                            value: t.errorCode.must_be_a_number
                        });
                        if (this.threshold < e) throw new i(this, e, {
                            threshold: this.threshold
                        });
                        return !0
                    }, this
                },
                NotNull: function() {
                    return this.__class__ = "NotNull", this.validate = function(e) {
                        if (null === e || "undefined" == typeof e) throw new i(this, e);
                        return !0
                    }, this
                },
                NotBlank: function() {
                    return this.__class__ = "NotBlank", this.validate = function(e) {
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if ("" === e.replace(/^\s+/g, "").replace(/\s+$/g, "")) throw new i(this, e);
                        return !0
                    }, this
                },
                Null: function() {
                    return this.__class__ = "Null", this.validate = function(e) {
                        if (null !== e) throw new i(this, e);
                        return !0
                    }, this
                },
                Range: function(e, t) {
                    if (this.__class__ = "Range", "undefined" == typeof e || "undefined" == typeof t) throw new Error("Range assert expects min and max values");
                    return this.min = e, this.max = t, this.validate = function(e) {
                        try {
                            return "string" == typeof e && isNaN(Number(e)) || o(e) ? (new r).Length({
                                min: this.min,
                                max: this.max
                            }).validate(e) : (new r).GreaterThanOrEqual(this.min).validate(e) && (new r).LessThanOrEqual(this.max).validate(e), !0
                        } catch (t) {
                            throw new i(this, e, t.violation)
                        }
                        return !0
                    }, this
                },
                Regexp: function(e, n) {
                    if (this.__class__ = "Regexp", "undefined" == typeof e) throw new Error("You must give a regexp");
                    return this.regexp = e, this.flag = n || "", this.validate = function(e) {
                        if ("string" != typeof e) throw new i(this, e, {
                            value: t.errorCode.must_be_a_string
                        });
                        if (!new RegExp(this.regexp, this.flag).test(e)) throw new i(this, e, {
                            regexp: this.regexp,
                            flag: this.flag
                        });
                        return !0
                    }, this
                },
                Required: function() {
                    return this.__class__ = "Required", this.validate = function(e) {
                        if ("undefined" == typeof e) throw new i(this, e);
                        try {
                            "string" == typeof e ? (new r).NotNull().validate(e) && (new r).NotBlank().validate(e) : !0 === o(e) && (new r).Length({
                                min: 1
                            }).validate(e)
                        } catch (t) {
                            throw new i(this, e)
                        }
                        return !0
                    }, this
                },
                Unique: function(e) {
                    return this.__class__ = "Unique", "object" == typeof e && (this.key = e.key), this.validate = function(e) {
                        var n, r = [];
                        if (!o(e)) throw new i(this, e, {
                            value: t.errorCode.must_be_an_array
                        });
                        for (var s = 0; s < e.length; s++)
                            if (n = "object" == typeof e[s] ? e[s][this.key] : e[s], "undefined" != typeof n) {
                                if (-1 !== r.indexOf(n)) throw new i(this, e, {
                                    value: n
                                });
                                r.push(n)
                            }
                        return !0
                    }, this
                }
            }, e.Assert = r, e.Validator = t, e.Violation = i, e.Constraint = n, Array.prototype.indexOf || (Array.prototype.indexOf = function(e) {
                if (null === this) throw new TypeError;
                var t = Object(this),
                    n = t.length >>> 0;
                if (0 === n) return -1;
                var i = 0;
                if (arguments.length > 1 && (i = Number(arguments[1]), i != i ? i = 0 : 0 !== i && 1 / 0 != i && i != -1 / 0 && (i = (i > 0 || -1) * Math.floor(Math.abs(i)))), i >= n) return -1;
                for (var r = i >= 0 ? i : Math.max(n - Math.abs(i), 0); n > r; r++)
                    if (r in t && t[r] === e) return r;
                return -1
            });
            var s = function(e) {
                    for (var t in e) return !1;
                    return !0
                },
                o = function(e) {
                    return "[object Array]" === Object.prototype.toString.call(e)
                };
            return "function" == typeof define && define.amd ? define("vendors/validator.js/dist/validator", [], function() {
                return e
            }) : "undefined" != typeof module && module.exports ? module.exports = e : window["undefined" != typeof validatorjs_ns ? validatorjs_ns : "Validator"] = e, e
        }();
        r = "undefined" != typeof r ? r : "undefined" != typeof module ? module.exports : null;
        var s = function(e, t) {
            this.__class__ = "ParsleyValidator", this.Validator = r, this.locale = "en", this.init(e || {}, t || {})
        };
        s.prototype = {
            init: function(t, n) {
                this.catalog = n;
                for (var i in t) this.addValidator(i, t[i].fn, t[i].priority, t[i].requirementsTransformer);
                e.emit("parsley:validator:init")
            },
            setLocale: function(e) {
                if ("undefined" == typeof this.catalog[e]) throw new Error(e + " is not available in the catalog");
                return this.locale = e, this
            },
            addCatalog: function(e, t, n) {
                return "object" == typeof t && (this.catalog[e] = t), !0 === n ? this.setLocale(e) : this
            },
            addMessage: function(e, t, n) {
                return "undefined" == typeof this.catalog[e] && (this.catalog[e] = {}), this.catalog[e][t.toLowerCase()] = n, this
            },
            validate: function() {
                return (new this.Validator.Validator).validate.apply(new r.Validator, arguments)
            },
            addValidator: function(t, n, i, s) {
                return this.validators[t.toLowerCase()] = function(t) {
                    return e.extend((new r.Assert).Callback(n, t), {
                        priority: i,
                        requirementsTransformer: s
                    })
                }, this
            },
            updateValidator: function(e, t, n, i) {
                return this.addValidator(e, t, n, i)
            },
            removeValidator: function(e) {
                return delete this.validators[e], this
            },
            getErrorMessage: function(e) {
                var t;
                return t = "type" === e.name ? this.catalog[this.locale][e.name][e.requirements] : this.formatMessage(this.catalog[this.locale][e.name], e.requirements), "" !== t ? t : this.catalog[this.locale].defaultMessage
            },
            formatMessage: function(e, t) {
                if ("object" == typeof t) {
                    for (var n in t) e = this.formatMessage(e, t[n]);
                    return e
                }
                return "string" == typeof e ? e.replace(new RegExp("%s", "i"), t) : ""
            },
            validators: {
                notblank: function() {
                    return e.extend((new r.Assert).NotBlank(), {
                        priority: 2
                    })
                },
                required: function() {
                    return e.extend((new r.Assert).Required(), {
                        priority: 512
                    })
                },
                type: function(t) {
                    var n;
                    switch (t) {
                        case "email":
                            n = (new r.Assert).Email();
                            break;
                        case "range":
                        case "number":
                            n = (new r.Assert).Regexp("^-?(?:\\d+|\\d{1,3}(?:,\\d{3})+)?(?:\\.\\d+)?$");
                            break;
                        case "integer":
                            n = (new r.Assert).Regexp("^-?\\d+$");
                            break;
                        case "digits":
                            n = (new r.Assert).Regexp("^\\d+$");
                            break;
                        case "alphanum":
                            n = (new r.Assert).Regexp("^\\w+$", "i");
                            break;
                        case "url":
                            n = (new r.Assert).Regexp("(https?:\\/\\/)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,24}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)", "i");
                            break;
                        default:
                            throw new Error("validator type `" + t + "` is not supported")
                    }
                    return e.extend(n, {
                        priority: 256
                    })
                },
                pattern: function(t) {
                    var n = "";
                    return /^\/.*\/(?:[gimy]*)$/.test(t) && (n = t.replace(/.*\/([gimy]*)$/, "$1"), t = t.replace(new RegExp("^/(.*?)/" + n + "$"), "$1")), e.extend((new r.Assert).Regexp(t, n), {
                        priority: 64
                    })
                },
                minlength: function(t) {
                    return e.extend((new r.Assert).Length({
                        min: t
                    }), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                maxlength: function(t) {
                    return e.extend((new r.Assert).Length({
                        max: t
                    }), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                length: function(t) {
                    return e.extend((new r.Assert).Length({
                        min: t[0],
                        max: t[1]
                    }), {
                        priority: 32
                    })
                },
                mincheck: function(e) {
                    return this.minlength(e)
                },
                maxcheck: function(e) {
                    return this.maxlength(e)
                },
                check: function(e) {
                    return this.length(e)
                },
                min: function(t) {
                    return e.extend((new r.Assert).GreaterThanOrEqual(t), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                max: function(t) {
                    return e.extend((new r.Assert).LessThanOrEqual(t), {
                        priority: 30,
                        requirementsTransformer: function() {
                            return "string" != typeof t || isNaN(t) ? t : parseInt(t, 10)
                        }
                    })
                },
                range: function(t) {
                    return e.extend((new r.Assert).Range(t[0], t[1]), {
                        priority: 32,
                        requirementsTransformer: function() {
                            for (var e = 0; e < t.length; e++) t[e] = "string" != typeof t[e] || isNaN(t[e]) ? t[e] : parseInt(t[e], 10);
                            return t
                        }
                    })
                },
                equalto: function(t) {
                    return e.extend((new r.Assert).EqualTo(t), {
                        priority: 256,
                        requirementsTransformer: function() {
                            return e(t).length ? e(t).val() : t
                        }
                    })
                }
            }
        };
        var o = function() {
            this.__class__ = "ParsleyUI"
        };
        o.prototype = {
            listen: function() {
                return e.listen("parsley:form:init", this, this.setupForm), e.listen("parsley:field:init", this, this.setupField), e.listen("parsley:field:validated", this, this.reflow), e.listen("parsley:form:validated", this, this.focus), e.listen("parsley:field:reset", this, this.reset), e.listen("parsley:form:destroy", this, this.destroy), e.listen("parsley:field:destroy", this, this.destroy), this
            },
            reflow: function(e) {
                if ("undefined" != typeof e._ui && !1 !== e._ui.active) {
                    var t = this._diff(e.validationResult, e._ui.lastValidationResult);
                    e._ui.lastValidationResult = e.validationResult, e._ui.validatedOnce = !0, this.manageStatusClass(e), this.manageErrorsMessages(e, t), this.actualizeTriggers(e), (t.kept.length || t.added.length) && "undefined" == typeof e._ui.failedOnce && this.manageFailingFieldTrigger(e)
                }
            },
            getErrorsMessages: function(e) {
                if (!0 === e.validationResult) return [];
                for (var t = [], n = 0; n < e.validationResult.length; n++) t.push(this._getErrorMessage(e, e.validationResult[n].assert));
                return t
            },
            manageStatusClass: function(e) {
                !0 === e.validationResult ? this._successClass(e) : e.validationResult.length > 0 ? this._errorClass(e) : this._resetClass(e)
            },
            manageErrorsMessages: function(t, n) {
                if ("undefined" == typeof t.options.errorsMessagesDisabled) {
                    if ("undefined" != typeof t.options.errorMessage) return n.added.length || n.kept.length ? (0 === t._ui.$errorsWrapper.find(".parsley-custom-error-message").length && t._ui.$errorsWrapper.append(e(t.options.errorTemplate).addClass("parsley-custom-error-message")), t._ui.$errorsWrapper.addClass("filled").find(".parsley-custom-error-message").html(t.options.errorMessage)) : t._ui.$errorsWrapper.removeClass("filled").find(".parsley-custom-error-message").remove();
                    for (var i = 0; i < n.removed.length; i++) this.removeError(t, n.removed[i].assert.name, !0);
                    for (i = 0; i < n.added.length; i++) this.addError(t, n.added[i].assert.name, void 0, n.added[i].assert, !0);
                    for (i = 0; i < n.kept.length; i++) this.updateError(t, n.kept[i].assert.name, void 0, n.kept[i].assert, !0)
                }
            },
            addError: function(t, n, i, r, s) {
                t._ui.$errorsWrapper.addClass("filled").append(e(t.options.errorTemplate).addClass("parsley-" + n).html(i || this._getErrorMessage(t, r))), !0 !== s && this._errorClass(t)
            },
            updateError: function(e, t, n, i, r) {
                e._ui.$errorsWrapper.addClass("filled").find(".parsley-" + t).html(n || this._getErrorMessage(e, i)), !0 !== r && this._errorClass(e)
            },
            removeError: function(e, t, n) {
                e._ui.$errorsWrapper.removeClass("filled").find(".parsley-" + t).remove(), !0 !== n && this.manageStatusClass(e)
            },
            focus: function(e) {
                if (!0 === e.validationResult || "none" === e.options.focus) return e._focusedField = null;
                e._focusedField = null;
                for (var t = 0; t < e.fields.length; t++)
                    if (!0 !== e.fields[t].validationResult && e.fields[t].validationResult.length > 0 && "undefined" == typeof e.fields[t].options.noFocus) {
                        if ("first" === e.options.focus) return e._focusedField = e.fields[t].$element, e._focusedField.focus();
                        e._focusedField = e.fields[t].$element
                    }
                return null === e._focusedField ? null : e._focusedField.focus()
            },
            _getErrorMessage: function(e, t) {
                var n = t.name + "Message";
                return "undefined" != typeof e.options[n] ? window.ParsleyValidator.formatMessage(e.options[n], t.requirements) : window.ParsleyValidator.getErrorMessage(t)
            },
            _diff: function(e, t, n) {
                for (var i = [], r = [], s = 0; s < e.length; s++) {
                    for (var o = !1, a = 0; a < t.length; a++)
                        if (e[s].assert.name === t[a].assert.name) {
                            o = !0;
                            break
                        }
                    o ? r.push(e[s]) : i.push(e[s])
                }
                return {
                    kept: r,
                    added: i,
                    removed: n ? [] : this._diff(t, e, !0).added
                }
            },
            setupForm: function(t) {
                t.$element.on("submit.Parsley", !1, e.proxy(t.onSubmitValidate, t)), !1 !== t.options.uiEnabled && t.$element.attr("novalidate", "")
            },
            setupField: function(t) {
                var n = {
                    active: !1
                };
                !1 !== t.options.uiEnabled && (n.active = !0, t.$element.attr(t.options.namespace + "id", t.__id__), n.$errorClassHandler = this._manageClassHandler(t), n.errorsWrapperId = "parsley-id-" + ("undefined" != typeof t.options.multiple ? "multiple-" + t.options.multiple : t.__id__), n.$errorsWrapper = e(t.options.errorsWrapper).attr("id", n.errorsWrapperId), n.lastValidationResult = [], n.validatedOnce = !1, n.validationInformationVisible = !1, t._ui = n, t.$element.is(t.options.excluded) || this._insertErrorWrapper(t), this.actualizeTriggers(t))
            },
            _manageClassHandler: function(t) {
                if ("string" == typeof t.options.classHandler && e(t.options.classHandler).length) return e(t.options.classHandler);
                var n = t.options.classHandler(t);
                return "undefined" != typeof n && n.length ? n : "undefined" == typeof t.options.multiple || t.$element.is("select") ? t.$element : t.$element.parent()
            },
            _insertErrorWrapper: function(t) {
                var n;
                if ("string" == typeof t.options.errorsContainer) {
                    if (e(t.options.errorsContainer).length) return e(t.options.errorsContainer).append(t._ui.$errorsWrapper);
                    window.console && window.console.warn && window.console.warn("The errors container `" + t.options.errorsContainer + "` does not exist in DOM")
                } else "function" == typeof t.options.errorsContainer && (n = t.options.errorsContainer(t));
                return "undefined" != typeof n && n.length ? n.append(t._ui.$errorsWrapper) : "undefined" == typeof t.options.multiple ? t.$element.after(t._ui.$errorsWrapper) : t.$element.parent().after(t._ui.$errorsWrapper)
            },
            actualizeTriggers: function(t) {
                var n = t.$element;
                if (t.options.multiple && (n = e("[" + t.options.namespace + 'multiple="' + t.options.multiple + '"]')), n.off(".Parsley"), !1 !== t.options.trigger) {
                    var i = t.options.trigger.replace(/^\s+/g, "").replace(/\s+$/g, "");
                    "" !== i && n.on(i.split(" ").join(".Parsley ") + ".Parsley", e.proxy("function" == typeof t.eventValidate ? t.eventValidate : this.eventValidate, t))
                }
            },
            eventValidate: function(e) {
                new RegExp("key").test(e.type) && !this._ui.validationInformationVisible && this.getValue().length <= this.options.validationThreshold || (this._ui.validatedOnce = !0, this.validate())
            },
            manageFailingFieldTrigger: function(t) {
                return t._ui.failedOnce = !0, t.options.multiple && e("[" + t.options.namespace + 'multiple="' + t.options.multiple + '"]').each(function() {
                    return new RegExp("change", "i").test(e(this).parsley().options.trigger || "") ? void 0 : e(this).on("change.ParsleyFailedOnce", !1, e.proxy(t.validate, t))
                }), t.$element.is("select") && !new RegExp("change", "i").test(t.options.trigger || "") ? t.$element.on("change.ParsleyFailedOnce", !1, e.proxy(t.validate, t)) : new RegExp("keyup", "i").test(t.options.trigger || "") ? void 0 : t.$element.on("keyup.ParsleyFailedOnce", !1, e.proxy(t.validate, t))
            },
            reset: function(e) {
                e.$element.off(".Parsley"), e.$element.off(".ParsleyFailedOnce"), "undefined" != typeof e._ui && "ParsleyForm" !== e.__class__ && (e._ui.$errorsWrapper.removeClass("filled").children().remove(), this._resetClass(e), e._ui.validatedOnce = !1, e._ui.lastValidationResult = [], e._ui.validationInformationVisible = !1)
            },
            destroy: function(e) {
                this.reset(e), "ParsleyForm" !== e.__class__ && ("undefined" != typeof e._ui && e._ui.$errorsWrapper.remove(), delete e._ui)
            },
            _successClass: function(e) {
                e._ui.validationInformationVisible = !0, e._ui.$errorClassHandler.removeClass(e.options.errorClass).addClass(e.options.successClass)
            },
            _errorClass: function(e) {
                e._ui.validationInformationVisible = !0, e._ui.$errorClassHandler.removeClass(e.options.successClass).addClass(e.options.errorClass)
            },
            _resetClass: function(e) {
                e._ui.$errorClassHandler.removeClass(e.options.successClass).removeClass(e.options.errorClass)
            }
        };
        var a = function(n, i, r, s) {
            this.__class__ = "OptionsFactory", this.__id__ = t.hash(4), this.formOptions = null, this.fieldOptions = null, this.staticOptions = e.extend(!0, {}, n, i, r, {
                namespace: s
            })
        };
        a.prototype = {
            get: function(e) {
                if ("undefined" == typeof e.__class__) throw new Error("Parsley Instance expected");
                switch (e.__class__) {
                    case "Parsley":
                        return this.staticOptions;
                    case "ParsleyForm":
                        return this.getFormOptions(e);
                    case "ParsleyField":
                    case "ParsleyFieldMultiple":
                        return this.getFieldOptions(e);
                    default:
                        throw new Error("Instance " + e.__class__ + " is not supported")
                }
            },
            getFormOptions: function(n) {
                return this.formOptions = t.attr(n.$element, this.staticOptions.namespace), e.extend({}, this.staticOptions, this.formOptions)
            },
            getFieldOptions: function(n) {
                return this.fieldOptions = t.attr(n.$element, this.staticOptions.namespace), null === this.formOptions && "undefined" != typeof n.parent && (this.formOptions = this.getFormOptions(n.parent)), e.extend({}, this.staticOptions, this.formOptions, this.fieldOptions)
            }
        };
        var u = function(n, i) {
            if (this.__class__ = "ParsleyForm", this.__id__ = t.hash(4), "OptionsFactory" !== t.get(i, "__class__")) throw new Error("You must give an OptionsFactory instance");
            this.OptionsFactory = i, this.$element = e(n), this.validationResult = null, this.options = this.OptionsFactory.get(this)
        };
        u.prototype = {
            onSubmitValidate: function(t) {
                return this.validate(void 0, void 0, t), !1 === this.validationResult && t instanceof e.Event && (t.stopImmediatePropagation(), t.preventDefault()), this
            },
            validate: function(t, n, i) {
                this.submitEvent = i, this.validationResult = !0;
                var r = [];
                e.emit("parsley:form:validate", this), this._refreshFields();
                for (var s = 0; s < this.fields.length; s++)(!t || this._isFieldInGroup(this.fields[s], t)) && (r = this.fields[s].validate(n), !0 !== r && r.length > 0 && this.validationResult && (this.validationResult = !1));
                return e.emit("parsley:form:" + (this.validationResult ? "success" : "error"), this), e.emit("parsley:form:validated", this), this.validationResult
            },
            isValid: function(e, t) {
                this._refreshFields();
                for (var n = 0; n < this.fields.length; n++)
                    if ((!e || this._isFieldInGroup(this.fields[n], e)) && !1 === this.fields[n].isValid(t)) return !1;
                return !0
            },
            _isFieldInGroup: function(n, i) {
                return t.isArray(n.options.group) ? -1 !== e.inArray(i, n.options.group) : n.options.group === i
            },
            _refreshFields: function() {
                return this.actualizeOptions()._bindFields()
            },
            _bindFields: function() {
                var e = this;
                return this.fields = [], this.fieldsMappedById = {}, this.$element.find(this.options.inputs).each(function() {
                    var t = new window.Parsley(this, {}, e);
                    "ParsleyField" !== t.__class__ && "ParsleyFieldMultiple" !== t.__class__ || t.$element.is(t.options.excluded) || "undefined" == typeof e.fieldsMappedById[t.__class__ + "-" + t.__id__] && (e.fieldsMappedById[t.__class__ + "-" + t.__id__] = t, e.fields.push(t))
                }), this
            }
        };
        var l = function(n, i, r, s, o) {
                var a = {};
                if (!new RegExp("ParsleyField").test(t.get(n, "__class__"))) throw new Error("ParsleyField or ParsleyFieldMultiple instance expected");
                if ("function" == typeof window.ParsleyValidator.validators[i] && (a = window.ParsleyValidator.validators[i](r)), "Assert" !== a.__parentClass__) throw new Error("Valid validator expected");
                var u = function() {
                    return "undefined" != typeof n.options[i + "Priority"] ? n.options[i + "Priority"] : t.get(a, "priority") || 2
                };
                return s = s || u(), "function" == typeof a.requirementsTransformer && (r = a.requirementsTransformer(), a = window.ParsleyValidator.validators[i](r)), e.extend(a, {
                    name: i,
                    requirements: r,
                    priority: s,
                    groups: [s],
                    isDomConstraint: o || t.attr(n.$element, n.options.namespace, i)
                })
            },
            c = function(n, i, r) {
                this.__class__ = "ParsleyField", this.__id__ = t.hash(4), this.$element = e(n), "undefined" != typeof r ? (this.parent = r, this.OptionsFactory = this.parent.OptionsFactory, this.options = this.OptionsFactory.get(this)) : (this.OptionsFactory = i, this.options = this.OptionsFactory.get(this)), this.constraints = [], this.constraintsByName = {}, this.validationResult = [], this._bindConstraints()
            };
        c.prototype = {
            validate: function(t) {
                return this.value = this.getValue(), e.emit("parsley:field:validate", this), e.emit("parsley:field:" + (this.isValid(t, this.value) ? "success" : "error"), this), e.emit("parsley:field:validated", this), this.validationResult
            },
            isValid: function(e, t) {
                this.refreshConstraints();
                var n = this._getConstraintsSortedPriorities();
                if (0 === n.length) return this.validationResult = [];
                if (("undefined" == typeof t || null === t) && (t = this.getValue()), !t.length && !this._isRequired() && "undefined" == typeof this.options.validateIfEmpty && !0 !== e) return this.validationResult = [];
                if (!1 === this.options.priorityEnabled) return !0 === (this.validationResult = this.validateThroughValidator(t, this.constraints, "Any"));
                for (var i = 0; i < n.length; i++)
                    if (!0 !== (this.validationResult = this.validateThroughValidator(t, this.constraints, n[i]))) return !1;
                return !0
            },
            getValue: function() {
                var e;
                return e = "undefined" != typeof this.options.value ? this.options.value : this.$element.val(), "undefined" == typeof e || null === e ? "" : !0 === this.options.trimValue ? e.replace(/^\s+|\s+$/g, "") : e
            },
            refreshConstraints: function() {
                return this.actualizeOptions()._bindConstraints()
            },
            addConstraint: function(e, t, n, i) {
                if (e = e.toLowerCase(), "function" == typeof window.ParsleyValidator.validators[e]) {
                    var r = new l(this, e, t, n, i);
                    "undefined" !== this.constraintsByName[r.name] && this.removeConstraint(r.name), this.constraints.push(r), this.constraintsByName[r.name] = r
                }
                return this
            },
            removeConstraint: function(e) {
                for (var t = 0; t < this.constraints.length; t++)
                    if (e === this.constraints[t].name) {
                        this.constraints.splice(t, 1);
                        break
                    }
                return delete this.constraintsByName[e], this
            },
            updateConstraint: function(e, t, n) {
                return this.removeConstraint(e).addConstraint(e, t, n)
            },
            _bindConstraints: function() {
                for (var e = [], t = {}, n = 0; n < this.constraints.length; n++) !1 === this.constraints[n].isDomConstraint && (e.push(this.constraints[n]), t[this.constraints[n].name] = this.constraints[n]);
                this.constraints = e, this.constraintsByName = t;
                for (var i in this.options) this.addConstraint(i, this.options[i]);
                return this._bindHtml5Constraints()
            },
            _bindHtml5Constraints: function() {
                (this.$element.hasClass("required") || this.$element.attr("required")) && this.addConstraint("required", !0, void 0, !0), "string" == typeof this.$element.attr("pattern") && this.addConstraint("pattern", this.$element.attr("pattern"), void 0, !0), "undefined" != typeof this.$element.attr("min") && "undefined" != typeof this.$element.attr("max") ? this.addConstraint("range", [this.$element.attr("min"), this.$element.attr("max")], void 0, !0) : "undefined" != typeof this.$element.attr("min") ? this.addConstraint("min", this.$element.attr("min"), void 0, !0) : "undefined" != typeof this.$element.attr("max") && this.addConstraint("max", this.$element.attr("max"), void 0, !0), "undefined" != typeof this.$element.attr("minlength") && "undefined" != typeof this.$element.attr("maxlength") ? this.addConstraint("length", [this.$element.attr("minlength"), this.$element.attr("maxlength")], void 0, !0) : "undefined" != typeof this.$element.attr("minlength") ? this.addConstraint("minlength", this.$element.attr("minlength"), void 0, !0) : "undefined" != typeof this.$element.attr("maxlength") && this.addConstraint("maxlength", this.$element.attr("maxlength"), void 0, !0);
                var e = this.$element.attr("type");
                return "undefined" == typeof e ? this : "number" === e ? "undefined" == typeof this.$element.attr("step") || 0 === parseFloat(this.$element.attr("step")) % 1 ? this.addConstraint("type", "integer", void 0, !0) : this.addConstraint("type", "number", void 0, !0) : new RegExp(e, "i").test("email url range") ? this.addConstraint("type", e, void 0, !0) : this
            },
            _isRequired: function() {
                return "undefined" == typeof this.constraintsByName.required ? !1 : !1 !== this.constraintsByName.required.requirements
            },
            _getConstraintsSortedPriorities: function() {
                for (var e = [], t = 0; t < this.constraints.length; t++) - 1 === e.indexOf(this.constraints[t].priority) && e.push(this.constraints[t].priority);
                return e.sort(function(e, t) {
                    return t - e
                }), e
            }
        };
        var d = function() {
            this.__class__ = "ParsleyFieldMultiple"
        };
        d.prototype = {
            addElement: function(e) {
                return this.$elements.push(e), this
            },
            refreshConstraints: function() {
                var t;
                if (this.constraints = [], this.$element.is("select")) return this.actualizeOptions()._bindConstraints(), this;
                for (var n = 0; n < this.$elements.length; n++)
                    if (e("html").has(this.$elements[n]).length) {
                        t = this.$elements[n].data("ParsleyFieldMultiple").refreshConstraints().constraints;
                        for (var i = 0; i < t.length; i++) this.addConstraint(t[i].name, t[i].requirements, t[i].priority, t[i].isDomConstraint)
                    } else this.$elements.splice(n, 1);
                return this
            },
            getValue: function() {
                if ("undefined" != typeof this.options.value) return this.options.value;
                if (this.$element.is("input[type=radio]")) return e("[" + this.options.namespace + 'multiple="' + this.options.multiple + '"]:checked').val() || "";
                if (this.$element.is("input[type=checkbox]")) {
                    var t = [];
                    return e("[" + this.options.namespace + 'multiple="' + this.options.multiple + '"]:checked').each(function() {
                        t.push(e(this).val())
                    }), t.length ? t : []
                }
                return this.$element.is("select") && null === this.$element.val() ? [] : this.$element.val()
            },
            _init: function(e) {
                return this.$elements = [this.$element], this.options.multiple = e, this
            }
        };
        var f = e({}),
            h = {};
        e.listen = function(e) {
            if ("undefined" == typeof h[e] && (h[e] = []), "function" == typeof arguments[1]) return h[e].push({
                fn: arguments[1]
            });
            if ("object" == typeof arguments[1] && "function" == typeof arguments[2]) return h[e].push({
                fn: arguments[2],
                ctxt: arguments[1]
            });
            throw new Error("Wrong parameters")
        }, e.listenTo = function(e, t, n) {
            if ("undefined" == typeof h[t] && (h[t] = []), !(e instanceof c || e instanceof u)) throw new Error("Must give Parsley instance");
            if ("string" != typeof t || "function" != typeof n) throw new Error("Wrong parameters");
            h[t].push({
                instance: e,
                fn: n
            })
        }, e.unsubscribe = function(e, t) {
            if ("undefined" != typeof h[e]) {
                if ("string" != typeof e || "function" != typeof t) throw new Error("Wrong arguments");
                for (var n = 0; n < h[e].length; n++)
                    if (h[e][n].fn === t) return h[e].splice(n, 1)
            }
        }, e.unsubscribeTo = function(e, t) {
            if ("undefined" != typeof h[t]) {
                if (!(e instanceof c || e instanceof u)) throw new Error("Must give Parsley instance");
                for (var n = 0; n < h[t].length; n++)
                    if ("undefined" != typeof h[t][n].instance && h[t][n].instance.__id__ === e.__id__) return h[t].splice(n, 1)
            }
        }, e.unsubscribeAll = function(e) {
            "undefined" != typeof h[e] && delete h[e]
        }, e.emit = function(e, t) {
            if ("undefined" != typeof h[e])
                for (var n = 0; n < h[e].length; n++)
                    if ("undefined" != typeof h[e][n].instance) {
                        if (t instanceof c || t instanceof u)
                            if (h[e][n].instance.__id__ !== t.__id__) {
                                if (h[e][n].instance instanceof u && t instanceof c)
                                    for (var i = 0; i < h[e][n].instance.fields.length; i++)
                                        if (h[e][n].instance.fields[i].__id__ === t.__id__) {
                                            h[e][n].fn.apply(f, Array.prototype.slice.call(arguments, 1));
                                            continue
                                        }
                            } else h[e][n].fn.apply(f, Array.prototype.slice.call(arguments, 1))
                    } else h[e][n].fn.apply("undefined" != typeof h[e][n].ctxt ? h[e][n].ctxt : f, Array.prototype.slice.call(arguments, 1))
        }, e.subscribed = function() {
            return h
        }, window.ParsleyConfig = window.ParsleyConfig || {}, window.ParsleyConfig.i18n = window.ParsleyConfig.i18n || {}, window.ParsleyConfig.i18n.en = e.extend(window.ParsleyConfig.i18n.en || {}, {
            defaultMessage: "This value seems to be invalid.",
            type: {
                email: "This value should be a valid email.",
                url: "This value should be a valid url.",
                number: "This value should be a valid number.",
                integer: "This value should be a valid integer.",
                digits: "This value should be digits.",
                alphanum: "This value should be alphanumeric."
            },
            notblank: "This value should not be blank.",
            required: "This value is required.",
            pattern: "This value seems to be invalid.",
            min: "This value should be greater than or equal to %s.",
            max: "This value should be lower than or equal to %s.",
            range: "This value should be between %s and %s.",
            minlength: "This value is too short. It should have %s characters or more.",
            maxlength: "This value is too long. It should have %s characters or fewer.",
            length: "This value length is invalid. It should be between %s and %s characters long.",
            mincheck: "You must select at least %s choices.",
            maxcheck: "You must select %s choices or fewer.",
            check: "You must select between %s and %s choices.",
            equalto: "This value should be the same."
        }), "undefined" != typeof window.ParsleyValidator && window.ParsleyValidator.addCatalog("en", window.ParsleyConfig.i18n.en, !0);
        var p = function(n, i, r) {
            if (this.__class__ = "Parsley", this.__version__ = "2.0.6", this.__id__ = t.hash(4), "undefined" == typeof n) throw new Error("You must give an element");
            if ("undefined" != typeof r && "ParsleyForm" !== r.__class__) throw new Error("Parent instance must be a ParsleyForm instance");
            return this.init(e(n), i, r)
        };
        p.prototype = {
            init: function(e, i, r) {
                if (!e.length) throw new Error("You must bind Parsley on an existing element.");
                if (this.$element = e, this.$element.data("Parsley")) {
                    var s = this.$element.data("Parsley");
                    return "undefined" != typeof r && (s.parent = r), s
                }
                return this.OptionsFactory = new a(n, t.get(window, "ParsleyConfig") || {}, i, this.getNamespace(i)), this.options = this.OptionsFactory.get(this), this.$element.is("form") || t.attr(this.$element, this.options.namespace, "validate") && !this.$element.is(this.options.inputs) ? this.bind("parsleyForm") : this.$element.is(this.options.inputs) && !this.$element.is(this.options.excluded) ? this.isMultiple() ? this.handleMultiple(r) : this.bind("parsleyField", r) : this
            },
            isMultiple: function() {
                return this.$element.is("input[type=radio], input[type=checkbox]") && "undefined" == typeof this.options.multiple || this.$element.is("select") && "undefined" != typeof this.$element.attr("multiple")
            },
            handleMultiple: function(n) {
                var i, r, s, o = this;
                if (this.options = e.extend(this.options, n ? n.OptionsFactory.get(n) : {}, t.attr(this.$element, this.options.namespace)), this.options.multiple ? r = this.options.multiple : "undefined" != typeof this.$element.attr("name") && this.$element.attr("name").length ? r = i = this.$element.attr("name") : "undefined" != typeof this.$element.attr("id") && this.$element.attr("id").length && (r = this.$element.attr("id")), this.$element.is("select") && "undefined" != typeof this.$element.attr("multiple")) return this.bind("parsleyFieldMultiple", n, r || this.__id__);
                if ("undefined" == typeof r) return window.console && window.console.warn && window.console.warn("To be binded by Parsley, a radio, a checkbox and a multiple select input must have either a name or a multiple option.", this.$element), this;
                if (r = r.replace(/(:|\.|\[|\]|\{|\}|\$)/g, ""), "undefined" != typeof i && e('input[name="' + i + '"]').each(function() {
                        e(this).is("input[type=radio], input[type=checkbox]") && e(this).attr(o.options.namespace + "multiple", r)
                    }), e("[" + this.options.namespace + "multiple=" + r + "]").length)
                    for (var a = 0; a < e("[" + this.options.namespace + "multiple=" + r + "]").length; a++)
                        if ("undefined" != typeof e(e("[" + this.options.namespace + "multiple=" + r + "]").get(a)).data("Parsley")) {
                            s = e(e("[" + this.options.namespace + "multiple=" + r + "]").get(a)).data("Parsley"), this.$element.data("ParsleyFieldMultiple") || (s.addElement(this.$element), this.$element.attr(this.options.namespace + "id", s.__id__));
                            break
                        }
                return this.bind("parsleyField", n, r, !0), s || this.bind("parsleyFieldMultiple", n, r)
            },
            getNamespace: function(e) {
                return "undefined" != typeof this.$element.data("parsleyNamespace") ? this.$element.data("parsleyNamespace") : "undefined" != typeof t.get(e, "namespace") ? e.namespace : "undefined" != typeof t.get(window, "ParsleyConfig.namespace") ? window.ParsleyConfig.namespace : n.namespace
            },
            bind: function(n, r, s, o) {
                var a;
                switch (n) {
                    case "parsleyForm":
                        a = e.extend(new u(this.$element, this.OptionsFactory), new i, window.ParsleyExtend)._bindFields();
                        break;
                    case "parsleyField":
                        a = e.extend(new c(this.$element, this.OptionsFactory, r), new i, window.ParsleyExtend);
                        break;
                    case "parsleyFieldMultiple":
                        a = e.extend(new c(this.$element, this.OptionsFactory, r), new i, new d, window.ParsleyExtend)._init(s);
                        break;
                    default:
                        throw new Error(n + "is not a supported Parsley type")
                }
                return "undefined" != typeof s && t.setAttr(this.$element, this.options.namespace, "multiple", s), "undefined" != typeof o ? (this.$element.data("ParsleyFieldMultiple", a), a) : (new RegExp("ParsleyF", "i").test(a.__class__) && (this.$element.data("Parsley", a), e.emit("parsley:" + ("parsleyForm" === n ? "form" : "field") + ":init", a)), a)
            }
        }, e.fn.parsley = e.fn.psly = function(t) {
            if (this.length > 1) {
                var n = [];
                return this.each(function() {
                    n.push(e(this).parsley(t))
                }), n
            }
            return e(this).length ? new p(this, t) : void(window.console && window.console.warn && window.console.warn("You must bind Parsley on an existing element."))
        }, window.ParsleyUI = "function" == typeof t.get(window, "ParsleyConfig.ParsleyUI") ? (new window.ParsleyConfig.ParsleyUI).listen() : (new o).listen(), "undefined" == typeof window.ParsleyExtend && (window.ParsleyExtend = {}), "undefined" == typeof window.ParsleyConfig && (window.ParsleyConfig = {}), window.Parsley = window.psly = p, window.ParsleyUtils = t, window.ParsleyValidator = new s(window.ParsleyConfig.validators, window.ParsleyConfig.i18n), !1 !== t.get(window, "ParsleyConfig.autoBind") && e(function() {
            e("[data-parsley-validate]").length && e("[data-parsley-validate]").parsley()
        })
    });
try {
    var metaLocale = document.querySelector('meta[name="site_locale"]'),
        siteLocale = metaLocale.content;
    if (siteLocale) {
        var url = "https://cdn.jsdelivr.net/gh/guillaumepotier/Parsley.js@2.0.7/src/i18n/" + siteLocale + ".js",
            head = document.getElementsByTagName("head")[0],
            el = document.createElement("script");
        el.src = url, head.insertBefore(el, head.lastChild)
    }
} catch (error) {}! function(e) {
    function t(t) {
        this.$el = e(t), this.token = this.$el.data("favoriteToken"), this.isFavorited = this.$el.data("favorited"), this.isProcessing = !1, this.activeClass = "favorited", this.endpoint = "/favorites", this.$el.on("click", this.onClicked.bind(this)), this.setInitialState()
    }
    t.prototype = {
        getDataForRequest: function() {
            return {
                token: this.token
            }
        },
        getHttpMethod: function() {
            return this.isFavorited ? "DELETE" : "POST"
        },
        markAsInstalled: function() {
            this.$el.data("starInstalled", !0)
        },
        onComplete: function() {
            this.isProcessing = !1
        },
        onClicked: function() {
            this.isProcessing || (this.isProcessing = !0, this.toggleClass(), e.ajax({
                beforeSend: function(t) {
                    t.setRequestHeader("X-CSRF-Token", e('meta[name="csrf-token"]').attr("content"))
                },
                url: this.endpoint,
                method: this.getHttpMethod(),
                data: this.getDataForRequest(),
                success: this.onSuccess.bind(this),
                error: this.onError.bind(this),
                complete: this.onComplete.bind(this)
            }))
        },
        onError: function() {
            this.toggleClass()
        },
        onSuccess: function() {
            this.isFavorited = !this.isFavorited
        },
        toggleClass: function() {
            this.$el.toggleClass(this.activeClass)
        },
        setInitialState: function() {
            this.markAsInstalled(), this.$el.click()
        }
    }, e(document).on("click", "[data-favorite-toggle]", function(n) {
        n.preventDefault();
        var i = e(n.currentTarget);
        i.data("starInstalled") || new t(n.currentTarget)
    })
}(jQuery), $(document).ready(function() {
        $("form[data-kjb-disable-on-submit]").on("submit", function() {
            if (!$(this).data("remote")) {
                var e = $(this).find(":submit"),
                    t = e.data("disable-with");
                e.attr("disabled", !0), t && e.text(t), $(this).parsley().subscribe("parsley:form:error", function() {
                    e.attr("disabled", !1)
                })
            }
        })
    }), $('input[type="hidden"][name="kjb_fk_checksum"]').val(""), $(document).on("click", "a[href='#two-step']", function(e) {
        Kajabi.theme.editor || (e.preventDefault(), $("#two-step").show().toggleClass("show", !0))
    }), $(window).on("message:assessment:resize resize", function() {
        resizeAssessmentIframe($(".assessment-wrapper iframe"))
    }), $(document).on("click", "a[href='#next-pipeline-step']", function(e) {
        Kajabi.theme.editor || (e.preventDefault(), window.location = Kajabi.nextPipelineStepUrl)
    }),
    function(e) {
        function t(t, n, i) {
            if (i.mailgunRequest && (i.mailgunRequest.abort(), i.mailgunRequest = null), t) {
                if (n && n.in_progress && n.in_progress(n.e), i.mailgunLastSuccessReturn && t == i.mailgunLastSuccessReturn.address) return void(n && n.success && n.success(i.mailgunLastSuccessReturn, n.e));
                var r = !1;
                if (t.length > 512 ? r = "Email address exceeds maxiumum allowable length of 512." : 1 !== t.split("@").length - 1 && (r = "Email address must contain only one @."), r) return void(n && n.error ? n.error(r, n.e) : console && console.log(r));
                n && void 0 == n.api_key && console && console.log("Please pass in api_key to mailgun_validator.");
                var s = setTimeout(function() {
                    r = "Error occurred, unable to validate address.", success || (i.mailgunRequest && (i.mailgunRequest.abort(), i.mailgunRequest = null), n && n.error ? n.error(r, n.e) : console && console.log(r))
                }, 3e4);
                i.mailgunRequest = e.ajax({
                    type: "GET",
                    url: "https://api.mailgun.net/v2/address/validate?callback=?",
                    data: {
                        address: t,
                        api_key: n.api_key
                    },
                    dataType: "jsonp",
                    crossDomain: !0,
                    success: function(e) {
                        clearTimeout(s), i.mailgunLastSuccessReturn = e, n && n.success && n.success(e, n.e)
                    },
                    error: function() {
                        clearTimeout(s), r = "Error occurred, unable to validate address.", n && n.error ? n.error(r, n.e) : console && console.log(r)
                    }
                })
            }
        }
        e.fn.mailgun_validator = function(n) {
            return this.each(function() {
                var i = e(this);
                i.focusout(function(r) {
                    var s = i.val();
                    s = e.trim(s), i.val(s), n.e = r, t(s, n, i)
                })
            })
        }
    }(jQuery), $(function() {
        var e = $("[data-mailgun-validation]");
        e.mailgun_validator({
            api_key: e.data("mailgun-public-api-key"),
            success: function(e, t) {
                var n = $(t.target),
                    i = n.parsley();
                if (n.siblings(".mailgun-validation").remove(), i.isValid() && !e.is_valid) {
                    var r = "Please double check your email address.";
                    e.did_you_mean && (r = "Did you mean " + e.did_you_mean + "?"), n.after($('<p class="mailgun-validation">').text(r))
                }
            },
            error: function() {}
        }).keyup(function() {
            var e = $(this);
            "" == e.val() && e.siblings(".mailgun-validation").remove()
        })
    }),
    function(e) {
        function t() {
            this.librarySlug = "/library", this.memberMobileBannerPath = "member_mobile_banner", this.onLibraryPage() && this.fetchBanner()
        }
        t.prototype = {
            fetchBanner: function() {
                e.ajax({
                    url: this.memberMobileBannerPath
                }).done(this.onFetchBannerDone.bind(this)).done(this.encoreThemeActions.bind(this))
            },
            onFetchBannerDone: function(t) {
                if ("" !== t) {
                    var n = e("body");
                    n.prepend(t)
                }
            },
            onLibraryPage: function() {
                return 0 === location.pathname.indexOf(this.librarySlug)
            },
            encoreThemeActions: function(t) {
                if ("" !== t) {
                    var n = ThemeInfo && "encore" === ThemeInfo.name;
                    if (n) {
                        var i = e(".sticky");
                        i.length && e(window).scroll(function() {
                            var t = e("#kjb-mobile-banner"),
                                n = 0 == e(window).scrollTop(),
                                i = n ? "block" : "none";
                            t.css("display", i)
                        });
                        var r = e(".header--overlay");
                        if (r.length) {
                            var s = e("header"),
                                o = s.height(),
                                a = s.css("transition"),
                                u = {
                                    position: "relative",
                                    transition: "none",
                                    "margin-bottom": 0 - o
                                };
                            s.css(u), setTimeout(function() {
                                e("header").css("transition", a)
                            });
                            var i = e(".sticky");
                            i.length && e(window).scroll(function() {
                                var t = e("header"),
                                    n = 0 == e(window).scrollTop(),
                                    i = n ? "relative" : "fixed";
                                t.css("position", i)
                            })
                        }
                    }
                }
            }
        }, e(document).ready(function() {
            new t
        })
    }(jQuery), $(document).ready(function() {
        $(this).trigger("page:update")
    }), $(document).ajaxComplete(function() {
        $(this).trigger("page:update")
    }), $(document).on("turbolinks:load", function() {
        $(this).trigger("page:update")
    }), jQuery.fn.extend({
        install: function(e, t) {
            return this.each(function() {
                installedBehaviors = $(this).data("installed_behaviors"), installedBehaviors || (installedBehaviors = {}), installedBehaviors[e] || (t.call(this, this), installedBehaviors[e] = !0, $(this).data("installed_behaviors", installedBehaviors))
            })
        }
    }), window.initKajabiRecaptcha = function(e, t, n) {
        var i = document.getElementById(e),
            r = i.form.querySelector("[type=submit]"),
            s = grecaptcha.render(t, {
                sitekey: n,
                size: "invisible",
                callback: function(e) {
                    r && (r.disabled = !0), i.value = e, i.form.submit()
                }
            }),
            o = function(e) {
                return r && (r.disabled = !1), grecaptcha.execute(s), e.preventDefault(), !1
            };
        window.jQuery ? window.jQuery(i.form).submit(o) : i.form.addEventListener("submit", o)
    }, $('input[type="search"]').on("search", function(e) {
        var t = e.target;
        0 == t.value.length && (window.location.search = "")
    }), window.ThemeInfo = {
        name: "encore"
    }, "undefined" != typeof Wistia && _.isObject(Wistia) && _.isUndefined(Wistia.obj) && (Wistia.obj = {
        merge: function(e, t) {
            _.extend(e, t)
        }
    });